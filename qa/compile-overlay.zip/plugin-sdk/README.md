# Opsis Plugin SDK 2.0 — R9 manifest and dependency preview

This increment adds SDK version negotiation at package discovery, not a new binary contract. Existing plugins using the shared 0.8.0.0 contract and the pinned 1.0.0.0 plugin DLL identities continue to use the same PluginHost. Missing `opsis-permissions.json` selects legacy SDK 1.0; legacy boolean fields remain supported.

A package opting into SDK 2.0 must place `opsis-permissions.json` beside its entry DLL. See `example/opsis-permissions.json`. Supported declarations: `network`, `audio`, `localFiles` (boolean, omitted=false). Optional `dependencies` declares required plugin IDs and minimum numeric plugin versions (up to 32). Unknown SDK versions, duplicate keys, incorrect types, unknown SDK 2.0 properties and unsupported runtimes are rejected before DLL instantiation. SDK 2.0 requires explicit package approval even under a protected install root. R11 SDK2 uses a separate SHA-256 domain including every regular file in the package; all prior SDK2 approvals must be renewed once. Legacy SDK1 keeps its existing digest.

**This is disclosure and package-level consent, not enforcement of per-capability permissions.** Approved in-process DLLs have the host's Windows rights. Revocation blocks host reactivation of resident code and persists the requirement for another approval on restart; it cannot unload a non-collectible AssemblyLoadContext or stop arbitrary threads created by a plugin. The consent store retains its existing folder-name identity semantics. A user-writable trust store and mutable package paths are not an OS security boundary. No separate-process sandbox or authenticated IPC is delivered. See the R10 offline maintenance tool below.

Tests: `dotnet run --project tests/Opsis.PluginPolicySmoke/Opsis.PluginPolicySmoke.csproj -c Release`. The Windows RC audit also runs this project. This test links the production parser and trust implementation; separate live host tests remain necessary.

## Dependency lifecycle (R9)
Example: `"dependencies": { "provider.one": "1.2.0" }`. Keys are runtime plugin IDs, not file names; values are minimum numeric versions (`System.Version`, 2–4 components, missing components normalized to zero). An empty or omitted object adds no requirements. SDK1 packages can provide dependencies but do not declare them. All entries in a package share its requirements.

The host activates providers first using bounded passes through eligible loaded entries. Missing, ambiguous, outdated, disabled, quarantined or cyclic providers block activation and produce a reason in the plugin permissions line/log. Late approvals and explicit provider enable retry only dependency-blocked entries, not failed starts. Disable, quarantine, revoke and uninstall stop active dependents before the provider. Dependents retain their saved enable preference. Live SDK2 replacement and live replacement of providers with active dependents require restart. No extra watcher, network request or automatic installation. Legacy plugin constructors still run after trust approval but before runtime dependency resolution; this is activation ordering, not a guarantee of no code execution. Existing lifecycle concurrency, arbitrary plugin threads, package staging, full dependency graph diagnostics, transactional upgrades and rollback remain open.

## Offline package maintenance (R10, operator tool; not an integrated updater)

Windows, Python 3.11+, normal user data folder only. Close Opsis and external plugin installers; use an independently trusted SHA-256 for a complete replacement ZIP with the same root entry DLL names. Existing `%APPDATA%/Opsis/plugins/<package>` only; no Program Files or registry-installed external paths. The tool holds the normal session mutex, keeps original files outside discovery, writes a pending marker before moving folders, and verifies file hashes before/after. No DLL execution or auto-approval.

```powershell
python tools/plugin_package_maintenance.py --confirm update Example update.zip --sha256 <trusted-64-hex-digest>
python tools/plugin_package_maintenance.py --confirm rollback <transaction-id>
python tools/plugin_package_maintenance.py --confirm recover
```

`recover` restores the old package after an interrupted swap. If either copy was modified, it stops without overwriting. Incomplete transactions hold plugin startup in the R10 host. External data folders/settings are not touched; package-local data is retained in the backup, not automatically merged. For SDK2, an assets-only update now invalidates approval; legacy SDK1 retains the old DLL/deps/manifest digest. This tool does not validate Authenticode or runtime ABI, does not resolve dependency downloads, and does not implement an OS security boundary. The SHA must come from a trusted independent channel. No automated backup expiration; failed staging may leave inert diagnostic folders. Mutex is local to the current Windows session; close other sessions and external installers. Power-loss durability, Windows ACL/reparse/races and actual host behavior still need testing. Do not use for a package queued for uninstallation.

Tests: `python -B tests/integration/test_plugin_package_maintenance.py -v` (portable fixture tests, no real DLL execution).

## R11 — complete package identity and bounded versions
SDK2 approval covers all regular files, up to 4096 filesystem entries and 512 MiB. Links, ambiguous case-insensitive file paths and changed/oversized files are rejected. A package with mutable files beside its DLL may require reapproval after changes; store persistent user data outside the package. This is not an authenticated signature or defense against same-user concurrent modification. SDK1 digest compatibility is preserved. Dependencies accept the old string or `{"min":"1.2","maxExclusive":"2.0"}` (upper bound optional, exclusive). No arbitrary SemVer or automatic dependency installation. The runtime still accepts only approved in-process DLLs. Separate capability enforcement and isolation remain open.
