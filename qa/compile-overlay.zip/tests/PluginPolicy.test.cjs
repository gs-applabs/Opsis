'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const read = p => fs.readFileSync(path.join(__dirname, '..', p), 'utf8');
test('SDK 2 package policy runs before the existing loader and requires explicit approval', () => {
  const host = read('src/Services/PluginHost.cs');
  const consider = host.slice(host.indexOf('internal bool ConsiderFolder('), host.indexOf('public int ResolvePending('));
  assert.ok(consider.indexOf('PluginCapabilityManifest.Inspect(folder)') < consider.indexOf('(FolderLoader ?? LoadFolder)(folder)'));
  assert.match(consider, /!trustedRoot \|\| declaration\.RequiresExplicitApproval \|\| TrustStore\.IsRevoked/);
  assert.match(host, /Capabilities = declaration\.Summary/);
  const example = JSON.parse(read('plugin-sdk/example/opsis-permissions.json'));
  assert.equal(example.sdkVersion, '2.0');
  assert.equal(example.runtime, 'in-process');
  assert.equal(example.network, false);
});
test('revocation blocks host reactivation, navigation and contribution enumeration', () => {
  const host = read('src/Services/PluginHost.cs');
  assert.match(host, /if \(enabled && Snap\(\)\.Any\(p => p\.Revoked/);
  assert.match(host, /if \(p\.Started && !p\.Revoked\) NavigationRequested/);
  assert.match(host, /Snap\(\)\.Where\(p => p\.Started && !p\.Revoked\)/);
  assert.match(read('src/Services/PluginTrust.cs'), /Revoked = true/);
  assert.match(read('.github/workflows/3.0-rc-vm-audit.yml'), /Opsis\.PluginPolicySmoke\.csproj/);
});

test('SDK2 dependency policy participates in start, approval and stop lifecycle', () => {
  const host = read('src/Services/PluginHost.cs');
  assert.match(host, /ActivateReady\(Snap\(\)\)/);
  assert.match(host, /ActivateReady\(Snap\(\)\.Where\(p => !before\.Contains\(p\)\)\)/);
  assert.match(host, /p\.DependencyBlock = DependencyReason\(p\)/);
  assert.match(host, /PluginDependencyPolicy\.StopOrder\(rootIds, nodes\)/);
  for (const reason of ['dependency approval revoked','dependency disabled','dependency uninstalled','dependency quarantined']) assert.ok(host.includes(reason));
  assert.match(host, /Dependencies = declaration\.Dependencies/);
  assert.match(read('src/Services/PluginCapabilityManifest.cs'), /dependencies\.Count >= 32/);
  assert.match(read('tests/Opsis.PluginPolicySmoke/Opsis.PluginPolicySmoke.csproj'), /PluginDependencyPolicy\.cs/);
});
test('SDK2 full integrity policy and version bounds are connected to the host', () => {
  const host = read('src/Services/PluginHost.cs');
  assert.match(host, /ApprovalDigest\(folder, declaration\.RequiresExplicitApproval\)/);
  assert.match(host, /ApprovalDigest\(req\.Folder, declaration\.RequiresExplicitApproval\)/);
  assert.match(read('src/Services/PluginTrust.cs'), /OPSIS-SDK2-FULL-PACKAGE-V1/);
  assert.match(read('src/Services/PluginDependencyPolicy.cs'), /Normalize\(actual\) >= Normalize\(max\)/);
});
test('host removal has a receipt and no recursive directory deletion', () => {
  const host = read('src/Services/PluginHost.cs');
  const policy = read('src/Services/PluginRemovalPolicy.cs');
  assert.match(host, /PluginRemovalPolicy\.Authorize/);
  assert.match(host, /PluginRemovalPolicy\.TryArchive/);
  assert.doesNotMatch(host, /Directory\.Delete\(/);
  assert.match(policy, /receipt\.Digest, PluginTrust\.HashCompletePackage\(folder\)/);
  assert.match(policy, /Directory\.Move\(folder, target\)/);
});
