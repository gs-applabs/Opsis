using MotionDesk.Services;
static void Assert(bool value,string label) { if(!value) throw new Exception(label);Console.WriteLine("PASS "+label); }
static string Id(int i)=>"package:"+i.ToString("X64");
var map=new Dictionary<string,string>();
Assert(PackageLineage.ValidId(Id(1)) && !PackageLineage.ValidId("../foo"),"strict catalog IDs");
Assert(PackageLineage.Link(map,Id(2),Id(1)),"record repair ancestry");
Assert(PackageLineage.Link(map,Id(3),Id(2)),"record update chain");
Assert(PackageLineage.Previous(map,Id(3))==Id(2),"direct predecessor");
Assert(!PackageLineage.Link(map,Id(1),Id(3)),"cycle refused");
Assert(!PackageLineage.Link(map,Id(2),Id(3)),"existing predecessor not overwritten");
Assert(!PackageLineage.Link(map,Id(4),Id(4)),"self link refused");
Assert(!PackageLineage.Link(map,"C:\\bad",Id(1)),"path refused");
for(int i=4;map.Count<PackageLineage.Limit;i++)Assert(PackageLineage.Link(map,Id(i),Id(1)),"bounded ancestry");
Assert(!PackageLineage.Link(map,Id(999),Id(1)),"capacity bounded");
