namespace MotionDesk.Services;
internal static class AppPaths { internal static string AppDataFolder { get; set; } = ""; }
