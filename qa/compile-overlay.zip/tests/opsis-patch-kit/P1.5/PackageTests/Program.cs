using System.IO.Compression;
using MotionDesk.Services;
static void Assert(bool value, string label) { if (!value) throw new Exception(label); Console.WriteLine("PASS " + label); }
var root = Path.Combine(Path.GetTempPath(), "opsis-package-tests-" + Guid.NewGuid().ToString("N")); Directory.CreateDirectory(root);
try
{
    AppPaths.AppDataFolder = root;
    var source = Path.Combine(root, "original.zip");
    using (var archive = ZipFile.Open(source, ZipArchiveMode.Create))
    {
        using (var writer = new StreamWriter(archive.CreateEntry("wrapper/index.html").Open())) writer.Write("<html>original</html>");
        using (var writer = new StreamWriter(archive.CreateEntry("wrapper/a.js").Open())) writer.Write("abcdef");
    }
    var index = WallpaperPackages.Import(source); var dir = Path.GetDirectoryName(index)!;
    var result = WallpaperPackages.VerifyAgainstArchive(index, source);
    Assert(result.Matches && result.MatchedFiles == 2, "identical original");
    File.WriteAllText(Path.Combine(dir,"a.js"), "abcdeg");
    result = WallpaperPackages.VerifyAgainstArchive(index, source);
    Assert(!result.Matches && result.Changed == 1, "same-size corruption");
    File.Delete(Path.Combine(dir,"a.js")); File.WriteAllText(Path.Combine(dir,"extra.txt"), "extra");
    result = WallpaperPackages.VerifyAgainstArchive(index, source);
    Assert(result.Missing == 1 && result.Unexpected == 1, "missing and extra files");
    var repaired = WallpaperPackages.Import(source);
    Assert(index != repaired && File.Exists(index) && File.Exists(Path.Combine(dir,"extra.txt")), "side-by-side repair retains original");
    Assert(WallpaperPackages.VerifyAgainstArchive(repaired,source).Matches, "repair matches archive");
    var exported = Path.Combine(root,"exported.zip");
    WallpaperPackages.Export(repaired,exported);
    Assert(WallpaperPackages.VerifyAgainstArchive(repaired,exported).Matches, "bounded export round trip");
    var repairedDir = Path.GetDirectoryName(repaired)!;
    try { WallpaperPackages.Export(repaired,Path.Combine(repairedDir,"inside.zip")); throw new Exception("inside package accepted"); }
    catch (IOException) { Console.WriteLine("PASS export into source refused"); }
    var badIndex = Path.Combine(repairedDir,"other.html"); File.WriteAllText(badIndex,"<html></html>");
    byte[] priorExport = File.ReadAllBytes(exported);
    try { WallpaperPackages.Export(badIndex,exported); throw new Exception("non-index accepted"); }
    catch (InvalidDataException) { Console.WriteLine("PASS arbitrary HTML export refused"); }
    Assert(File.ReadAllBytes(exported).SequenceEqual(priorExport), "failed export preserves previous archive");
    File.Delete(badIndex);
    string outside = Path.Combine(root,"outside.txt"); File.WriteAllText(outside,"not part of package");
    string link = Path.Combine(repairedDir,"link.txt");
    bool linked = false;
    try { File.CreateSymbolicLink(link,outside); linked = true; }
    catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or PlatformNotSupportedException)
    { Console.WriteLine("SKIP symlink test: runner has no permission/support"); }
    if (linked)
    {
        try { WallpaperPackages.Export(repaired,exported); throw new Exception("linked file accepted"); }
        catch (InvalidDataException) { Console.WriteLine("PASS linked file refused"); }
        Assert(File.ReadAllBytes(exported).SequenceEqual(priorExport), "link rejection preserves previous archive");
        File.Delete(link);
    }

    try { WallpaperPackages.VerifyAgainstArchive(Path.Combine(root,"index.html"),source); throw new Exception("outside root accepted"); }
    catch (InvalidDataException) { Console.WriteLine("PASS outside root refused"); }
    // P1.10: preflight must reject before any extraction, even on a case-sensitive filesystem.
    void RejectArchive(string label, params string[] paths)
    {
        string file = Path.Combine(root, Guid.NewGuid().ToString("N") + ".zip");
        using (var z = ZipFile.Open(file, ZipArchiveMode.Create)) foreach (string path in paths) z.CreateEntry(path);
        try { WallpaperPackages.Inspect(file); throw new Exception(label + " accepted"); }
        catch (InvalidDataException) { Console.WriteLine("PASS " + label); }
        string dest = Path.Combine(root, Guid.NewGuid().ToString("N"));
        try { WallpaperPackages.Import(file, dest); throw new Exception(label + " imported"); }
        catch (InvalidDataException) { Assert(!Directory.Exists(dest), label + " rejected before extraction"); }
    }
    RejectArchive("multiple wrapper roots", "one/index.html", "two/index.html");
    RejectArchive("stray wrapper content", "one/index.html", "README.txt");
    RejectArchive("file as parent", "index.html", "a", "a/x.txt");
    RejectArchive("case ambiguous parent", "index.html", "Assets/a.png", "assets/b.png");
    RejectArchive("superscript device", "index.html", "COM¹.txt");
    RejectArchive("reserved console", "index.html", "CONOUT$.txt");
    RejectArchive("too deep", "index.html", string.Join('/', Enumerable.Repeat("d", 33)) + "/file");
    string upperZip = Path.Combine(root,"uppercase.zip");
    using (var z = ZipFile.Open(upperZip, ZipArchiveMode.Create)) { z.CreateEntry("Wrap/"); z.CreateEntry("Wrap/INDEX.HTML"); z.CreateEntry("Wrap/assets/a.txt"); }
    string upperIndex = WallpaperPackages.Import(upperZip);
    Assert(File.Exists(upperIndex) && Path.GetFileName(upperIndex)=="index.html", "uppercase entry point canonicalized");
    Assert(WallpaperPackages.VerifyAgainstArchive(upperIndex,upperZip).Matches,"canonical entry point verifies");
    string specialZip = Path.Combine(root,"special.zip");
    using (var z = ZipFile.Open(specialZip, ZipArchiveMode.Create)) { z.CreateEntry("index.html"); z.CreateEntry("fifo").ExternalAttributes = 0x1000 << 16; }
    try { WallpaperPackages.Inspect(specialZip); throw new Exception("FIFO accepted"); }
    catch (InvalidDataException) { Console.WriteLine("PASS special Unix entry refused"); }
    var unsafeZip = Path.Combine(root,"unsafe.zip");
    using (var archive = ZipFile.Open(unsafeZip, ZipArchiveMode.Create)) { archive.CreateEntry("../bad"); archive.CreateEntry("index.html"); }
    try { WallpaperPackages.VerifyAgainstArchive(repaired,unsafeZip); throw new Exception("unsafe ZIP accepted"); }
    catch (InvalidDataException) { Console.WriteLine("PASS unsafe ZIP refused"); }
}
finally { Directory.Delete(root, true); }
