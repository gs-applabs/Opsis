using MotionDesk.Widgets;
static void Assert(bool value,string label) { if(!value) throw new Exception(label); Console.WriteLine("PASS "+label); }
var topology=new MonitorScenePolicy.Display[]{new("PnP-A","DISPLAY1"),new("PnP-B","DISPLAY2")};
var key=MonitorScenePolicy.Key(topology,"DISPLAY1")!;
Assert(key=="id:PNP-A","stable normalized key");
Assert(MonitorScenePolicy.Key(new[]{new MonitorScenePolicy.Display("PnP-A","DISPLAY3")},"DISPLAY3")==key,"renumbering keeps identity");
Assert(MonitorScenePolicy.Key(new[]{new MonitorScenePolicy.Display("PnP-A","DISPLAY1"),new("PnP-A","DISPLAY2")},"DISPLAY1")==null,"ambiguous IDs refused");
Assert(MonitorScenePolicy.Key(new[]{new MonitorScenePolicy.Display("DISPLAY1","DISPLAY1")},"DISPLAY1")==null,"device-only identity refused");
Assert(MonitorScenePolicy.Key(topology,"DISPLAY3")==null,"no nearest match");
var map=new Dictionary<string,MonitorSceneChoice>{{key,new("Weather","Mountain Lake")}};
string Normal(string? s)=>s is "Classic" or "Mountain Lake" ? s : "Classic";
bool Studio(string s)=>s=="Studio Aurora";
MonitorSceneChoice Resolve(string mode,string? k)=>MonitorScenePolicy.Resolve(mode,"Classic",k,map,Studio,Normal);
Assert(Resolve("Weather",key).Scene=="Mountain Lake","assigned scene");
Assert(Resolve("Weather","id:PNP-B").Scene=="Classic","unassigned uses common scene");
Assert(Resolve("Video",key).Mode=="Video" && Resolve("Desktop",key).Mode=="Desktop","global media and overlay preserved");
map[key]=new("Studio Aurora","bogus"); Assert(Resolve("Weather",key)==new MonitorSceneChoice("Studio Aurora","Classic"),"studio selection");
map[key]=new("Page","Classic"); Assert(Resolve("Weather",key).Mode=="Weather","HTML rejected");
map[key]=new("Weather","invalid"); Assert(Resolve("Weather",key).Scene=="Classic","unknown scene fallback");
