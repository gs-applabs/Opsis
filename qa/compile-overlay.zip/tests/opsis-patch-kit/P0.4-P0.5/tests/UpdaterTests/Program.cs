using System.Text.Json;
using MotionDesk.Services;

static string Release(string tag, bool draft = false, bool pre = false) => JsonSerializer.Serialize(new {
    tag_name = tag, draft, prerelease = pre,
    html_url = "https://github.com/gs-applabs/Opsis/releases/tag/" + tag,
    assets = new[] { new { name = "OpsisSetup.exe", browser_download_url = "https://github.com/gs-applabs/Opsis/releases/download/" + tag + "/OpsisSetup.exe", digest = "sha256:" + new string('a',64) } }
});
static UpdateCheckService.UpdateInfo? Select(params string[] releases) {
    using var doc = JsonDocument.Parse("[" + string.Join(",", releases) + "]");
    return UpdateCheckService.SelectAppRelease(doc.RootElement, new Version(2,8,0,2510));
}
static void Check(bool ok, string description) { if(!ok) throw new Exception(description); Console.WriteLine("PASS: " + description); }
Check(Select(Release("wallpapers-addon-v9.0.0"),Release("v3.0.0.3200"))?.Version == new Version(3,0,0,3200), "addon before stable app");
Check(Select(Release("v3.0.0.3200"),Release("v3.1.0.4000"))?.Version == new Version(3,1,0,4000), "highest app version");
Check(Select(Release("v9.0.0.0",draft:true),Release("v8.0.0.0",pre:true),Release("v7.0.0-preview")) == null, "draft and prerelease exclusion");
Check(Select(Release("v2.8.0.2510"), Release("v2.7.0.0")) == null,"no downgrade");
Check(Select(Release("v3.0.0.3200"))?.CanInstallAutomatically == true,"checksum-qualified installer");
namespace MotionDesk.Services {
    // Test-only stubs; no settings writes or network calls.
    public static class AppVersion { public static Version Number => new(2,8,0,2510); }
    public sealed class AppSettings { public bool UpdateCheckEnabled {get;set;} public DateTime LastUpdateCheckUtc {get;set;} public static AppSettings Load()=>new(); public void Save() {} }
}
