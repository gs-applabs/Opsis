#!/usr/bin/env python3
"""Create a deterministic, offline authoring payload from reviewed scenes only.
This is not a runtime installer or an archaeological approval mechanism.
"""
import argparse, hashlib, json, os, pathlib, re, stat, sys, tempfile, zipfile
from PIL import Image, ImageChops, ImageStat
from validate_scene import check, safe, sha, ROLES
HERE=pathlib.Path(__file__).resolve().parent
MAX_MANIFEST=256*1024; MAX_PACK=2*1024**3
POLARITY={'skyMask':'white-sky','foregroundMask':'white-foreground','occlusionMask':'white-occluder'}

def linked(path):
    info=path.lstat()
    return path.is_symlink() or bool(getattr(info,'st_file_attributes',0) & getattr(stat,'FILE_ATTRIBUTE_REPARSE_POINT',0x400))

def unique_object(items):
    result={}
    for key,value in items:
        if key in result:raise ValueError('duplicate JSON key: '+key)
        result[key]=value
    return result

def read_json(path):
    if not path.exists() or linked(path) or not path.is_file() or path.stat().st_size>MAX_MANIFEST:raise ValueError(f'not a bounded regular JSON: {path}')
    raw=path.read_bytes()
    if len(raw)>MAX_MANIFEST:raise ValueError('JSON grew beyond limit')
    data=json.loads(raw,object_pairs_hook=unique_object)
    if not isinstance(data,dict):raise ValueError('JSON object required')
    return raw,data

def approved_entries(approvals, backlog):
    if approvals.get('schema')!=1 or not isinstance(approvals.get('entries'),list):raise ValueError('approval schema 1 required')
    known={e['id'] for e in backlog['entries']}; seen=set(); result=[]
    for e in approvals['entries']:
        if not isinstance(e,dict) or e.get('id') not in known or e['id'] in seen:raise ValueError('unknown or duplicate approval ID')
        if not isinstance(e.get('manifestSha256'),str) or not re.fullmatch('[a-fA-F0-9]{64}',e['manifestSha256']):raise ValueError('approval must bind exact manifest SHA-256')
        if not isinstance(e.get('approvalReference'),str) or not e['approvalReference'].strip():raise ValueError('missing approval reference')
        seen.add(e['id']);result.append(e)
    if not result:raise ValueError('no approved scenes selected; no package produced')
    return sorted(result,key=lambda x:x['id'])

def mask_geometry(root,manifest):
    if manifest.get('maskPolarity')!=POLARITY:raise ValueError('explicit mask polarity contract required')
    masks={}
    for role in POLARITY:
        with Image.open(safe(root,manifest['assets'][role]['path'])) as im:
            if 'A' in im.getbands() and im.getchannel('A').getextrema()!=(255,255):raise ValueError(role+' must be opaque grayscale (not alpha-coded)')
            masks[role]=im.convert('L')
    # Only the selected production convention: sky and foreground partition the frame;
    # occluders may be a subset of foreground. Small anti-aliasing differences allowed.
    sky,fg,occ=(masks[r] for r in POLARITY)
    gap=ImageStat.Stat(ImageChops.difference(ImageChops.invert(sky),fg)).mean[0]
    overlap=ImageStat.Stat(ImageChops.multiply(sky,occ)).mean[0]
    if gap>2 or overlap>1.5:raise ValueError(f'inconsistent masks (mean complement error {gap:.3f}; sky/occluder overlap {overlap:.3f})')
    return {'complementMeanError':round(gap,4),'skyOccluderMeanOverlap':round(overlap,4)}

def zi(name):
    x=zipfile.ZipInfo(name,date_time=(1980,1,1,0,0,0));x.compress_type=zipfile.ZIP_STORED;x.external_attr=0o100644<<16;return x

def digest_bytes(b):return hashlib.sha256(b).hexdigest()

def build(root,approval_path,output,backlog_path=HERE/'production-backlog.json'):
    root=root.resolve();output=output.parent.resolve()/output.name;approval_path=approval_path.absolute()
    if output.exists() or output.is_symlink() or output.is_relative_to(root):raise ValueError('new output outside input tree required')
    if not output.parent.is_dir():raise ValueError('output parent missing')
    if approval_path.resolve().is_relative_to(root):raise ValueError('approval ledger must be external to source scene tree')
    _,approvals=read_json(approval_path);_,backlog=read_json(backlog_path)
    selected=approved_entries(approvals,backlog);records=[];plans=[];total=0
    for e in selected:
        scene=root/e['id']
        if not scene.is_dir() or linked(scene):raise ValueError('scene folder missing or linked: '+e['id'])
        raw,d=read_json(scene/'manifest.json')
        if digest_bytes(raw)!=e['manifestSha256'].lower() or d.get('approvalReference')!=e['approvalReference'] or d.get('id')!=e['id']:raise ValueError('approval does not match manifest: '+e['id'])
        errors=check(scene,d)
        if errors:raise ValueError(e['id']+': '+'; '.join(errors))
        geometry=mask_geometry(scene,d);prefix='living-history/'+e['id']+'/'
        records.append({'id':e['id'],'manifestSha256':digest_bytes(raw),'approvalReference':e['approvalReference'],'maskChecks':geometry,'roles':{}})
        plans.append((prefix+'manifest.json',raw,None,digest_bytes(raw)));total+=len(raw)
        for role in ROLES:
            a=d['assets'][role];p=safe(scene,a['path']);name=prefix+a['path'];size=p.stat().st_size;total+=size
            if total>MAX_PACK:raise ValueError('pack exceeds 2 GiB authoring budget')
            records[-1]['roles'][role]={'path':name,'sha256':a['sha256'].lower(),'bytes':size}
            plans.append((name,None,p,a['sha256'].lower()))
    names=[p[0].casefold() for p in plans]
    if len(set(names))!=len(names):raise ValueError('duplicate output paths')
    index={'schema':1,'kind':'living-history-authoring-payload','runtimeInstalled':False,'releaseApproved':False,'entries':records}
    index_raw=(json.dumps(index,ensure_ascii=False,sort_keys=True,indent=2)+'\n').encode()
    fd,temp=tempfile.mkstemp(prefix='.history-',suffix='.zip',dir=output.parent);os.close(fd);temp=pathlib.Path(temp)
    try:
        with zipfile.ZipFile(temp,'w',allowZip64=True) as z:
            z.writestr(zi('living-history-index.json'),index_raw)
            actual=0
            for name,raw,p,expected in sorted(plans,key=lambda x:x[0]):
                if raw is not None:z.writestr(zi(name),raw);actual+=len(raw);continue
                h=hashlib.sha256();n=0
                with p.open('rb') as src,z.open(zi(name),'w',force_zip64=True) as dst:
                    for block in iter(lambda:src.read(1024*1024),b''):
                        n+=len(block);actual+=len(block)
                        if n>64*1024**2 or actual>MAX_PACK:raise ValueError('file grew beyond budget')
                        h.update(block);dst.write(block)
                if h.hexdigest()!=expected:raise ValueError('asset changed after validation: '+name)
        with zipfile.ZipFile(temp) as z:
            if z.testzip() is not None or len(z.namelist())!=len(plans)+1:raise ValueError('ZIP verification failed')
        # Same-filesystem exclusive publication, never overwrite a prior artifact.
        os.link(temp,output)
    finally:temp.unlink(missing_ok=True)
    return {'scenes':len(records),'files':len(plans)+1,'bytes':output.stat().st_size,'sha256':sha(output),'runtimeInstalled':False,'releaseApproved':False}

def main():
    p=argparse.ArgumentParser();p.add_argument('scenes',type=pathlib.Path);p.add_argument('approvals',type=pathlib.Path);p.add_argument('output',type=pathlib.Path);a=p.parse_args()
    try:print(json.dumps(build(a.scenes,a.approvals,a.output),ensure_ascii=False,indent=2))
    except (ValueError,OSError,KeyError,TypeError) as e:print('FAILED: '+str(e),file=sys.stderr);return 1
    return 0
if __name__=='__main__':sys.exit(main())
