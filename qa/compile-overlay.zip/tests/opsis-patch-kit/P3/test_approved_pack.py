import copy,json,pathlib,tempfile,unittest,zipfile,hashlib
from PIL import Image,ImageDraw,ImageOps
from build_approved_pack import build, mask_geometry, POLARITY, approved_entries, read_json
from validate_scene import sha,ROLES
class T(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.tmp=tempfile.TemporaryDirectory();cls.root=pathlib.Path(cls.tmp.name);cls.scenes=cls.root/'scenes';cls.scene=cls.scenes/'giza';cls.scene.mkdir(parents=True)
  assets={};sky=Image.new('L',(3840,2160),0);ImageDraw.Draw(sky).rectangle((0,0,3839,800),fill=255)
  occ=Image.new('L',sky.size,0);ImageDraw.Draw(occ).rectangle((1100,900,2400,1900),fill=255)
  for i,role in enumerate(ROLES):
   p=cls.scene/(role+'.webp');im={'skyMask':sky,'foregroundMask':ImageOps.invert(sky),'occlusionMask':occ}.get(role)
   if im is None:im=Image.new('RGB',(320,180) if role=='poster' else (3840,2160),(i*24,10,20))
   im.save(p,format='WEBP',lossless=True,method=0);assets[role]={'path':p.name,'sha256':sha(p)}
  cls.d={'id':'giza','status':'approved','approved':True,'approvalReference':'TEST FIXTURE — NOT HISTORICAL APPROVAL','period':'synthetic fixture','viewpoint':dict(lat=0,lon=0,azimuth=90,fov=60,cameraHeightM=2,reference='fixture'),'singleViewpoint':True,'sources':[dict(url='fixture',scope='test',license='test',attribution='test')]*2,'uncertainty':['fixture'],'geometryReviewed':True,'weatherOcclusionReviewed':True,'assets':assets,'nativeResolution':True,'maskPolarity':POLARITY}
 @classmethod
 def tearDownClass(cls):cls.tmp.cleanup()
 def prepare(self,d=None):
  d=copy.deepcopy(d or self.d);m=self.scene/'manifest.json';m.write_text(json.dumps(d));a=self.root/'approvals.json';a.write_text(json.dumps({'schema':1,'entries':[{'id':'giza','manifestSha256':sha(m),'approvalReference':d['approvalReference']}]}));return m,a
 def test_pack_and_reproducibility(self):
  _,a=self.prepare();out=self.root/'one.zip';other=self.root/'two.zip';r=build(self.scenes,a,out);s=build(self.scenes,a,other);self.assertEqual(r['sha256'],s['sha256']);self.assertEqual(r['files'],10)
  with zipfile.ZipFile(out) as z:self.assertIsNone(z.testzip());self.assertFalse(json.loads(z.read('living-history-index.json'))['runtimeInstalled'])
  with self.assertRaises(ValueError):build(self.scenes,a,out)
 def test_no_approval(self):
  _,a=self.prepare();a.write_text('{"schema":1,"entries":[]}');out=self.root/'empty.zip'
  with self.assertRaises(ValueError):build(self.scenes,a,out)
  self.assertFalse(out.exists())
 def test_mismatch(self):
  m,a=self.prepare();m.write_text(m.read_text()+' ')
  with self.assertRaisesRegex(ValueError,'approval does not match'):build(self.scenes,a,self.root/'mismatch.zip')
 def test_mask_mismatch(self):
  d=copy.deepcopy(self.d);d['assets']['foregroundMask']=d['assets']['skyMask']
  with self.assertRaisesRegex(ValueError,'inconsistent masks'):mask_geometry(self.scene,d)
 def test_wrong_polarity(self):
  d=copy.deepcopy(self.d);d['maskPolarity']={}
  with self.assertRaisesRegex(ValueError,'polarity'):mask_geometry(self.scene,d)
 def test_unapproved_manifest(self):
  d=copy.deepcopy(self.d);d['approved']=False;_,a=self.prepare(d)
  with self.assertRaisesRegex(ValueError,'explicit user approval'):build(self.scenes,a,self.root/'unapproved.zip')
 def test_duplicate_json_key(self):
  p=self.root/'duplicate.json';p.write_text('{"schema":1,"schema":2}')
  with self.assertRaisesRegex(ValueError,'duplicate JSON key'):read_json(p)
 def test_duplicate_approval(self):
  _,a=self.prepare();x=json.loads(a.read_text());x['entries']*=2
  with self.assertRaisesRegex(ValueError,'duplicate'):approved_entries(x,{'entries':[{'id':'giza'}]})
if __name__=='__main__':unittest.main(verbosity=2)
