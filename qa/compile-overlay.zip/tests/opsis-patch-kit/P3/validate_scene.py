#!/usr/bin/env python3
"""Offline preflight only. No archaeology/visual approval is inferred from passing checks."""
import argparse, hashlib, json, math, pathlib, re, stat, sys
from PIL import Image
ROLES=('day','golden','blue','night','skyMask','foregroundMask','occlusionMask','poster')
MAX_BYTES=64*1024*1024

def safe(root, rel):
    if not isinstance(rel,str) or not rel or '\\' in rel or ':' in rel or rel.startswith('/') or any(p in ('','.','..') for p in rel.split('/')): raise ValueError('unsafe relative path')
    p=root
    for part in rel.split('/'):
        p=p/part
        if p.is_symlink() or (p.exists() and getattr(p.lstat(),'st_file_attributes',0) & getattr(stat,'FILE_ATTRIBUTE_REPARSE_POINT',0x400)): raise ValueError('linked path')
    if not p.is_file() or not p.resolve().is_relative_to(root.resolve()) or p.stat().st_size>MAX_BYTES: raise ValueError('missing/outside/oversize file')
    return p

def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
    return h.hexdigest()

def require(cond,msg):
    if not cond: raise ValueError(msg)

def check(root,d):
    errors=[]
    def need(cond,msg):
        if not cond: errors.append(msg)
    need(d.get('status')=='approved' and d.get('approved') is True,'explicit user approval missing')
    need(isinstance(d.get('approvalReference'),str) and bool(d['approvalReference'].strip()),'approval evidence missing')
    need(isinstance(d.get('id'),str) and bool(re.fullmatch(r'[a-z0-9-]{1,60}',d['id'])),'invalid id')
    need(bool(d.get('period')),'historical period missing')
    v=d.get('viewpoint') or {}; need(isinstance(v,dict),'invalid viewpoint');v=v if isinstance(v,dict) else {}
    for key,lo,hi in [('lat',-90,90),('lon',-180,180),('azimuth',0,360),('fov',1,179),('cameraHeightM',0.1,10000)]:
        n=v.get(key);need(type(n) in (float,int) and math.isfinite(n) and lo<=n<=hi,f'viewpoint {key} missing/invalid')
    need(bool(v.get('reference')) and d.get('singleViewpoint') is True,'single viewpoint/reference missing')
    sources=d.get('sources');need(isinstance(sources,list) and len(sources)>=2,'at least two source records required')
    for s in sources if isinstance(sources,list) else []:
        need(isinstance(s,dict) and all(isinstance(s.get(k),str) and s[k].strip() for k in ('url','scope','license','attribution')),'source rights/attribution incomplete')
    need(isinstance(d.get('uncertainty'),list) and bool(d['uncertainty']),'historical uncertainty register missing')
    need(d.get('geometryReviewed') is True,'geometry review missing')
    need(d.get('weatherOcclusionReviewed') is True,'weather/occlusion review missing')
    assets=d.get('assets') or {};assets=assets if isinstance(assets,dict) else {}
    expected=(3840,2160); seen=set()
    for role in ROLES:
        try:
            a=assets[role]; p=safe(root,a['path']); require(p.suffix.lower()=='.webp','not WebP');require(p not in seen,'duplicate role file');seen.add(p)
            require(sha(p)==a['sha256'].lower(),'SHA-256 mismatch')
            with Image.open(p) as im:
                require(im.format=='WEBP' and not getattr(im,'is_animated',False),'not still WebP')
                require(im.width*im.height<=3840*2160,'image over pixel budget')
                im.load()
                if role!='poster': require(im.size==expected,'expected 3840×2160')
                else: require(im.width*9==im.height*16 and im.width>=320,'poster aspect/size')
                if role.endswith('Mask'):
                    require(im.mode in ('L','RGB','RGBA'),'mask channels')
                    if im.mode!='L':
                        rgb=im.convert('RGB');r,g,b=rgb.split();from PIL import ImageChops
                        require(not ImageChops.difference(r,g).getbbox() and not ImageChops.difference(r,b).getbbox(),'mask not grayscale')
                    lo,hi=im.convert('L').getextrema(); require(lo<32 and hi>223,'empty/degenerate mask')
        except (KeyError,TypeError,AttributeError,ValueError,OSError,AssertionError) as e: errors.append(f'{role}: {e}')
    need(d.get('nativeResolution') is True or (d.get('nativeResolution') is False and bool(d.get('upscaleDisclosure'))),'native/upscale disclosure missing')
    return errors

def main():
    p=argparse.ArgumentParser();p.add_argument('manifest',type=pathlib.Path);a=p.parse_args();d=json.loads(a.manifest.read_text(encoding='utf-8'));es=check(a.manifest.parent,d)
    print(json.dumps({'id':d.get('id'),'passed':not es,'errors':es},ensure_ascii=False,indent=2));return 1 if es else 0
if __name__=='__main__':sys.exit(main())
