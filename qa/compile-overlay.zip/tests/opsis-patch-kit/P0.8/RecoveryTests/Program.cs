using MotionDesk.Widgets;
static void Assert(bool value, string label) { if (!value) throw new Exception(label); Console.WriteLine("PASS " + label); }
var one = new RecoveryBudget(); var two = new RecoveryBudget();
Assert(one.NextDelay(0) == 1000, "first delay");
Assert(one.NextDelay(1000) == 2000, "second delay");
Assert(one.NextDelay(3000) == 4000, "third delay");
Assert(one.NextDelay(7000) == 8000, "fourth delay");
Assert(one.NextDelay(15000) == null, "bounded budget");
Assert(two.NextDelay(15000) == 1000, "monitor isolation");
Assert(one.NextDelay(120000) == 8000, "sliding window");
Assert(one.NextDelay(250000) == 1000, "expired attempts reset");
