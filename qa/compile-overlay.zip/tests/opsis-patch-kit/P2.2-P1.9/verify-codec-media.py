#!/usr/bin/env python3
"""Read-only preflight binding benchmark reports to the actual local media.
No runtime variant selection or hardware decoding inference.
"""
import argparse, hashlib, importlib.util, json, math, pathlib, re, subprocess, sys
from fractions import Fraction
HERE=pathlib.Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('rank',HERE.parent/'P0.10-P1.8/rank-codec-benchmarks.py');ranker=importlib.util.module_from_spec(spec);spec.loader.exec_module(ranker)
MAX_BYTES=8*1024**3
FORMATS={'.mp4':'mov','.m4v':'mov','.webm':'matroska','.mkv':'matroska'}
def local(root,name):
    if not isinstance(name,str) or not name or len(name)>240 or '\\' in name or ':' in name:raise ValueError('invalid relative media path')
    p=pathlib.PurePosixPath(name)
    if p.is_absolute() or any(x in ('','.','..') for x in name.split('/')):raise ValueError('unsafe path')
    candidate=root
    for part in p.parts:
        candidate=candidate/part
        if candidate.is_symlink() or getattr(candidate,'is_junction',lambda:False)():raise ValueError('linked media path')
    if not candidate.is_file() or not candidate.resolve().is_relative_to(root):raise ValueError('missing or outside media root')
    if candidate.suffix.lower() not in FORMATS:raise ValueError('unsupported benchmark container')
    return candidate

def digest(path):
    h=hashlib.sha256();n=0
    with path.open('rb') as f:
        while chunk:=f.read(1024**2):
            n+=len(chunk)
            if n>MAX_BYTES:raise ValueError('media exceeds hash budget')
            h.update(chunk)
    return h.hexdigest(),n

def inspect(path,ffprobe):
    before=path.stat()
    if not 0<before.st_size<=MAX_BYTES:raise ValueError('invalid media size')
    sha,n=digest(path)
    cmd=[ffprobe,'-v','error','-protocol_whitelist','file','-f',FORMATS[path.suffix.lower()],'-show_entries','stream=codec_type,codec_name,width,height,avg_frame_rate,r_frame_rate:stream_disposition=attached_pic:format=duration','-of','json',str(path)]
    p=subprocess.run(cmd,capture_output=True,timeout=30,check=True)
    if len(p.stdout)>1024*1024:raise ValueError('probe report too large')
    data=json.loads(p.stdout);video=[s for s in data['streams'] if s.get('codec_type')=='video' and not s.get('disposition',{}).get('attached_pic',0)]
    if len(video)!=1:raise ValueError('one video stream required')
    v=video[0];fps=float(Fraction(v['avg_frame_rate']));duration=float(data['format']['duration'])
    if not math.isfinite(fps) or not math.isfinite(duration) or min(fps,duration,int(v['width']),int(v['height']))<=0:raise ValueError('invalid actual media metadata')
    after=path.stat()
    if (before.st_size,before.st_mtime_ns,before.st_ino)!=(after.st_size,after.st_mtime_ns,after.st_ino) or n!=before.st_size:raise ValueError('media changed during preflight')
    return {'sha256':sha,'bytes':n,'codec':v['codec_name'],'width':int(v['width']),'height':int(v['height']),'fps':fps,'seconds':duration}

def verify(manifest,root,ffprobe='ffprobe'):
    root=root.resolve();vs=manifest.get('variants')
    if not isinstance(vs,list) or not 1<=len(vs)<=16:raise ValueError('1–16 variants required')
    result=[];seen=set();hashes=set()
    for variant in vs:
        path=local(root,variant.get('media'))
        if path.resolve() in seen:raise ValueError('duplicate media path')
        seen.add(path.resolve());expected=variant.get('sha256','')
        if not isinstance(expected,str) or not re.fullmatch('[a-fA-F0-9]{64}',expected):raise ValueError('variant SHA-256 required')
        measured=inspect(path,ffprobe)
        if measured['sha256']!=expected.lower():raise ValueError('media hash mismatch: '+variant['id'])
        if measured['sha256'] in hashes:raise ValueError('duplicate media content')
        hashes.add(measured['sha256'])
        if any(variant.get(k)!=measured[k] for k in ('codec','width','height')) or abs(ranker.number(variant['fps'])-measured['fps'])>.1 or abs(ranker.number(variant['seconds'])-measured['seconds'])>.25:raise ValueError('declared media metadata mismatch: '+variant['id'])
        runs=variant.get('runs')
        if not isinstance(runs,list) or not 2<=len(runs)<=8 or any(r.get('mediaSha256','').lower()!=measured['sha256'] for r in runs):raise ValueError('each run must declare the matching media hash')
        result.append({'id':variant['id'],**measured})
    return result

def main():
    p=argparse.ArgumentParser();p.add_argument('manifest',type=pathlib.Path);p.add_argument('--ffprobe',default='ffprobe');a=p.parse_args()
    try:
        if a.manifest.stat().st_size>256*1024:raise ValueError('manifest too large')
        m=json.loads(a.manifest.read_text(encoding='utf-8-sig'));root=a.manifest.resolve().parent
        verified=verify(m,root,a.ffprobe);r=ranker.rank(m,root);r.update(mediaVerified=verified,verifiedPlayback=False)
        print(json.dumps(r,indent=2,ensure_ascii=False))
    except (ValueError,TypeError,KeyError,AttributeError,OSError,ArithmeticError,subprocess.SubprocessError) as e:print('FAILED: '+str(e),file=sys.stderr);return 1
    return 0
if __name__=='__main__':sys.exit(main())
