import importlib.util,pathlib,tempfile,subprocess,unittest,hashlib,copy,shutil
HERE=pathlib.Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('verified',HERE/'verify-codec-media.py');v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
@unittest.skipUnless(shutil.which('ffmpeg') and shutil.which('ffprobe'),'FFmpeg required')
class Tests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.tmp=tempfile.TemporaryDirectory();cls.root=pathlib.Path(cls.tmp.name);cls.data={'variants':[]}
  for id,codec,file,encoder in [('a','h264','master.mp4','libx264'),('b','vp9','candidate.webm','libvpx-vp9')]:
   p=cls.root/file;subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-f','lavfi','-i','testsrc2=size=128x72:rate=30','-t','1','-c:v',encoder,'-threads','2','-an',str(p)],check=True,timeout=30)
   h=hashlib.sha256(p.read_bytes()).hexdigest();cls.data['variants'].append({'id':id,'media':file,'sha256':h,'codec':codec,'width':128,'height':72,'fps':30,'seconds':1,'runs':[{'mediaSha256':h},{'mediaSha256':h}]})
 @classmethod
 def tearDownClass(cls):cls.tmp.cleanup()
 def test_valid(self):self.assertEqual([x['codec'] for x in v.verify(self.data,self.root)],['h264','vp9'])
 def invalid(self,key,val):
  d=copy.deepcopy(self.data);d['variants'][1][key]=val
  with self.assertRaises(ValueError):v.verify(d,self.root)
 def test_hash(self):self.invalid('sha256','0'*64)
 def test_codec(self):self.invalid('codec','av1')
 def test_fps(self):self.invalid('fps',60)
 def test_resolution(self):self.invalid('width',1920)
 def test_duration(self):self.invalid('seconds',60)
 def test_nan_fps(self):self.invalid('fps',float('nan'))
 def test_escape(self):self.invalid('media','../candidate.webm')
 def test_run_hash(self):self.invalid('runs',[{'mediaSha256':'0'*64},{'mediaSha256':'0'*64}])
 def test_duplicate_path(self):self.invalid('media','master.mp4')
 def test_link(self):
  p=self.root/'link.webm'
  try:p.symlink_to(self.root/'candidate.webm')
  except OSError:self.skipTest('links not available')
  try:self.invalid('media','link.webm')
  finally:p.unlink()
if __name__=='__main__':unittest.main(verbosity=2)
