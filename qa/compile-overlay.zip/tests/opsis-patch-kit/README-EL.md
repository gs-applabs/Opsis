# OPSIS — Ενοποιημένοι έλεγχοι και εργαλεία

Το `Opsis/` είναι ήδη ενημερωμένο. Δεν χρειάζεται επανεφαρμογή των 25 επιμέρους patches. Τα 9 C# projects διαβάζουν τον πραγματικό πηγαίο κώδικα μέσω `-p:OpsisRepo=...`.

Σε Windows, με εγκατεστημένο .NET 11 SDK, Git και Node, από καθαρό committed checkout του ενοποιημένου source:

```powershell
python tests/opsis-patch-kit/P5/run-windows-gates.py . ../opsis-qa-report
```

Προαιρετικά `--iscc` με τη διαδρομή του Inno Setup compiler. Πρόκειται για development gate, όχι έγκριση production. Το `run-ui-smoke.py` είναι ξεχωριστό εργαλείο. Ο Chromium έλεγχος απαιτεί Python Playwright και Linux chromium (`/usr/bin/chromium`) και χρησιμοποιεί inlined scripts και mock bridge, όχι WebView2. Τα P3 / P3.2 είναι εργαλεία παραγωγής εγκεκριμένων assets, όχι τελικά ιστορικά σκηνικά. Τα P0.10-P1.8 / P2.2-P1.9 είναι εργαλεία αξιολόγησης codec και media, όχι αυτόματη επιλογή codec.
