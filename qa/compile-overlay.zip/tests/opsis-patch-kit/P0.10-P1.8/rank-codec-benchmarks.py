#!/usr/bin/env python3
"""Read-only ranking of actual playback benchmark CSVs (Measure-Opsis.ps1).
No transcoding, hardware decoding claims, runtime switching or deletion.
"""
import argparse, csv, json, math, statistics, pathlib, sys
METRICS=('CpuPctMachine','Gpu3DEngineSumPct','GpuDecodeEngineSumPct','PrivateWorkingSetBytes')
CODECS={'h264','vp9','av1','hevc'}

def number(x):
    n=float(x)
    if not math.isfinite(n) or n<0:raise ValueError('invalid numeric measurement')
    return n

def samples(path,expected_scenario):
    if path.stat().st_size>4*1024*1024:raise ValueError('CSV too large')
    with path.open(encoding='utf-8-sig',newline='') as f:
        rows=list(csv.DictReader(f))
    if not 12<=len(rows)<=10000:raise ValueError('need 12–10000 samples')
    t=[number(r['ElapsedSeconds']) for r in rows]
    if any(b<=a for a,b in zip(t,t[1:])) or t[-1]-t[0]<55:raise ValueError('need >=55 s of monotonically increasing samples')
    # First 10 seconds are warmup. Require actual GPU observations, not missing treated as 0.
    used=[r for r,x in zip(rows,t) if x-t[0]>=10]
    if len(used)<8:raise ValueError('insufficient steady-state samples')
    if {r.get('Scenario') for r in rows}!={expected_scenario}:raise ValueError('scenario CSV identity mismatch')
    return {k:statistics.median(number(r[k]) for r in used) for k in METRICS}

def rank(manifest,root):
    if not isinstance(manifest,dict) or manifest.get('schema')!=1:raise ValueError('unsupported benchmark schema')
    device=manifest.get('device');clip=manifest.get('clip');variants=manifest.get('variants');master=manifest.get('master')
    if not isinstance(device,str) or not device.strip() or not isinstance(clip,str) or not clip.strip():raise ValueError('device and logical clip required')
    if not isinstance(variants,list) or not 1<=len(variants)<=16:raise ValueError('1–16 variants required')
    if any(not isinstance(v,dict) or not isinstance(v.get('id'),str) for v in variants):raise ValueError('invalid variant entries')
    if len({v.get('id') for v in variants})!=len(variants):raise ValueError('duplicate IDs')
    byid={v['id']:v for v in variants}
    if master not in byid:raise ValueError('unknown master')
    m=byid[master]; mw,mh,mfps,md=[number(m[k]) for k in ('width','height','fps','seconds')]
    if min(mw,mh,mfps,md)<=0:raise ValueError('invalid master media metadata')
    results=[]; seen=set()
    for v in variants:
        rid=v['id']; row={'id':rid,'codec':v.get('codec'),'eligible':False}
        try:
            if not isinstance(rid,str) or not rid.strip() or len(rid)>120 or v.get('codec') not in CODECS:raise ValueError('invalid ID or codec')
            if v.get('sameContentReviewed') is not True:raise ValueError('content equivalence not reviewed')
            w,h,fps,d=[number(v[k]) for k in ('width','height','fps','seconds')]
            if w!=mw or h!=mh or abs(fps-mfps)>.1 or abs(d-md)>.25:raise ValueError('resolution/FPS/duration mismatch; preserve master quality')
            if not isinstance(v.get('runs'),list) or not 2<=len(v['runs'])<=8 or any(not isinstance(r,dict) for r in v['runs']):raise ValueError('2–8 repeated runs required')
            runmetrics=[];drops=[]
            for run in v['runs']:
                if run.get('device')!=device or run.get('clip')!=clip or run.get('variant')!=rid:raise ValueError('inconsistent run identity')
                # Decoder support from browser is advisory; failed playback is never eligible.
                if run.get('playbackSucceeded') is not True:raise ValueError('playback not confirmed')
                total=number(run['totalFrames']);dropped=number(run['droppedFrames'])
                if total<300 or dropped>total or total%1 or dropped%1:raise ValueError('insufficient or invalid frame counts')
                drops.append(dropped/total)
                name=run['csv'];p=(root/name).resolve()
                if not p.is_relative_to(root.resolve()) or p in seen or not p.is_file():raise ValueError('CSV missing, reused or outside report directory')
                seen.add(p);runmetrics.append(samples(p,rid))
            if max(drops)>.005:raise ValueError('dropped-frame ratio exceeds 0.5%')
            row.update(eligible=True,metrics={k:round(statistics.median(r[k] for r in runmetrics),4) for k in METRICS},maxDropRatio=round(max(drops),6))
        except (ValueError,TypeError,KeyError,OSError) as exc:row['reason']=str(exc)
        results.append(row)
    baseline=next(x for x in results if x['id']==master)
    # Conservative Pareto decision: lower CPU by >=0.3 pp, OR lower combined GPU engine sum by >=2 pp,
    # no material regression in the other metric, no >16 MiB private working-set regression.
    # Engine sums are not normalized GPU utilization and not hardware decoder proof.
    recommendation=master if baseline['eligible'] else None
    if baseline['eligible']:
        b=baseline['metrics'];bg=b[METRICS[1]]+b[METRICS[2]]
        winners=[]
        for r in results:
            if not r['eligible'] or r['id']==master:continue
            v=r['metrics'];vg=v[METRICS[1]]+v[METRICS[2]];cpu_gain=b[METRICS[0]]-v[METRICS[0]];gpu_gain=bg-vg
            if (cpu_gain>=.3 or gpu_gain>=2) and cpu_gain>=-.15 and gpu_gain>=-1 and v[METRICS[3]]<=b[METRICS[3]]+16*1024*1024:
                winners.append((cpu_gain/.3+gpu_gain/2,r['id']))
        if winners:recommendation=max(winners)[1]
    return {'device':device,'clip':clip,'master':master,'recommendation':recommendation,'automaticRuntimeSwitch':False,'hardwareDecodeVerified':False,'results':results,'note':'Review same-device repeated measurements and visual equivalence before approving any variant. Missing GPU data blocks ranking; never delete the master.'}

def main():
    p=argparse.ArgumentParser();p.add_argument('manifest',type=pathlib.Path);a=p.parse_args()
    try:
        if a.manifest.stat().st_size>256*1024:raise ValueError('manifest too large')
        print(json.dumps(rank(json.loads(a.manifest.read_text(encoding='utf-8-sig')),a.manifest.resolve().parent),indent=2,ensure_ascii=False))
    except (ValueError,TypeError,KeyError,OSError) as e:print('FAILED: '+str(e),file=sys.stderr);return 1
    return 0
if __name__=='__main__':sys.exit(main())
