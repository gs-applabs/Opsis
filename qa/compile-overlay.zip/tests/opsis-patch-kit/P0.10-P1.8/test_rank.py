import importlib.util, pathlib, tempfile, unittest, csv
p=pathlib.Path(__file__).with_name('rank-codec-benchmarks.py');spec=importlib.util.spec_from_file_location('rank',p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
class T(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.root=pathlib.Path(self.tmp.name)
  self.data={'schema':1,'device':'PC1/1080p60','clip':'clip1','master':'master','variants':[]}
  for id,codec,cpu,gpu in [('master','h264',2,5),('vp9','vp9',1,3)]:
   v={'id':id,'codec':codec,'sameContentReviewed':True,'width':1920,'height':1080,'fps':60,'seconds':60,'runs':[]};self.data['variants'].append(v)
   for i in range(2):
    name=f'{id}-{i}.csv';v['runs'].append({'device':self.data['device'],'clip':'clip1','variant':id,'playbackSucceeded':True,'totalFrames':3600,'droppedFrames':0,'csv':name})
    with (self.root/name).open('w',newline='') as f:
     w=csv.writer(f);w.writerow(['ElapsedSeconds','Scenario',*m.METRICS]);w.writerows([[j*5,id,cpu,gpu,1,100*1024*1024] for j in range(14)])
 def tearDown(self):self.tmp.cleanup()
 def run_rank(self):return m.rank(self.data,self.root)
 def test_recommend(self):self.assertEqual(self.run_rank()['recommendation'],'vp9')
 def test_fps(self):self.data['variants'][1]['fps']=30;self.assertEqual(self.run_rank()['recommendation'],'master')
 def test_drop(self):self.data['variants'][1]['runs'][0]['droppedFrames']=40;self.assertEqual(self.run_rank()['recommendation'],'master')
 def test_missing_gpu(self):p=self.root/'vp9-0.csv';p.write_text(p.read_text().replace(',3,1,',',,1,'));self.assertEqual(self.run_rank()['recommendation'],'master')
 def test_baseline_invalid(self):self.data['variants'][0]['runs'][0]['playbackSucceeded']=False;self.assertIsNone(self.run_rank()['recommendation'])
 def test_no_equivalence(self):self.data['variants'][1]['sameContentReviewed']=False;self.assertEqual(self.run_rank()['recommendation'],'master')
 def test_wrong_device(self):self.data['variants'][1]['runs'][0]['device']='PC2';self.assertEqual(self.run_rank()['recommendation'],'master')
 def test_duplicate(self):self.data['variants'][1]['runs'][0]['csv']='master-0.csv';self.assertEqual(self.run_rank()['recommendation'],'master')
if __name__=='__main__':unittest.main(verbosity=2)
