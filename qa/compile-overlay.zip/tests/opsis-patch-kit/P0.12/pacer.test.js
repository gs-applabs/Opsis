const {readFileSync}=require('node:fs');const {runInNewContext}=require('node:vm');const {test}=require('node:test');const assert=require('node:assert/strict');
const htmlPath=process.env.OPSIS_PACER_HTML || require('node:path').resolve(__dirname,'../../../src/Widgets/wallpaper/index.html');
let source;
if(htmlPath){const html=readFileSync(htmlPath,'utf8'), start='class OpsisFramePacer {', end='const framePacer = new OpsisFramePacer();';assert.equal(html.split(start).length,2);assert.equal(html.split(end).length,2);const a=html.indexOf(start),b=html.indexOf(end);assert.ok(b>a);source=html.slice(a,b);assert.ok(html.includes('if (framePacer.ready(now, minFrameMs))'));assert.ok(html.includes('framePacer.delay(performance.now())'));}
const Pacer=runInNewContext(source+'\nOpsisFramePacer');
function simulate(hz,fps,seconds=10,jitter=0){const p=new Pacer(),times=[];for(let i=0;i<hz*seconds;i++){let t=i*1000/hz+Math.sin(i*1.73)*jitter;if(p.ready(t,1000/fps))times.push(t);}return times;}
for(const hz of [60,120,144,165,240])for(const fps of [15,30,60])test(`${hz}Hz → ${fps} FPS`,()=>{const t=simulate(hz,fps,10,.12);assert.ok(Math.abs(t.length-fps*10)<=1,`${t.length}`);assert.ok(t.every((x,i)=>i===0||x>t[i-1]));});
test('30Hz cannot exceed display frequency',()=>assert.equal(simulate(30,60).length,300));
test('stall skips missed frames',()=>{let p=new Pacer();assert.ok(p.ready(0,16.666));assert.ok(p.ready(10000,16.666));assert.equal(p.ready(10000,16.666),false);assert.ok(p.due>10000);});
test('profile change immediate and uses new period',()=>{let p=new Pacer();p.ready(0,10000);assert.ok(p.ready(1,1000/30));assert.equal(p.ready(2,1000/30),false);});
test('reset immediate on resume',()=>{let p=new Pacer();p.ready(1,10000);p.reset();assert.ok(p.ready(2,10000));});
test('negative clock jump resets',()=>{let p=new Pacer();p.ready(100,30);assert.ok(p.ready(2,30));});
test('invalid inputs do not mutate',()=>{let p=new Pacer();assert.equal(p.ready(NaN,10),false);assert.equal(p.ready(0,0),false);assert.equal(p.ready(0,Infinity),false);assert.equal(p.due,null);});
test('reduced mode wake and no extra render',()=>{let p=new Pacer();p.ready(0,10000);assert.equal(p.delay(0),9988);assert.equal(p.ready(9988,10000),false);assert.ok(p.ready(10000,10000));});
test('battery 2FPS',()=>{assert.equal(simulate(144,2).length,20);});
