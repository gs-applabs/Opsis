from pathlib import Path
from playwright.sync_api import sync_playwright
import sys,mimetypes,re
root=Path(sys.argv[1]).resolve()/'src/Widgets/wallpaper'
with sync_playwright() as pw:
 b=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 p=b.new_page(viewport={'width':960,'height':540}); errors=[];blocked=[]
 p.on('pageerror',lambda e: errors.append(str(e)))
 def route(r):
  from urllib.parse import urlparse,unquote
  u=urlparse(r.request.url)
  if u.hostname!='opsis-test.invalid':blocked.append(r.request.url);r.abort();return
  path=(root/unquote(u.path).lstrip('/')).resolve()
  if path.is_file() and path.is_relative_to(root):r.fulfill(body=path.read_bytes(),content_type=mimetypes.guess_type(path)[0] or 'application/octet-stream')
  else:r.fulfill(status=404,body='not found')
 p.route('**/*',route)
 def load(name):
  html=(root/name).read_text(encoding='utf-8-sig')
  # Test harness only: inline exact local scripts; production CSP stays unchanged.
  html=re.sub(r'<meta http-equiv="Content-Security-Policy"[^>]*>','',html)
  html=re.sub(r'<script src="([^"]+)"></script>',lambda m:'<script>'+ (root/m[1]).read_text(encoding='utf-8-sig').replace('</script','<\\/script')+'</script>',html)
  p.set_content(html,wait_until='load')
 load('gallery-weather-preview.html')
 p.evaluate("opsisPreviewInit('Classic', false)")
 seen=set();count=0
 for scene in ['Classic','Mediterranean Ocean','Mountain Lake','Rolling Hills','Desert Horizon','Living Forest','Spectrum Weather']:
  for time in ['Day','Night']:
   p.select_option('#scene',scene);p.select_option('#time',time);p.select_option('#weather','Rain' if time=='Night' else 'Clear')
   x=p.evaluate("document.querySelector('#preview').toDataURL()")
   assert len(x)>2000,(scene,time,len(x));seen.add(x);count+=1
 assert len(seen)==count,(len(seen),count)
 assert not errors,errors
 print('PASS actual integrated preview, 14 distinct scene/time/weather combinations; no JS exceptions')
 p.close();p=b.new_page(viewport={'width':960,'height':540});p.on('pageerror',lambda e: errors.append(str(e)));p.route('**/*',route);load('index.html')
 # Exercise actual host page with a mock bridge; this is Chromium, not WebView2.
 p.evaluate('''() => {window.chrome ??= {}; window.chrome.webview = {hostObjects:{wallpaper:{GetWaveConfigJson:async()=>JSON.stringify(window.testCfg),GetWeatherJson:async()=>JSON.stringify({ok:true,temp:21,wind:10,code:0,utcOffsetSec:7200}),GetAncientAthensWeatherJson:async()=>JSON.stringify({ok:true,temp:21,wind:10,code:0,utcOffsetSec:7200}),RequestWeatherRefresh:()=>{},RequestAncientAthensWeatherRefresh:()=>{},GetAudioPeak:async()=>0,NotifyReady:()=>{},GetPagePropertiesJson:async()=>"{}"}},addEventListener(){},postMessage(){}};}''')
 config={'mode':'Weather','waveStyle':'Ribbons','background':'#05070d','wave':'#0b3d91','peak':'#00d2ff','glow':'#00e5ff','highlight':'#ffffff','speed':1,'glowIntensity':1,'lineThickness':1,'performanceMode':'Low Power','weatherSim':'Clear','timeSim':'Day','weatherLandmarks':False,'weatherLat':37.98,'weatherLon':23.72,'weatherGlass':False,'weatherInfo':True,'weatherCity':'Test','lang':'en','perf':{'targetFps':15,'renderScale':0.65,'pixelBudget':921600,'adaptive':False},'weatherProceduralScene':'Classic','weatherSpatialMode':'Off','weatherPhotoFocusX':.5}
 for mode in ['Classic','Mountain Lake','Rolling Hills','Spectrum Weather']:
  config['weatherProceduralScene']=mode
  p.evaluate('(c)=>window.testCfg=c',config)
  p.evaluate('async()=>{await motionDeskRefresh(); renderFrame(.016);}')
  assert p.evaluate('document.querySelector("#waves").width')>0
  p.evaluate('motionDeskSetPaused(true); motionDeskSetPaused(false)')
 assert not errors,errors
 print('PASS actual integrated host page with mock bridge: 4 Weather modes + pause/resume')
 b.close()
