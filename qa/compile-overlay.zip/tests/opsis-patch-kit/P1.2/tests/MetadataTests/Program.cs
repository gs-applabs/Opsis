using System;
using MotionDesk.Services;
void Check(bool ok) { if (!ok) throw new Exception("Metadata assertion failed"); }
var now = DateTime.UtcNow;
var m = GalleryVideoMetadata.Parse("{\"streams\":[{\"codec_name\":\"vp9\",\"width\":1920,\"height\":1080,\"avg_frame_rate\":\"60000/1001\"}]}", 100, now);
Check(m is { Width:1920, Height:1080, Codec:"vp9", Bytes:100 } && Math.Abs(m.Fps-59.94005994)<0.00001);
Check(GalleryVideoMetadata.Parse("{\"streams\":[{\"avg_frame_rate\":\"0/0\"}]}", 0, now)?.Fps == 0);
Check(GalleryVideoMetadata.Parse("{\"streams\":[]}", 0, now) == null);
Check(GalleryVideoMetadata.Parse("bad", 0, now) == null);
Check(GalleryVideoMetadata.IsSupported("x.WEBM") && !GalleryVideoMetadata.IsSupported("x.html"));
Console.WriteLine("5/5 metadata checks");
namespace MotionDesk.Services { internal static class WmvConversionService { internal static string? FindFfmpeg() => null; } }
