using MotionDesk.UI;
static void Check(bool ok, string detail) { if (!ok) throw new Exception(detail); Console.WriteLine("PASS: " + detail); }
Check(GalleryViewport.Range(0, 3, 100, 0, 300) == (0,0), "empty");
Check(GalleryViewport.Range(96, 3, 100, 0, 300) == (0,12), "top overscan");
Check(GalleryViewport.Range(96, 3, 100, 1000, 1300) == (27,42), "middle overscan");
Check(GalleryViewport.Range(95, 3, 100, 3100, 3200) == (90,95), "partial final row");
Check(GalleryViewport.Range(95, 0, 100, 0, 300) == (0,0), "invalid columns");
Check(GalleryViewport.Range(95, 3, 0, 0, 300) == (0,0), "invalid stride");
for (int cols = 1; cols <= 6; cols++) for (int n = 0; n <= 96; n++) for (int top = 0; top <= 26000; top += 101)
{
    var (first,last) = GalleryViewport.Range(n,cols,262,top,top+800);
    if (first < 0 || last < first || last > n || last-first > 7*cols) throw new Exception("range invariant");
}
Console.WriteLine("PASS: randomized-grid range invariants");
