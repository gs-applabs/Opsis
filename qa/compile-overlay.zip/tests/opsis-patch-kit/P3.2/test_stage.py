import sys, pathlib, unittest, tempfile, json
from PIL import Image
HERE=pathlib.Path(__file__).parent
sys.path.insert(0,str(HERE.parent/'P3'))
from test_approved_pack import T
from stage_runtime import stage
class Runtime(unittest.TestCase):
 @classmethod
 def setUpClass(cls):T.setUpClass();cls.fixture=T();cls.fixture.d={**T.d,"sceneTimeZone":"Etc/UTC"}
 @classmethod
 def tearDownClass(cls):T.tearDownClass()
 def test_stage(self):
  _,a=self.fixture.prepare();out=T.root/'runtime';r=stage(T.scenes,a,out);self.assertEqual(r['scenes'],1);self.assertFalse(r['releaseApproved']);p=out/'src/Widgets/wallpaper/scenes/living-history';d=json.loads((p/'catalog.json').read_text());self.assertTrue(d[0]['historical']);self.assertTrue(d[0]['manualOnly']);self.assertEqual(d[0]['sceneTimeZone'],'Etc/UTC');self.assertTrue((p/'history-giza/poster.webp').is_file());self.assertEqual(d[0]['id'],'history-giza');
  for role in ['day','golden','blue','night']:
   with Image.open(p/'history-giza'/(role+'.webp')) as im:self.assertEqual(im.size,(1920,1080));self.assertEqual(im.getpixel((100,100))[3],0);self.assertEqual(im.getpixel((100,900))[3],255)
  with self.assertRaises(ValueError):stage(T.scenes,a,out)
 def test_empty_ledger(self):
  _,a=self.fixture.prepare();a.write_text('{"schema":1,"entries":[]}');out=T.root/'emptyruntime'
  with self.assertRaises(ValueError):stage(T.scenes,a,out)
  self.assertFalse(out.exists())
 def test_missing_timezone(self):
  _,a=self.fixture.prepare(T.d);out=T.root/'nozone'
  with self.assertRaisesRegex(ValueError,'sceneTimeZone'):stage(T.scenes,a,out)
  self.assertFalse(out.exists())
if __name__=='__main__':unittest.main(verbosity=2)
