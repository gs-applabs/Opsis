#!/usr/bin/env python3
"""Prepare reviewed offline assets, never modify repository or approval ledger."""
import argparse, io, json, pathlib, sys, tempfile, zipfile
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError
from PIL import Image, ImageChops
HERE=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent/'P3'))
from build_approved_pack import build, read_json
from validate_scene import sha
STAGES=('day','golden','blue','night')

def stage(root, ledger, output):
    root=root.resolve(); output=output.absolute(); ledger=ledger.absolute()
    if output.exists() or output.is_symlink() or output.resolve().is_relative_to(root) or not output.parent.is_dir():raise ValueError('new output directory outside source required')
    with tempfile.TemporaryDirectory(prefix='.history-runtime-',dir=output.parent) as tmp:
        temp=pathlib.Path(tmp); pack=temp/'verified.zip'
        build(root,ledger,pack)
        folder=temp/'overlay'; scenes=folder/'src/Widgets/wallpaper/scenes/living-history';scenes.mkdir(parents=True)
        _,backlog=read_json(HERE.parent/'P3/production-backlog.json'); titles={e['id']:e['title'] for e in backlog['entries']}
        catalog=[]; inventory=[]
        with zipfile.ZipFile(pack) as z:
            index=json.loads(z.read('living-history-index.json'))
            for entry in index['entries']:
                id=entry['id']; key='history-'+id; target=scenes/key;target.mkdir()
                d=json.loads(z.read('living-history/'+id+'/manifest.json')); roles=entry['roles']
                def image(role):
                    with Image.open(io.BytesIO(z.read(roles[role]['path']))) as im:
                        return im.convert('L' if role.endswith('Mask') else 'RGB').resize((1920,1080),Image.Resampling.LANCZOS)
                zone=d.get('sceneTimeZone')
                if not isinstance(zone,str) or not zone or len(zone)>80:raise ValueError(id+': explicit IANA sceneTimeZone required in approved manifest')
                try:ZoneInfo(zone)
                except (ZoneInfoNotFoundError,ValueError) as e:raise ValueError(id+': unknown sceneTimeZone; install tzdata if missing') from e
                # Explicit polarity from P3.1; occluders remain foreground. No new guessed geometry.
                alpha=ImageChops.lighter(image('foregroundMask'),image('occlusionMask'))
                for name in STAGES:
                    im=image(name);im.putalpha(alpha);p=target/(name+'.webp');im.save(p,format='WEBP',quality=92,method=4,alpha_quality=100)
                    inventory.append({'path':p.relative_to(folder).as_posix(),'sha256':sha(p),'bytes':p.stat().st_size})
                # Keep the approved poster, independently scaled for Gallery consumption.
                with Image.open(io.BytesIO(z.read(roles['poster']['path']))) as im:
                    im=im.convert('RGB');im.thumbnail((640,360),Image.Resampling.LANCZOS);p=target/'poster.webp';im.save(p,format='WEBP',quality=90)
                    inventory.append({'path':p.relative_to(folder).as_posix(),'sha256':sha(p),'bytes':p.stat().st_size})
                v=d['viewpoint'];title=titles[id];english=id.replace('-',' ').title()
                catalog.append(dict(id=key,name=title,nameEn=english,lat=v['lat'],lon=v['lon'],terrain='land',motif='history',file='scenes/living-history/'+key+'/day.webp',lights=None,manualOnly=True,historical=True,sceneTimeZone=zone))
        cp=scenes/'catalog.json';cp.write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');inventory.append(dict(path=cp.relative_to(folder).as_posix(),sha256=sha(cp),bytes=cp.stat().st_size))
        (folder/'living-history-runtime-inventory.json').write_text(json.dumps(dict(schema=1,authoringSha256=sha(pack),runtimeResolution=[1920,1080],releaseApproved=False,files=inventory),indent=2)+'\n')
        # Atomic directory publication; no overwrite of a nonempty directory. Destination must be new.
        if output.exists() or output.is_symlink():raise ValueError('output appeared during staging')
        folder.rename(output)
    return {'scenes':len(catalog),'files':len(inventory),'releaseApproved':False}

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('scenes',type=pathlib.Path);p.add_argument('ledger',type=pathlib.Path);p.add_argument('output',type=pathlib.Path);a=p.parse_args()
    try:print(json.dumps(stage(a.scenes,a.ledger,a.output)))
    except (ValueError,OSError,KeyError,TypeError) as e:sys.exit('FAILED: '+str(e))
