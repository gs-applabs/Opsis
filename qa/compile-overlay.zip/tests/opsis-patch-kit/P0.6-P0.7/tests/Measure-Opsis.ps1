# Windows diagnostic sampler; does not launch/stop Opsis or modify settings.
# Run separately from the workload; use the same interval for baseline and test.
param(
  [Parameter(Mandatory=$true)][int]$RootPid,
  [Parameter(Mandatory=$true)][string]$Scenario,
  [ValidateRange(10,28800)][int]$DurationSeconds=120,
  [ValidateRange(2,60)][int]$IntervalSeconds=5,
  [string]$OutputCsv="opsis-performance.csv"
)
$ErrorActionPreference='Stop'
$root=Get-Process -Id $RootPid
$startTime=$root.StartTime
$logical=[Environment]::ProcessorCount
$rows=[System.Collections.Generic.List[object]]::new()
$clock=[Diagnostics.Stopwatch]::StartNew()
function Sum-Property($items,[string]$name) {
  $sum=0.0; $found=$false
  foreach($item in $items) {
    if($null -ne $item.$name) { $sum += [double]$item.$name; $found=$true }
  }
  if($found) { return $sum }; return $null
}
while($clock.Elapsed.TotalSeconds -lt $DurationSeconds) {
  $current=Get-Process -Id $RootPid -ErrorAction SilentlyContinue
  if(!$current -or $current.StartTime -ne $startTime) { Write-Warning 'Root process exited or restarted; stopping this sample.'; break }
  $all=@(Get-CimInstance Win32_Process -Property ProcessId,ParentProcessId)
  $ids=[System.Collections.Generic.HashSet[int]]::new(); [void]$ids.Add($RootPid)
  do {
    $before=$ids.Count
    foreach($p in $all) { if($ids.Contains([int]$p.ParentProcessId)) { [void]$ids.Add([int]$p.ProcessId) } }
  } while($ids.Count -gt $before)
  $perf=@(Get-CimInstance Win32_PerfFormattedData_PerfProc_Process | Where-Object {$ids.Contains([int]$_.IDProcess)})
  $gpu3d=$null; $gpuDecode=$null; $gpuDedicated=$null; $gpuShared=$null
  try {
    $eng=@(Get-CimInstance Win32_PerfFormattedData_GPUPerformanceCounters_GPUEngine | Where-Object {$_.Name -match '^pid_(\d+)_' -and $ids.Contains([int]$Matches[1])})
    # Sum of utilization across process/engine instances; may exceed 100%.
    $gpu3d=Sum-Property @($eng | Where-Object {$_.Name -match 'engtype_3D$'}) 'UtilizationPercentage'
    $gpuDecode=Sum-Property @($eng | Where-Object {$_.Name -match 'engtype_VideoDecode$'}) 'UtilizationPercentage'
  } catch { }
  try {
    $mem=@(Get-CimInstance Win32_PerfFormattedData_GPUPerformanceCounters_GPUProcessMemory | Where-Object {$_.Name -match '^pid_(\d+)_' -and $ids.Contains([int]$Matches[1])})
    $gpuDedicated=Sum-Property $mem 'DedicatedUsage'; $gpuShared=Sum-Property $mem 'SharedUsage'
  } catch { }
  $cpu=Sum-Property $perf 'PercentProcessorTime'
  $rows.Add([pscustomobject]@{
    TimestampUtc=[DateTime]::UtcNow.ToString('o'); ElapsedSeconds=[math]::Round($clock.Elapsed.TotalSeconds,2); Scenario=$Scenario; ProcessCount=$perf.Count;
    CpuPctMachine=if($null -ne $cpu){[math]::Round($cpu/$logical,3)}else{$null}; PrivateWorkingSetBytes=Sum-Property $perf 'WorkingSetPrivate'; PrivateBytes=Sum-Property $perf 'PrivateBytes';
    ProcessIoWriteBytesPerSec=Sum-Property $perf 'IOWriteBytesPersec'; Gpu3DEngineSumPct=$gpu3d; GpuDecodeEngineSumPct=$gpuDecode; GpuDedicatedBytes=$gpuDedicated; GpuSharedBytes=$gpuShared
  })
  Start-Sleep -Seconds $IntervalSeconds
}
# Write once, outside the sampling period. Process IO includes non-disk I/O.
$rows | Export-Csv -LiteralPath $OutputCsv -NoTypeInformation -Encoding UTF8
Write-Host "Saved $($rows.Count) samples to $OutputCsv"
