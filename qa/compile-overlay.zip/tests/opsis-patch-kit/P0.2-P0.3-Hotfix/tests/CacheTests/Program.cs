using System;
using System.Threading;
using System.Threading.Tasks;
using MotionDesk.Services;

static void Equal<T>(T expected, T actual) { if (!Equals(expected, actual)) throw new Exception($"Expected {expected}, got {actual}"); }
var cache = new WallpaperMetaCache<string>(2, 8, 3, 1);
int calls = 0;
Task<string?> Load(string s) { Interlocked.Increment(ref calls); return Task.FromResult<string?>(s); }
Task<string?> Read(string key) => cache.GetAsync(key, () => Load(key), s => s.Length, default);
Equal("a", await Read("a")); Equal("b", await Read("b")); Equal("a", await Read("a"));
Equal(2, calls); Equal("c", await Read("c")); Equal("b", await Read("b")); Equal(4, calls);
// byte budget / oversized item cannot evict useful entries unnecessarily
Equal("123456789", await Read("123456789")); Equal("123456789", await Read("123456789")); Equal(6, calls);
var blocked = new TaskCompletionSource<string?>(TaskCreationOptions.RunContinuationsAsynchronously);
var pending = new WallpaperMetaCache<string>(8, 64, 2, 1);
int runs=0;
Task<string?> Job() { Interlocked.Increment(ref runs); return blocked.Task; }
using var cts = new CancellationTokenSource();
var first = pending.GetAsync("one", Job, s => s.Length, cts.Token);
var second = pending.GetAsync("one", Job, s => s.Length, default);
var queued = pending.GetAsync("two", () => Task.FromResult<string?>("two"), s => s.Length, default);
Equal<string?>(null, await pending.GetAsync("three", Job, s => s.Length, default));
cts.Cancel(); try { await first; throw new Exception("Cancellation missing"); } catch (OperationCanceledException) { }
blocked.SetResult("one"); Equal("one", await second); Equal("two", await queued); Equal(1, runs);
Console.WriteLine("PASS: LRU, cache hit, oversized entry, shared work, queue limit, consumer cancellation");
