namespace MotionDesk.Widgets;
public sealed class WallpaperSettings { public Dictionary<string,string> PageProperties {get;set;} = new(); }
