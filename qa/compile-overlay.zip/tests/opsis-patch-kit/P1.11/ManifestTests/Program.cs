using System.Text.Json;
using MotionDesk.Widgets;
static void Assert(bool value,string label) { if (!value) throw new Exception(label);Console.WriteLine("PASS "+label); }
var root=Path.Combine(Path.GetTempPath(),"opsis-manifest-test-"+Guid.NewGuid().ToString("N"));Directory.CreateDirectory(root);
try
{
    string html=Path.Combine(root,"index.html"), file=Path.Combine(root,WallpaperManifest.FileName);
    File.WriteAllText(html,"<html></html>");
    File.WriteAllText(file,"""
      {"name":null,"properties":[null,{"key":"__proto__","type":"text"},
      {"key":"bad|key","type":"text"},
      {"key":"overflow","type":"slider","min":-1e300,"max":1e300,"step":1e-300},
      {"key":"zero","type":"slider","min":0,"max":10,"step":0},
      {"key":"gain","type":"slider","min":-10,"max":10,"step":0.5,"default":3},
      {"key":"gain","type":"text"},
      {"key":"enabled","type":"checkbox","default":true},
      {"key":"style","type":"combo","options":["Bars",null,"Bars","Line"],"default":"Bogus"},
      {"key":"empty","type":"combo","options":null},
      {"key":"color","type":"color","default":"#00c8e6"},
      {"key":"title","type":"text","default":"OPSIS"}]}
      """);
    var m=WallpaperManifest.LoadFor(html)!;Assert(m!=null && m.Properties.Count==5,"bad metadata rejected without losing valid entries");
    Assert(m.Name=="", "null metadata normalized");
    var s=new WallpaperSettings();
    var gain=m.Properties.Single(x=>x.Key=="gain");
    WallpaperManifest.SetValue(s,html,"gain","NaN");Assert(WallpaperManifest.GetValue(s,html,gain)=="3","nonfinite stored number falls back");
    WallpaperManifest.SetValue(s,html,"gain","999");Assert(WallpaperManifest.GetValue(s,html,gain)=="10","range clamp");
    WallpaperManifest.SetValue(s,html,"enabled","invalid");
    WallpaperManifest.SetValue(s,html,"style","bogus");
    using var j=JsonDocument.Parse(WallpaperManifest.ValuesJson(s,html,m));
    Assert(j.RootElement.GetProperty("gain").GetDouble()==10,"typed finite JSON number");
    Assert(j.RootElement.GetProperty("enabled").GetBoolean(),"invalid boolean falls back");
    Assert(j.RootElement.GetProperty("style").GetString()=="Bars","unknown option falls back");
    Assert(m.Properties.Single(x=>x.Key=="style").Options.Count==2,"options deduplicated");
    Assert(j.RootElement.GetProperty("color").GetString()=="#00c8e6","existing sample color preserved");
    File.WriteAllText(file,"{\"properties\":null}");Assert(WallpaperManifest.LoadFor(html)!.Properties.Count==0,"null property list safe");
    File.WriteAllText(file,new string(' ',256*1024+1));Assert(WallpaperManifest.LoadFor(html)==null,"oversize rejected");
}
finally { Directory.Delete(root,true); }
