#!/usr/bin/env python3
"""Read-only inventory of explicitly mapped existing add-on files. Does not convert or delete anything."""
import argparse,json,hashlib,pathlib,re,subprocess,sys
from fractions import Fraction
R6={'original':30,'inox-rails':60,'autumn':60,'carnival':60,'summer':60,'spring':60,'winter':60,'easter':60}
def path_in(root,raw):
    if not isinstance(raw,str) or '\\' in raw or ':' in raw or raw.startswith('/') or any(x in ('','.','..') for x in raw.split('/')):raise ValueError('unsafe path')
    p=root
    for x in raw.split('/'):
        p=p/x
        if p.is_symlink() or (hasattr(p,'is_junction') and p.is_junction()):raise ValueError('linked path')
    if not p.is_file() or not p.resolve().is_relative_to(root.resolve()):raise ValueError('missing/outside file')
    return p

def hashfile(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
    return h.hexdigest()

def probe(p):
    r=subprocess.run(['ffprobe','-v','error','-show_entries','stream=codec_type,codec_name,width,height,avg_frame_rate,duration:format=duration','-of','json',str(p.resolve())],capture_output=True,check=True,timeout=30)
    j=json.loads(r.stdout);v=next(x for x in j['streams'] if x['codec_type']=='video');return dict(codec=v['codec_name'],width=v['width'],height=v['height'],fps=float(Fraction(v['avg_frame_rate'])),duration=float(j['format']['duration']))

def audit(root,manifest):
    errors=[];rows=[];ids=set();roles=set();paths=set();content={};
    for e in manifest['entries']:
        ident=e.get('id','');key=ident.casefold() if isinstance(ident,str) else ''
        try:
            if not re.fullmatch(r'[a-zA-Z0-9._-]{1,100}',ident) or key in ids:raise ValueError('invalid/duplicate ID')
            ids.add(key)
            if e.get('core') is True or key in ('ancient-athens','ancient_athens'):raise ValueError('core wallpaper must not be duplicated')
            p=path_in(root,e['path']);h=hashfile(p)
            if str(p).casefold() in paths:raise ValueError('duplicate file path')
            paths.add(str(p).casefold())
            if h!=e['sha256'].lower():raise ValueError('SHA-256 mismatch')
            row=dict(id=ident,path=e['path'],bytes=p.stat().st_size,sha256=h,kind=e.get('kind'))
            if h in content:
                row['identicalTo']=content[h];errors.append(f'{ident}: identical bytes to {content[h]} — review duplicate before release')
            else:content[h]=ident
            role=e.get('r6Role')
            if role is not None:
                if role not in R6 or role in roles:raise ValueError('unknown/duplicate R6 role')
                roles.add(role)
                if p.suffix.lower()!='.webm' or e.get('kind')!='video':raise ValueError('R6 must be WebM video')
                meta=probe(p);row['video']=meta
                if meta['codec']!='vp9' or (meta['width'],meta['height'])!=(1920,1080) or abs(meta['fps']-R6[role])>0.1 or abs(meta['duration']-60)>0.25:raise ValueError('R6 codec/resolution/FPS/duration mismatch')
            rows.append(row)
        except (ValueError,TypeError,KeyError,AttributeError,OSError,subprocess.SubprocessError,StopIteration,ZeroDivisionError) as ex:errors.append(f'{ident}: {ex}')
    missing=sorted(set(R6)-roles)
    if missing:errors.append('missing R6 roles: '+', '.join(missing))
    return dict(passed=not errors,verifiedEntries=len(rows),errors=errors,entries=rows)

def main():
    p=argparse.ArgumentParser();p.add_argument('root',type=pathlib.Path);p.add_argument('manifest',type=pathlib.Path);p.add_argument('--report',type=pathlib.Path);a=p.parse_args();r=audit(a.root,json.loads(a.manifest.read_text(encoding='utf-8')));s=json.dumps(r,ensure_ascii=False,indent=2)
    if a.report:a.report.write_text(s+'\n',encoding='utf-8')
    else:print(s)
    return 0 if r['passed'] else 1
if __name__=='__main__':sys.exit(main())
