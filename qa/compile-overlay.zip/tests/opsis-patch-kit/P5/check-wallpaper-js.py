#!/usr/bin/env python3
"""Check actual integrated wallpaper entrypoints, local script dependencies and syntax."""
import argparse, pathlib, shutil, subprocess, sys
from html.parser import HTMLParser
from urllib.parse import urlsplit
class Scripts(HTMLParser):
    def __init__(self):super().__init__(convert_charrefs=False);self.scripts=[];self.current=None
    def handle_starttag(self,tag,attrs):
        if tag=='script':
            if self.current is not None:raise ValueError('nested script tag')
            self.current=(dict(attrs),[])
    def handle_data(self,data):
        if self.current is not None:self.current[1].append(data)
    def handle_endtag(self,tag):
        if tag=='script':
            if self.current is None:raise ValueError('unmatched script end')
            self.scripts.append((self.current[0],''.join(self.current[1])));self.current=None

def check(root,node='node'):
    root=root.resolve();checked=set();count=0
    def syntax(text,name,module=False):
        nonlocal count
        p=subprocess.run([node,'--input-type='+('module' if module else 'commonjs'),'--check'],input=text,text=True,encoding='utf-8',capture_output=True,timeout=30)
        if p.returncode:raise ValueError(f'{name}: {p.stderr.strip()}')
        count+=1
    for name in ('index.html','gallery-weather-preview.html'):
        page=root/name;parser=Scripts();parser.feed(page.read_text(encoding='utf-8-sig'));parser.close()
        if parser.current is not None:raise ValueError('unterminated script: '+name)
        refs=[];inline=0
        for attrs,text in parser.scripts:
            kind=(attrs.get('type') or '').strip().lower()
            if kind not in ('','text/javascript','application/javascript','module'):continue
            src=attrs.get('src')
            if src is None:
                if 'src' in attrs:raise ValueError('empty script src: '+name)
                inline+=1;syntax(text,f'{name} inline {inline}',kind=='module');continue
            u=urlsplit(src)
            if u.scheme or u.netloc or u.query or u.fragment or '\\' in src or '%' in src or not src or pathlib.PurePosixPath(src).is_absolute() or '..' in pathlib.PurePosixPath(src).parts:raise ValueError('nonlocal or unsafe script: '+src)
            target=(root/src).resolve()
            if not target.is_relative_to(root) or not target.is_file():raise ValueError('missing or unsafe script: '+src)
            refs.append(target.relative_to(root).as_posix())
            ident=(target,kind=='module')
            if ident not in checked:syntax(target.read_text(encoding='utf-8-sig'),src,kind=='module');checked.add(ident)
        for dep in ('weather-procedural.js','history-renderer.js','weather.js'):
            if refs.count(dep)!=1:raise ValueError(f'{name}: missing or duplicate {dep}')
        if not (refs.index('weather-procedural.js')<refs.index('weather.js') and refs.index('history-renderer.js')<refs.index('weather.js')):raise ValueError('weather dependencies loaded after renderer: '+name)
        if name=='gallery-weather-preview.html' and (refs.count('gallery-weather-preview.js')!=1 or refs.index('gallery-weather-preview.js')<refs.index('weather.js')):raise ValueError('preview initialization dependency missing or out of order')
    return count
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('repo',type=pathlib.Path);a=p.parse_args()
    try:print('PASS: integrated script syntax and dependency order:',check(a.repo/'src/Widgets/wallpaper'))
    except (ValueError,OSError,subprocess.SubprocessError) as e:sys.exit('FAILED: '+str(e))
