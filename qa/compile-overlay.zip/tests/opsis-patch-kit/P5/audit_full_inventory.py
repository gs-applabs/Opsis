#!/usr/bin/env python3
"""Verify ALL files in an extracted, quiescent add-on payload. Never alters the payload."""
import argparse, hashlib, json, os, pathlib, re, stat, sys
MAX_FILES=100000
MAX_MANIFEST=32*1024*1024

def linked(st):
    return stat.S_ISLNK(st.st_mode) or bool(getattr(st,'st_file_attributes',0)&getattr(stat,'FILE_ATTRIBUTE_REPARSE_POINT',0x400))
def safe_path(raw):
    if not isinstance(raw,str) or not raw or len(raw)>1024 or any(ord(c)<32 or c in '\\:<>"|?*' for c in raw):raise ValueError('unsafe path')
    for seg in raw.split('/'):
        if not seg or seg in ('.','..') or seg.endswith(('.', ' ')) or re.fullmatch(r'(?i:con|prn|aux|nul|com[1-9¹²³]|lpt[1-9¹²³])',seg.split('.')[0]):raise ValueError('unsafe segment')
    return raw

def fingerprint(p):
    st=p.lstat()
    if linked(st) or not stat.S_ISREG(st.st_mode):raise ValueError('not a regular unlinked file')
    h=hashlib.sha256()
    with p.open('rb') as f:
        actual=os.fstat(f.fileno())
        if not os.path.samestat(st,actual):raise ValueError('changed while opening')
        for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
        last=os.fstat(f.fileno())
    after=p.lstat()
    if any(linked(x) or not os.path.samestat(st,x) or x.st_size!=st.st_size or x.st_mtime_ns!=st.st_mtime_ns for x in (last,after)):raise ValueError('changed during hash')
    return st.st_size,h.hexdigest()

def audit(root,manifest):
    root=pathlib.Path(root).absolute(); errors=[]; declared={}; actual={}; count=0
    if linked(root.lstat()) or not root.is_dir():raise ValueError('root must be an unlinked directory')
    if manifest.get('schema')!=1 or not isinstance(manifest.get('files'),list) or not 1<=len(manifest['files'])<=MAX_FILES:raise ValueError('invalid full inventory schema/count')
    for entry in manifest['files']:
        try:
            raw=safe_path(entry['path']);key=raw.casefold()
            if key in declared:raise ValueError('duplicate/case-colliding declared path')
            if type(entry['bytes']) is not int or entry['bytes']<0 or not re.fullmatch('[a-fA-F0-9]{64}',entry['sha256']):raise ValueError('invalid bytes/hash')
            declared[key]=entry
        except (ValueError,TypeError,KeyError) as e:errors.append(str(e))
    stack=[root];dirs=0
    while stack:
        folder=stack.pop();dirs+=1
        if dirs>MAX_FILES:raise ValueError('directory limit')
        with os.scandir(folder) as listing:
            for de in listing:
                p=pathlib.Path(de.path);raw=p.relative_to(root).as_posix();count+=1
                if count>MAX_FILES:raise ValueError('payload entry limit')
                try:
                    safe_path(raw);st=p.lstat()
                    if linked(st):raise ValueError('reparse point/symlink')
                    if stat.S_ISDIR(st.st_mode):stack.append(p);continue
                    if not stat.S_ISREG(st.st_mode):raise ValueError('special file')
                    key=raw.casefold()
                    if key in actual:raise ValueError('case-colliding payload path')
                    actual[key]=raw
                    d=declared.get(key)
                    if not d:raise ValueError('undeclared file')
                    if raw!=d['path']:raise ValueError('path casing mismatch')
                    n,h=fingerprint(p)
                    if n!=d['bytes'] or h!=d['sha256'].lower():raise ValueError('bytes/hash mismatch')
                except (ValueError,OSError) as e:errors.append(raw+': '+str(e))
    for key in sorted(set(declared)-set(actual)):errors.append(declared[key]['path']+': missing file')
    return {'passed':not errors,'declaredFiles':len(declared),'discoveredFiles':len(actual),'errors':errors,'productionApproved':False}

def main():
    p=argparse.ArgumentParser();p.add_argument('root',type=pathlib.Path);p.add_argument('manifest',type=pathlib.Path);a=p.parse_args()
    try:
        if a.manifest.stat().st_size>MAX_MANIFEST:raise ValueError('manifest too large')
        r=audit(a.root,json.loads(a.manifest.read_text(encoding='utf-8-sig')));print(json.dumps(r,ensure_ascii=False,indent=2));return 0 if r['passed'] else 1
    except (ValueError,OSError,TypeError,KeyError,AttributeError) as e:print(str(e),file=sys.stderr);return 1
if __name__=='__main__':sys.exit(main())
