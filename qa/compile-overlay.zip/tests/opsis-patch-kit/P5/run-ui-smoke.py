#!/usr/bin/env python3
"""Opt-in Windows desktop smoke test on a disposable VM, using existing Opsis CLI."""
import argparse, hashlib, json, os, pathlib, subprocess, sys, tempfile

# The existing UiAudit itself reports which controls were exercised, which were skipped,
# and layout items requiring human review. Never equate exit 0 with complete release QA.
CASES=(('en','Light'),('el','Dark'))

def inspect_audit(path, require_clicks):
    if not path.is_file() or path.stat().st_size>8*1024*1024:raise ValueError('missing or oversized UI audit')
    d=json.loads(path.read_text(encoding='utf-8-sig'))
    if not isinstance(d,dict) or type(d.get('clicked')) is not int or d['clicked']<0 or not isinstance(d.get('problems'),list) or not isinstance(d.get('captionReview'),list) or not isinstance(d.get('pages'),list) or not d['pages']:raise ValueError('invalid or empty UI audit')
    if any(not isinstance(v,str) for v in d['problems']+d['captionReview']):raise ValueError('invalid UI audit messages')
    names=set(); clicks=0
    for p in d['pages']:
        if not isinstance(p,dict) or not isinstance(p.get('page'),str) or not p['page'] or p['page'] in names or type(p.get('clicked')) is not int or p['clicked']<0 or type(p.get('controls')) is not int or p['controls']<0:raise ValueError('invalid or duplicate page result')
        names.add(p['page']);clicks+=p['clicked']
    if clicks!=d['clicked'] or not {'Wallpaper','Settings'}.issubset(names):raise ValueError('incomplete page coverage or click counts')
    return {'pages':len(d['pages']),'clicked':d['clicked'],'problems':d['problems'],'captionReview':d['captionReview'],'passed':not d['problems'] and (not require_clicks or d['clicked']>0),'manualLayoutReviewRequired':bool(d['captionReview'])}

def child_env(root,lang,theme,clicks):
    env={k:v for k,v in os.environ.items() if not k.upper().startswith('OPSIS_')}
    env.update(OPSIS_APPDATA=str(root),OPSIS_E2E='1',OPSIS_AUDIT_LANGUAGE=lang,OPSIS_AUDIT_THEME=theme,OPSIS_AUDIT_NOCLICK='0' if clicks else '1')
    return env

def run(exe,report,disposable=False,clicks=False):
    exe=exe.resolve();report=report.resolve()
    if os.name!='nt' or not disposable:raise ValueError('requires Windows disposable VM with explicit --disposable-vm')
    if not exe.is_file() or exe.name.lower()!='opsis.exe':raise ValueError('select the published Opsis.exe')
    if report.exists() or report.is_relative_to(exe.parent):raise ValueError('report must be a new directory outside publish')
    report.mkdir(parents=True)
    sha=hashlib.sha256(exe.read_bytes()).hexdigest()
    result={'productionApproved':False,'exeSha256':sha,'clicksRequested':clicks,'cases':[],'unverified':['manual visual review','all 14 languages','full monitor/GPU and installer tests']}
    try:
        with tempfile.TemporaryDirectory(prefix='opsis-ui-smoke-') as td:
            for lang,theme in CASES:
                case=report/(lang+'-'+theme.lower());case.mkdir();data=pathlib.Path(td)/(lang+'-data');data.mkdir()
                r={'language':lang,'theme':theme};result['cases'].append(r)
                with (case/'process.log').open('wb') as log:
                    try:p=subprocess.run([str(exe),'--ui-audit',str(case)],cwd=exe.parent,env=child_env(data,lang,theme,clicks),stdout=log,stderr=subprocess.STDOUT,timeout=600);r['exitCode']=p.returncode
                    except subprocess.TimeoutExpired:r['exitCode']=124
                try:r.update(inspect_audit(case/'ui-audit.json',clicks))
                except (ValueError,OSError) as e:r.update(passed=False,error=str(e))
                r['passed']=r.get('passed',False) and r['exitCode']==0
        result['smokePassed']=len(result['cases'])==len(CASES) and all(c['passed'] for c in result['cases']) and hashlib.sha256(exe.read_bytes()).hexdigest()==sha
    finally:(report/'ui-smoke-report.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    return 0 if result.get('smokePassed') else 1

def main():
    p=argparse.ArgumentParser();p.add_argument('exe',type=pathlib.Path);p.add_argument('report',type=pathlib.Path);p.add_argument('--disposable-vm',action='store_true');p.add_argument('--clicks',action='store_true',help='exercise the existing reversible controls; VM only');a=p.parse_args()
    try:return run(a.exe,a.report,a.disposable_vm,a.clicks)
    except (ValueError,OSError,subprocess.SubprocessError) as e:print('FAILED:',e,file=sys.stderr);return 1
if __name__=='__main__':sys.exit(main())
