using System.Drawing;
using System.Reflection;
using System.Text.Json;
using MotionDesk.Widgets;
using Opsis.Containers;
using LegacyItem = MotionDesk.Widgets.ContainerItem;
using NativeItem = Opsis.Containers.ContainerItem;

// Tests the actual application assembly without altering the real desktop or profile.
var asm = typeof(DeskContainerState).Assembly;
var parity = asm.GetType("MotionDesk.Containers.ContainerLegacyParity", true)!;
var migration = asm.GetType("MotionDesk.Containers.NativeMigration", true)!;
object? Call(Type type, string name, params object?[] args) =>
    type.GetMethod(name, BindingFlags.Static | BindingFlags.NonPublic | BindingFlags.Public)!.Invoke(null, args);
void Check(bool pass, string name) { if (!pass) throw new InvalidOperationException(name); Console.WriteLine("PASS " + name); }
string root = Path.Combine(Path.GetTempPath(), "opsis-parity-" + Guid.NewGuid().ToString("N"));
Directory.CreateDirectory(root);
try
{
    string small = Path.Combine(root, "small.txt"), big = Path.Combine(root, "big.txt"), missing = Path.Combine(root, "missing.txt");
    File.WriteAllBytes(small, new byte[10]); File.WriteAllBytes(big, new byte[4096]);
    var legacy = new DeskContainerState
    {
        Title = "Legacy", Width = 320, Height = 240, ShowLabels = false, ExcludeFromQuickHide = true,
        WindowOpacity = .65, SortMode = "TimesOpened", PlaceNewIconsHereByDefault = true, AutoCollectExtensions = "txt,pdf",
        Tabs = [new ContainerTabState { Name = "Single tab", Items = [new LegacyItem { Path = small, OpenCount = 7, DateAdded = new DateTime(2020,1,1,0,0,0,DateTimeKind.Utc) }, new LegacyItem { Path = big }] }],
        Items = [new LegacyItem { Path = missing }]
    };
    var monitors = new[] { new MonitorInfo("Smoke", new Rectangle(0,0,1920,1080), true) };
    var issues = new List<string>();
    var model = (Container)Call(migration, "ConvertOriginal", legacy, "legacy_config.json", monitors, issues)!;
    Check(model.ExcludeFromQuickHide && model.Appearance.TintOpacity == 65, "legacy quick-hide exclusion and opacity");
    Check(model.TabsEnabled && model.Tabs.Count == 1 && model.Tabs[0].Items.Count == 3, "single tab and root references retained");
    Check(!(bool)Call(parity, "ShowLabels", model)!, "labels disabled on migration");
    Check(issues.Count == 1 && model.Extra!["opsisOriginalDefaultForNewIcons"].GetBoolean(), "rule intent preserved but not automatically enabled");
    var nameItem = new NativeItem { Path = Path.Combine(root, "Report.PDF"), DisplayName = "Annual summary" };
    Check((bool)Call(parity,"MatchesName",nameItem,"report")! && (bool)Call(parity,"MatchesName",nameItem,"SUMMARY")!, "legacy name search and displayed name, case insensitive");
    Check((bool)Call(parity,"MatchesName",nameItem,"")! && !(bool)Call(parity,"MatchesName",nameItem,"opsis-parity-")!, "empty query restores all; parent path is not searched");
    var history = Call(parity, "ReadHistory", model);
    var items = model.Tabs[0].Items.ToArray();
    List<NativeItem> Sort(string order) => (List<NativeItem>)Call(parity,"Sort",items,order,history,CancellationToken.None)!;
    Check(Sort("size").Select(x=>x.Path).SequenceEqual(new[]{small,big,missing}),"ascending size, unknown last");
    Check(Sort("size-desc").Select(x=>x.Path).SequenceEqual(new[]{big,small,missing}),"descending size, unknown last");
    Check(Sort("opened-desc")[0].Path==small,"legacy launch count imported");
    Check(Sort("added")[0].Path==small,"known added date before unknowns");
    Call(parity, "RecordOpen", model, big);
    Call(parity, "RecordAdded", model, new[] { Path.Combine(root,"new.txt") });
    var roundtrip = JsonSerializer.Deserialize<Container>(JsonSerializer.Serialize(model))!;
    Check(roundtrip.Extra!.ContainsKey("opsisItemHistory") && !(bool)Call(parity,"ShowLabels",roundtrip)!, "native JSON metadata roundtrip");
    // Move/copy histories with duplicate paths, detach, and malformed metadata.
    var from = new Container { Items = [new NativeItem { Path = small }] };
    var to = new Container { Items = [new NativeItem { Path = small }, new NativeItem { Path = big }] };
    from.Extra = new() { ["opsisItemHistory"] = JsonSerializer.SerializeToElement(new Dictionary<string, object>
    {
        [small] = new { AddedUtc = new DateTime(2020,1,1,0,0,0,DateTimeKind.Utc), OpenCount = 7 },
        [big] = new { AddedUtc = new DateTime(2021,1,1,0,0,0,DateTimeKind.Utc), OpenCount = 3 }
    }) };
    Call(parity, "RecordAdded", to, new[] { small });
    Call(parity, "RecordOpen", to, small);
    Call(parity, "TransferHistory", from, to, new[] { small, big });
    JsonElement Entry(Container c, string path) => c.Extra!["opsisItemHistory"].GetProperty(path);
    Check(Entry(to,small).GetProperty("OpenCount").GetInt32()==7 && Entry(to,small).GetProperty("AddedUtc").GetDateTime().Year==2020, "duplicate history preserves earliest date and max count");
    Check(from.Extra!["opsisItemHistory"].TryGetProperty(small,out _) && !from.Extra["opsisItemHistory"].TryGetProperty(big,out _), "only still referenced history retained at source");
    Call(parity, "TransferHistory", from, to, new[] { small });
    Check(Entry(to,small).GetProperty("OpenCount").GetInt32()==7,"repeated moves do not inflate open count");
    var detached = JsonSerializer.Deserialize<Container>(JsonSerializer.Serialize(to))!;
    Call(parity,"ClearHistory",detached);
    detached.Items = [new NativeItem { Path = big }];
    to.Items.RemoveAll(i=>i.Path==big);
    Call(parity,"TransferHistory",to,detached,new[] { big });
    Check(Entry(detached,big).GetProperty("OpenCount").GetInt32()==3 && !detached.Extra!["opsisItemHistory"].TryGetProperty(small,out _) && !to.Extra!["opsisItemHistory"].TryGetProperty(big,out _), "detached history excludes unrelated entries");
    var damaged = new Container { Extra = new() { ["opsisItemHistory"] = JsonSerializer.SerializeToElement(new Dictionary<string, object> { [small] = new { OpenCount = "bad" }, [big] = new { OpenCount = 3 } }) } };
    Call(parity,"RecordOpen",damaged,big);
    Check(Entry(damaged,big).GetProperty("OpenCount").GetInt32()==4,"invalid entry does not hide subsequent history");
    // Legacy rule shortcuts share the existing routing engine and retain unrelated rules.
    var legacyRules = asm.GetType("MotionDesk.Containers.ContainerLegacyRules", true)!;
    var organization = asm.GetType("MotionDesk.Containers.DesktopOrganization", true)!;
    var desktopFiles = asm.GetType("MotionDesk.Containers.DesktopFiles", true)!;
    object?[] argsExt = ["*.PDF, .txt; pdf", null];
    Check((bool)Call(legacyRules,"TryExtensions",argsExt)! && ((string[])argsExt[1]!).SequenceEqual(new[]{"pdf","txt"}), "normalize and deduplicate legacy extensions");
    object?[] invalidExt = ["txt, C:/private", null];
    Check(!(bool)Call(legacyRules,"TryExtensions",invalidExt)!, "reject invalid extension input");
    var package = JsonSerializer.Deserialize("""
        {"Layouts":[],"Rules":[{"Name":"existing","Target":"other","Conditions":[],"Priority":true,"Enabled":true}],"DefaultTarget":"other","KeepUpdated":false,"Issues":[],"RulesEnabled":false}
        """, organization)!;
    var updated = Call(legacyRules,"SetExtensions",package,"legacy",new[]{"pdf","txt"})!;
    var json = JsonSerializer.SerializeToElement(updated);
    Check(json.GetProperty("Rules").GetArrayLength()==2 && json.GetProperty("Rules")[0].GetProperty("Name").GetString()=="existing" && json.GetProperty("DefaultTarget").GetString()=="other", "legacy rule preserves existing rules and default");
    Check(json.GetProperty("RulesEnabled").GetBoolean() && json.GetProperty("KeepUpdated").GetBoolean(), "confirmed configuration enables shared periodic routing");
    Check(ReferenceEquals(updated,Call(legacyRules,"SetExtensions",updated,"legacy",new[]{"pdf","txt"})),"unchanged rule configuration is no-op");
    var cleared = JsonSerializer.SerializeToElement(Call(legacyRules,"SetExtensions",updated,"legacy",Array.Empty<string>()));
    Check(cleared.GetProperty("Rules").GetArrayLength()==1 && cleared.GetProperty("DefaultTarget").GetString()=="other", "remove only owned rule");
    var fallback = Call(legacyRules,"SetDefault",updated,"legacy",true)!;
    Check(JsonSerializer.SerializeToElement(fallback).GetProperty("DefaultTarget").GetString()=="legacy" && ReferenceEquals(fallback,Call(legacyRules,"SetDefault",fallback,"other",false)), "one fallback; clearing another target is no-op");
    Directory.CreateDirectory(Path.Combine(root,"folder.txt"));
    File.WriteAllText(Path.Combine(root,"report.PDF"),"test");
    var found = (List<NativeItem>)Call(desktopFiles,"CollectMatching",root,root,new[]{"pdf","txt"},CancellationToken.None)!;
    Check(found.Count==3 && found.All(x=>!x.IsFolder) && File.Exists(small) && File.Exists(big), "read-only collection matches files, skips folders and duplicate roots");
    // Verify no old source is modified or removed and no existing native state is overwritten.
    string folder = Path.Combine(root,"deskcontainers"); Directory.CreateDirectory(folder);
    string source = Path.Combine(folder,"legacy_config.json"); File.WriteAllText(source,JsonSerializer.Serialize(legacy));
    string oldText = File.ReadAllText(source);
    var store = new ContainersStore(Path.Combine(root,"native.json"));
    Check(Call(migration,"ImportOriginalContainers",store,folder,monitors) is string && File.Exists(store.Path), "original profile imported into new store");
    string originalNative = File.ReadAllText(store.Path);
    Check(Call(migration,"ImportOriginalContainers",store,folder,monitors)==null && File.ReadAllText(store.Path)==originalNative && File.ReadAllText(source)==oldText,"repeat import is read-only and idempotent");
    var legacyWithSpacer = new DeskContainerState { Width = 320, Height = 240, Items = [new LegacyItem { Path = small }, new LegacyItem { Path = "::spacer::1" }, new LegacyItem { Path = big }] };
    var spaced = (Container)Call(migration,"ConvertOriginal",legacyWithSpacer,"spaced_config.json",monitors,new List<string>())!;
    Check(spaced.Items.Count == 2 && spaced.Extra!["opsisOriginalSpacers"][0].GetProperty("BeforeFileCount").GetInt32()==1, "spacer position retained without a pseudo file reference");
    var spacer = asm.GetType("MotionDesk.Containers.ContainerSpacers", true)!;
    int[] gaps = (int[])Call(spacer,"Active",spaced)!;
    Check(gaps.SequenceEqual(new[]{1}) && spaced.Items.All(i=>!i.Path.StartsWith("::spacer::")), "legacy gap normalized without synthetic file");
    Check((int)Call(spacer,"SlotFor",0,gaps)! == 0 && (int)Call(spacer,"SlotFor",1,gaps)! == 2 &&
        (int)Call(spacer,"ItemAt",1,gaps)! == -1 && (int)Call(spacer,"ItemAt",2,gaps)! == 1, "gap maps visual slots to real indices and cannot be selected");
    var layoutType = asm.GetType("MotionDesk.Containers.ContainerItemLayout", true)!;
    var metrics = ContainerMetrics.Default(1f, 28, 48);
    object layout = Activator.CreateInstance(layoutType, BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance, null,
        new object[]{new Size(320,280), metrics, true, gaps}, null)!;
    object? LayoutCall(string method, params object[] parameters) => layoutType.GetMethod(method, BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.Public)!.Invoke(layout,parameters);
    var firstRect = (Rectangle)LayoutCall("CellRect",0,0)!;
    var secondRect = (Rectangle)LayoutCall("CellRect",1,0)!;
    var gapPoint = new Point(firstRect.Left+2, firstRect.Top+(secondRect.Top-firstRect.Top)/2+2);
    Check((int)LayoutCall("HitTest",gapPoint,2,0)! == -1 && (int)LayoutCall("HitGap",gapPoint,2,0)! == 0 &&
        (int)LayoutCall("HitTest",new Point(secondRect.Left+2,secondRect.Top+2),2,0)! == 1, "row hit-testing distinguishes blank and real item");
    object grid = Activator.CreateInstance(layoutType, BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance, null,
        new object[]{new Size(420,300), metrics, false, gaps}, null)!;
    object bareGrid = Activator.CreateInstance(layoutType, BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance, null,
        new object[]{new Size(420,300), metrics, false, Array.Empty<int>()}, null)!;
    var cellMethod = layoutType.GetMethod("CellRect", BindingFlags.Instance | BindingFlags.NonPublic)!;
    var hitMethod = layoutType.GetMethod("HitTest", BindingFlags.Instance | BindingFlags.NonPublic)!;
    var blankCell = (Rectangle)cellMethod.Invoke(bareGrid,new object[]{1,0})!;
    Check((int)hitMethod.Invoke(grid,new object[]{new Point(blankCell.Left+blankCell.Width/2,blankCell.Top+blankCell.Height/2),2,0})! == -1,
        "grid spacer is empty and is not a file hit target");
    Call(spacer,"SetActive",spaced,new[]{2});
    spaced.Items.RemoveAt(1);
    Call(spacer,"ClampForList",spaced,spaced.Items);
    spaced.Items.Add(new NativeItem{Path=big});
    Check(((int[])Call(spacer,"Active",spaced)!).SequenceEqual(new[]{1}),"deleted items clamp persisted gap without later drift");
    Call(spacer,"SetActive",spaced,Array.Empty<int>());
    Call(spacer,"NormalizeLegacy",spaced);
    Check(((int[])Call(spacer,"Active",spaced)!).Length==0,"cleared legacy spacers are not resurrected");
    var tabsWithSpacers = new DeskContainerState { Width=320, Height=240, Tabs=[new ContainerTabState { Name="One", Items=[new LegacyItem{Path=small},new LegacyItem{Path="::spacer::a"},new LegacyItem{Path=big}] },new ContainerTabState { Name="Two",Items=[new LegacyItem{Path="::spacer::b"},new LegacyItem{Path=missing}] }], Items=[new LegacyItem{Path=small},new LegacyItem{Path="::spacer::c"},new LegacyItem{Path=Path.Combine(root,"unique.txt")}] };
    var tabbed = (Container)Call(migration,"ConvertOriginal",tabsWithSpacers,"tabs-spacers.json",monitors,new List<string>())!;
    Check(((int[])Call(spacer,"Active",tabbed)!).SequenceEqual(new[]{1,2}),"new root append calculates exact spacer position after deduplication");
    tabbed.CurrentTab=1;
    var tabbedReloaded=JsonSerializer.Deserialize<Container>(JsonSerializer.Serialize(tabbed))!;
    Check(((int[])Call(spacer,"Active",tabbedReloaded)!).SequenceEqual(new[]{0}) && tabbedReloaded.Tabs[1].Items.Count==1,"per-tab spacer state roundtrips with no pseudo references");
    string nameA = (string)Call(migration,"ImportedSnapshotName","../../unsafe")!;
    string nameB = (string)Call(migration,"ImportedSnapshotName","../../unsafe")!;
    Check(nameA != nameB && nameA.All(c=>char.IsLetterOrDigit(c)||c=='-'), "unique traversal-safe snapshot names");
    var read = ((ContainersDocument Document, List<string> Issues))Call(migration,"ReadOriginalContainers",folder,monitors)!;
    Check(read.Document.Containers.Count==1 && File.ReadAllText(store.Path)==originalNative, "read original profiles independently of existing store");
    string savedName = (string)Call(migration,"SaveImportedSnapshot",read.Document,store.Path)!;
    Check(savedName.StartsWith("Legacy-") && Directory.EnumerateFiles(Path.Combine(root,"container-snapshots")).Any() && File.ReadAllText(store.Path)==originalNative && File.ReadAllText(source)==oldText, "import as snapshot leaves source and native layout untouched");
}
finally { Directory.Delete(root,true); }
