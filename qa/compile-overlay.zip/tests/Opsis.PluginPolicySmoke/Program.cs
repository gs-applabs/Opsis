using MotionDesk.Services;
using System.Text.Json;

var root = Path.Combine(Path.GetTempPath(), "opsis-plugin-policy-" + Guid.NewGuid().ToString("N"));
Directory.CreateDirectory(root);
int passed = 0;
void Check(bool ok, string name) { if (!ok) throw new Exception("FAIL " + name); passed++; Console.WriteLine("PASS " + name); }
var folder = Directory.CreateDirectory(Path.Combine(root, "plugin")).FullName;
var manifest = Path.Combine(folder, "opsis-permissions.json");
void Write(string json) => File.WriteAllText(manifest, json);
void Reject(string json, string description)
{
    Write(json);
    bool rejected = false;
    try { PluginCapabilityManifest.Inspect(folder); }
    catch (Exception e) when (e is InvalidDataException or JsonException) { rejected = true; }
    Check(rejected, description);
}
try
{
    Check(PluginCapabilityManifest.Inspect(folder) is { SdkVersion: "1.0", Present: false }, "manifest-free legacy package");
    Write("{\"Network\":true,\"Audio\":false,\"LocalFiles\":true}");
    Check(PluginCapabilityManifest.Read(folder).SequenceEqual(new[]{"network", "local-files"}), "legacy permissions unchanged");
    Write("{\"sdkVersion\":\"2.0\",\"runtime\":\"in-process\",\"audio\":true}");
    Check(PluginCapabilityManifest.Inspect(folder) is { RequiresExplicitApproval: true, Audio: true, Network: false, LocalFiles: false }, "SDK2 explicitly approved, absent flags false");
    Reject("{\"sdkVersion\":\"3.0\"}", "future SDK rejected");
    Reject("{\"sdkVersion\":\"2.0\",\"runtime\":\"isolated\"}", "unavailable isolation rejected");
    Reject("{\"sdkVersion\":\"2.0\"}", "runtime required");
    Reject("{\"sdkVersion\":\"2.0\",\"runtime\":\"in-process\",\"netwrok\":true}", "unknown SDK2 capability rejected");
    Reject("{\"network\":true,\"Network\":false}", "case-insensitive duplicate rejected");
    Reject("{\"audio\":\"true\"}", "nonboolean flag rejected");
    Reject("null", "non-object rejected");
    Reject("{" + new string(' ', 5000) + "}", "oversized declaration rejected");
    Write("{\"sdkVersion\":\"2.0\",\"runtime\":\"in-process\"}");
    File.WriteAllText(Path.Combine(folder, "ExamplePlugin.dll"), "test fixture, never loaded");
    var oldHash = PluginTrust.HashFolder(folder);
    var trustPath = Path.Combine(root, "trust.json");
    var store = new PluginTrust.Store(trustPath);
    store.Approve("Example", oldHash);
    Check(store.IsApproved("example", oldHash), "case-insensitive approval");
    Write("{\"sdkVersion\":\"2.0\",\"runtime\":\"in-process\",\"audio\":true}");
    var newHash = PluginTrust.HashFolder(folder);
    Check(oldHash != newHash && !store.IsApproved("Example", newHash), "changed declaration requires new approval");
    store.Revoke("example");
    var reopened = new PluginTrust.Store(trustPath);
    Check(reopened.IsRevoked("EXAMPLE") && !reopened.IsApproved("Example", oldHash), "revocation survives restart");
    reopened.Approve("Example", newHash);
    Check(!reopened.IsRevoked("example") && reopened.IsApproved("example", newHash), "explicit approval clears revocation");
    File.WriteAllText(trustPath, "[null]");
    Check(!new PluginTrust.Store(trustPath).IsApproved("Example", newHash), "malformed null trust record does not authorize");
    Write("""{"sdkVersion":"2.0","runtime":"in-process","dependencies":{"provider.one":"1.2"}}""");
    var deps = PluginCapabilityManifest.Inspect(folder).Dependencies;
    Check(deps.Length == 1 && deps[0].Id == "provider.one" && deps[0].MinimumVersion == new Version(1, 2), "dependency declaration parsed");
    Reject("""{"sdkVersion":"2.0","runtime":"in-process","dependencies":{"Provider":"1.0","provider":"2.0"}}""", "duplicate dependency rejected");
    Reject("""{"sdkVersion":"2.0","runtime":"in-process","dependencies":{"../path":"1.0"}}""", "invalid dependency ID rejected");
    Reject("""{"sdkVersion":"2.0","runtime":"in-process","dependencies":{"provider":"latest"}}""", "invalid minimum version rejected");
    Reject("""{"sdkVersion":"2.0","runtime":"in-process","dependencies":[]}""", "dependency array rejected");
    Reject("""{"dependencies":{"provider":"1.0"}}""", "legacy dependency declaration rejected");
    var consumer = new PluginDependencyPolicy.Node("consumer", "1.0", false, deps);
    var provider = new PluginDependencyPolicy.Node("PROVIDER.ONE", "1.2.0.0", true, []);
    Check(PluginDependencyPolicy.BlockingReason(consumer, [consumer, provider]) == null, "case-insensitive and normalized version match");
    Check(PluginDependencyPolicy.BlockingReason(consumer, [consumer]) != null, "missing provider blocks start");
    Check(PluginDependencyPolicy.BlockingReason(consumer, [consumer, provider with { Started = false }]) != null, "disabled provider blocks start");
    Check(PluginDependencyPolicy.BlockingReason(consumer, [consumer, provider with { Version = "1.1.9" }]) != null, "obsolete provider blocks start");
    Check(PluginDependencyPolicy.BlockingReason(consumer, [consumer, provider, provider]) != null, "ambiguous provider blocks start");
    var self = consumer with { Dependencies = [new("CONSUMER", new Version(1, 0))] };
    Check(PluginDependencyPolicy.BlockingReason(self, [self]) != null, "self dependency blocked");
    var cycleProvider = provider with { Started = false, Dependencies = [new("consumer", new Version(1, 0))] };
    Check(PluginDependencyPolicy.BlockingReason(consumer, [consumer, cycleProvider]) != null && PluginDependencyPolicy.BlockingReason(cycleProvider, [consumer, cycleProvider]) != null, "cycle cannot activate");
    var downstream = new PluginDependencyPolicy.Node("downstream", "1.0", true, [new("consumer", new Version(1, 0))]);
    Check(PluginDependencyPolicy.StopOrder([provider.Id], [provider, consumer with { Started = true }, downstream]).SequenceEqual(new[] { "downstream", "consumer", provider.Id }), "reverse transitive stop order");
    Check(PluginDependencyPolicy.StopOrder([provider.Id], [provider, consumer, downstream]).SequenceEqual(new[] { provider.Id }), "inactive consumers are not stopped");
    Check(PluginDependencyPolicy.StopOrder([provider.Id, "consumer"], [provider, consumer with { Started = true }, downstream]).Distinct(StringComparer.OrdinalIgnoreCase).Count() == 3, "multiple roots stop once");
    Write("""{"sdkVersion":"2.0","runtime":"in-process","dependencies":{"provider.one":{"min":"1.2","maxExclusive":"2.0"}}}""");
    var ranged = PluginCapabilityManifest.Inspect(folder).Dependencies;
    Check(ranged.Length == 1 && ranged[0].MaximumExclusive == new Version(2, 0), "bounded dependency parsed");
    Check(PluginDependencyPolicy.BlockingReason(consumer with { Dependencies = ranged }, [provider]) == null, "range accepts lower bound");
    Check(PluginDependencyPolicy.BlockingReason(consumer with { Dependencies = ranged }, [provider with { Version = "2.0.0" }]) != null, "range rejects exclusive upper bound");
    Reject("""{"sdkVersion":"2.0","runtime":"in-process","dependencies":{"provider":{"min":"2.0","maxExclusive":"2.0.0"}}}""", "empty range rejected");
    Reject("""{"sdkVersion":"2.0","runtime":"in-process","dependencies":{"provider":{"maxExclusive":"2.0"}}}""", "missing minimum rejected");
    Reject("""{"sdkVersion":"2.0","runtime":"in-process","dependencies":{"provider":{"min":"1.0","Min":"1.1"}}}""", "duplicate range field rejected");
    Write("""{"sdkVersion":"2.0","runtime":"in-process"}""");
    var beforeFull = PluginTrust.ApprovalDigest(folder, true);
    var beforeLegacy = PluginTrust.ApprovalDigest(folder, false);
    Check(beforeFull != beforeLegacy, "SDK2 digest domain differs from legacy");
    Check(beforeFull == PluginTrust.ApprovalDigest(folder, true), "full digest stable");
    var asset = Path.Combine(folder, "script.js");
    File.WriteAllText(asset, "first");
    var withAsset = PluginTrust.ApprovalDigest(folder, true);
    Check(withAsset != beforeFull, "added asset changes SDK2 digest");
    Check(PluginTrust.ApprovalDigest(folder, false) == beforeLegacy, "legacy digest compatibility retained");
    File.WriteAllText(asset, "other");
    Check(PluginTrust.ApprovalDigest(folder, true) != withAsset, "changed non-DLL asset changes SDK2 digest");
    File.Delete(asset);
    Check(PluginTrust.ApprovalDigest(folder, true) == beforeFull, "removed asset restores original digest");
    var managed = Directory.CreateDirectory(Path.Combine(root, "plugins", "Managed")).FullName;
    File.WriteAllText(Path.Combine(managed, "ExamplePlugin.dll"), "fixture");
    Check(PluginRemovalPolicy.IsManagedPackage(root, managed), "managed direct child accepted");
    Check(!PluginRemovalPolicy.IsManagedPackage(root, folder), "external folder rejected");
    Check(!PluginRemovalPolicy.TryArchive(root, managed), "legacy queue without receipt cannot move files");
    PluginRemovalPolicy.Authorize(root, managed);
    File.WriteAllText(Path.Combine(managed, "asset.txt"), "changed");
    Check(!PluginRemovalPolicy.TryArchive(root, managed), "changed pending package held");
    PluginRemovalPolicy.Authorize(root, managed);
    Check(PluginRemovalPolicy.TryArchive(root, managed) && !Directory.Exists(managed), "approved unchanged package archived");
    Check(Directory.EnumerateFiles(Path.Combine(root, "plugin-removed-backups"), "ExamplePlugin.dll", SearchOption.AllDirectories).Any(), "archived original retained");
    var unwritablePath = Path.Combine(root, "not-a-file");
    var failedStore = new PluginTrust.Store(unwritablePath);
    Directory.CreateDirectory(unwritablePath);
    bool persistenceFailed = false;
    try { failedStore.Approve("Example", beforeFull); }
    catch (Exception e) when (e is IOException or UnauthorizedAccessException) { persistenceFailed = true; }
    Check(persistenceFailed && !failedStore.IsApproved("Example", beforeFull), "failed persistence never grants approval");
    Console.WriteLine($"{passed} plugin policy assertions passed");
}
finally { Directory.Delete(root, true); }
