"""Independent mathematical reference check, NOT execution of the C# implementation."""
from itertools import combinations_with_replacement


def check():
    cases = 0
    for n in range(9):
        for k in range(5):
            for gaps in combinations_with_replacement(range(n + 1), k):
                expected = []
                for i in range(n + 1):
                    expected += [-1] * gaps.count(i)
                    if i < n:
                        expected.append(i)
                for item in range(n):
                    assert expected[item + sum(g <= item for g in gaps)] == item
                for slot, value in enumerate(expected):
                    passed = 0
                    result = None
                    for gap in gaps:
                        blank = gap + passed
                        if slot == blank:
                            result = -1
                            break
                        if slot < blank:
                            break
                        passed += 1
                    if result is None:
                        result = slot - passed
                    assert result == value
                for slot in range(len(expected) + 1):
                    passed = 0
                    for gap in gaps:
                        if gap + passed >= slot:
                            break
                        passed += 1
                    assert max(0, slot - passed) == sum(v >= 0 for v in expected[:slot])
                cases += 1
    print(f'PASS independent Python slot reference: {cases} configurations (not C# execution)')


if __name__ == '__main__':
    check()
