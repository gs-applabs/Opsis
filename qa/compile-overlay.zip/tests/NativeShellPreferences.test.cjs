const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.join(__dirname, '..');
const read = f => fs.readFileSync(path.join(root,f), 'utf8');
test('native shell features use the existing services and no external command adapter', () => {
  const main=read('src/UI/MainWindow.cs'), explorer=read('src/UI/OpsisExplorerStudioForm.cs');
  for(const file of ['src/Services/NativeShellThemeBridge.cs','src/UI/NativeShellThemeForm.cs']) assert.equal(fs.existsSync(path.join(root,file)),false);
  assert.doesNotMatch(main+explorer,/NativeShellThemeBridge|NativeShellThemeForm|windhawk-cli|Windhawk styler/i);
  for(const key of ['MMTaskbarEnabled','TaskbarSd']) {
    assert.ok(main.includes(`TaskbarViewProfiles.ReadOption("${key}")`));
    assert.ok(main.includes(`TaskbarViewProfiles.ApplyOption("${key}", value)`));
  }
  for(const key of ['NavPaneShowAllFolders','NavPaneExpandToCurrentFolder']) {
    assert.ok(explorer.includes(`["${key}"]`));
    assert.ok(explorer.includes(`ExplorerViewProfiles.ReadOption("${key}")`));
  }
  assert.ok(explorer.includes('ExplorerViewProfiles.ApplyOptions('));
});
test('compatibility presentation aggregates potential overlaps rather than advertising external products', () => {
  const ui=read('src/UI/MainWindow.Experience.cs');
  assert.ok(ui.includes('GroupBy(f => (f.Area, f.Risk))'));
  assert.doesNotMatch(ui,/f\.Product|Scan Windhawk\/Rainmeter conflicts/);
  assert.ok(read('src/Services/OpsisIntegrationAudit.cs').includes('configured state is not proof of active code'));
});
test('existing shell services share the checked rollback transaction and preserve their backups', () => {
  for(const file of ['src/Services/ExplorerViewProfiles.cs','src/Services/TaskbarViewProfiles.cs']) {
    const s=read(file);
    assert.ok(s.includes('ShellPreferenceTransaction.Apply(desired, ReadRaw, WriteRaw, BackupIfMissing)'));
    assert.ok(s.includes('ShellPreferenceTransaction.Apply(desired, ReadRaw, WriteRaw, () => { })'));
    assert.ok(s.includes('SafeModeService.IsSafeMode || WindowsUpdateGuard.RequiresReview'));
  }
  const transaction=read('src/Services/ShellPreferenceTransaction.cs');
  assert.ok(transaction.includes('if (changes.Length == 0) return false;'));
  assert.ok(transaction.includes('attempted.AsEnumerable().Reverse()'));
  assert.ok(transaction.includes('if (read(pair.Key) != pair.Value)'));
});
test('Start extends legacy backups and shares checked preference transactions', () => {
  const service=read('src/Services/NativeStartPreferences.cs'), ui=read('src/UI/NativeStartSettingsForm.cs');
  for(const key of ['ShowRecentList','Start_TrackDocs']) { assert.ok(service.includes(`("${key}",`)); assert.ok(ui.includes(`Add(panel, "${key}"`)); }
  assert.ok(service.includes('Options.Take(3)'));
  assert.ok(service.includes('saved.TryAdd(item.Name, value)'));
  assert.ok(service.includes('ShellPreferenceTransaction.Apply(desired, ReadRaw, Write, BackupIfMissing)'));
  assert.ok(ui.includes('_loaded![pair.Key] != value'));
  assert.ok(ui.includes('NativeStartPreferences.ApplySelection(changes)'));
});
test('Explorer only snapshots and applies explicitly changed selections', () => {
  const ui=read('src/UI/OpsisExplorerStudioForm.cs');
  assert.ok(ui.includes('SelectedValues().Where(p => _loaded[p.Key] != p.Value)'));
  assert.ok(ui.indexOf('if (changed.Count == 0)') < ui.indexOf('OpsisRecoveryHub.Snapshot("Before Explorer Studio preference changes")'));
  assert.ok(ui.includes('ExplorerViewProfiles.ApplyOptions(changed)'));
});
test('native multi-display taskbar routing uses existing allowlisted backup owner', () => {
  const ui=read('src/UI/MainWindow.cs'), service=read('src/Services/TaskbarViewProfiles.cs');
  assert.ok(service.includes('(Advanced, "MMTaskbarMode")'));
  assert.ok(ui.includes('TaskbarViewProfiles.ApplyOption("MMTaskbarMode", value)'));
});
