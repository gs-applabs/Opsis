[CmdletBinding()]
param(
    [Parameter(Mandatory)] [string] $Compiler,
    [Parameter(Mandatory)] [string] $CertificateThumbprint,
    [string] $OpsisAppVersion = "3.0.0.3200",
    [version] $ExplorerIdentityVersion,
    [string] $CrawlerSetup,
    [string] $WallpapersSetup,
    [string] $WallpapersSha256,
    [switch] $RequireOptionalPayloads,
    [string] $CrawlerSha256 = '0971cc56e64f25fe608303144ac18f8854cc1c41f894d4989693ffbff8af0fc5'
)
$ErrorActionPreference = 'Stop'
$compilerPath = (Resolve-Path -LiteralPath $Compiler).Path
$repo = Split-Path $PSScriptRoot
$destination = Join-Path $repo 'publish'
$dotnetProject = Join-Path $repo 'Opsis.csproj'
$installer = Join-Path $repo 'installer.iss'
$arguments = @("/DPublishDir=$destination")
if ($RequireOptionalPayloads -and (!$CrawlerSetup -or !$WallpapersSetup)) { throw "Full installer requires verified Crawler and wallpapers setup files." }
if ($CrawlerSetup) {
    $crawlerPath = (Resolve-Path -LiteralPath $CrawlerSetup).Path
    $hash = (Get-FileHash -LiteralPath $crawlerPath -Algorithm SHA256).Hash
    if ($hash -ne $CrawlerSha256) { throw 'The Crawler setup does not match the selected release SHA-256.' }
    $arguments += "/DCrawlerSetup=$crawlerPath"
}

if ($WallpapersSetup) {
    if ($WallpapersSha256 -notmatch '^[0-9a-fA-F]{64}$') { throw 'Provide verified wallpaper setup SHA-256.' }
    $wallpaperPath = (Resolve-Path -LiteralPath $WallpapersSetup).Path
    if ((Get-FileHash -LiteralPath $wallpaperPath -Algorithm SHA256).Hash -ne $WallpapersSha256) { throw 'Wallpaper setup checksum mismatch.' }
    $arguments += "/DWallpapersSetup=$wallpaperPath"
}

dotnet publish $dotnetProject --configuration Release --runtime win-x64 --self-contained false -o $destination "-p:OpsisAppVersion=$OpsisAppVersion"
if ($LASTEXITCODE -ne 0) { throw 'Opsis publish failed.' }
& (Join-Path $PSScriptRoot 'explorer/Build-Explorer.ps1') -OutputDirectory $destination
$identityArgs = @{ PublishedDirectory=$destination; OutputPackage=(Join-Path $destination 'OpsisExplorer.msix'); CertificateThumbprint=$CertificateThumbprint }
if ($ExplorerIdentityVersion) { $identityArgs.IdentityVersion = $ExplorerIdentityVersion }
& (Join-Path $PSScriptRoot 'explorer/Build-ExplorerIdentity.ps1') @identityArgs
& (Join-Path $repo 'tools/emit-release-identity.ps1') -PublishDir $destination -OutFile (Join-Path $repo 'Output/release-identity.json')
& $compilerPath @arguments $installer
if ($LASTEXITCODE -ne 0) { throw 'Inno Setup compilation failed.' }
