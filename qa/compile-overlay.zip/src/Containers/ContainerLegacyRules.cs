using System.Text.Json;
using Opsis.Containers;

namespace MotionDesk.Containers;

// Compatibility shortcuts for the existing organization engine, not a second watcher.
internal static class ContainerLegacyRules
{
    internal const string OriginalExtensionsKey = "opsisOriginalAutoCollectExtensions";
    internal static bool TryExtensions(string raw, out string[] extensions)
    {
        extensions = [];
        if (raw.Length > 1024) return false;
        var parts = raw.Split(new[] { ',', ';', ' ', '\t', '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);
        var values = parts.Select(p => (p.StartsWith("*.", StringComparison.Ordinal) ? p[2..] : p.StartsWith('.') ? p[1..] : p).ToLowerInvariant()).ToArray();
        if (values.Any(p => p.Length is < 1 or > 32 || !p.All(char.IsLetterOrDigit))) return false;
        extensions = values.Distinct(StringComparer.OrdinalIgnoreCase).ToArray();
        return extensions.Length <= 64;
    }

    internal static string RuleName(string id) => "OPSIS legacy extensions [" + id + "]";
    private static bool Owned(DesktopFileRule rule, string id) => rule.Native &&
        rule.Target.Equals(id, StringComparison.OrdinalIgnoreCase) && rule.Name == RuleName(id);
    internal static string InitialExtensions(Container model, DesktopOrganization? package)
    {
        var rule = package?.Rules.FirstOrDefault(r => Owned(r, model.Id));
        if (rule != null && rule.Conditions.Length == 2 &&
            rule.Conditions[0].ValueKind == JsonValueKind.Object && rule.Conditions[0].TryGetProperty("value", out var val) && val.ValueKind == JsonValueKind.Array)
            return string.Join(", ", val.EnumerateArray().Where(x => x.ValueKind == JsonValueKind.String).Select(x => x.GetString()));
        return model.Extra?.TryGetValue(OriginalExtensionsKey, out var old) == true && old.ValueKind == JsonValueKind.String
            ? old.GetString() ?? "" : "";
    }

    internal static bool MatchesExtension(string path, string[] extensions) =>
        extensions.Contains(Path.GetExtension(path).TrimStart('.'), StringComparer.OrdinalIgnoreCase);

    internal static DesktopOrganization SetExtensions(DesktopOrganization package, string id, string[] extensions)
    {
        var rules = package.Rules.ToList();
        int index = rules.FindIndex(r => Owned(r, id));
        if (extensions.Length == 0)
        {
            if (index < 0) return package;
            rules.RemoveAll(r => Owned(r, id));
            return package with { Rules = rules.ToArray() };
        }
        var conditions = new[] {
            JsonSerializer.SerializeToElement(new { cond = "ext", value = extensions }),
            JsonSerializer.SerializeToElement(new { cond = "filesOnly" })
        };
        var rule = new DesktopFileRule(RuleName(id), id, conditions, Priority: false, Enabled: true, Native: true);
        if (index >= 0 && rules[index].Enabled && !rules[index].Priority &&
            rules[index].Conditions.Select(c => c.GetRawText()).SequenceEqual(conditions.Select(c => c.GetRawText())) &&
            package.KeepUpdated && package.RulesEnabled) return package;
        if (index < 0) rules.Add(rule); else rules[index] = rule;
        return package with { Rules = rules.ToArray(), RulesEnabled = true, KeepUpdated = true };
    }

    internal static DesktopOrganization SetDefault(DesktopOrganization package, string id, bool enabled)
    {
        if (!enabled) return package.DefaultTarget == id ? package with { DefaultTarget = null } : package;
        if (package.DefaultTarget == id && package.RulesEnabled && package.KeepUpdated) return package;
        return package with { DefaultTarget = id, RulesEnabled = true, KeepUpdated = true };
    }
}
