using Opsis.Containers;
using System.Text.Json;
using MotionDesk.Services;

namespace MotionDesk.Containers;

internal static class ContainerTitleFrame
{
    internal const string Key = "opsis.titleFrameRadius";
    internal static int Radius(Container model)
    {
        if (model.Extra != null && model.Extra.TryGetValue(Key, out var value) && value.ValueKind == JsonValueKind.Number && value.TryGetInt32(out int radius))
            return Math.Clamp(radius, 0, 32);
        var material = DesktopMaterials.Get(DesktopSurface.Containers);
        return material.UsesCustom ? material.Radius : 14;
    }
    internal static void SetRadius(Container model, int radius) =>
        (model.Extra ??= new())[Key] = JsonSerializer.SerializeToElement(Math.Clamp(radius, 0, 32));
}
