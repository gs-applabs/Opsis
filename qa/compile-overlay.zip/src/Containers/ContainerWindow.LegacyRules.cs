using MotionDesk.UI;

namespace MotionDesk.Containers;

internal sealed partial class ContainerWindow
{
    private bool _legacyCollectBusy;
    private static string LegacyText(string en, string el) => MainWindow.StudioText(en, el);

    private string[]? AskLegacyExtensions(ContainerHost host)
    {
        string? raw = Ask(LegacyText("File extensions (e.g. pdf, txt, jpg)", "Επεκτάσεις αρχείων (π.χ. pdf, txt, jpg)"),
            ContainerLegacyRules.InitialExtensions(Model, host.OrganizationStatus));
        if (raw == null) return null;
        if (ContainerLegacyRules.TryExtensions(raw, out var extensions)) return extensions;
        MessageBox.Show(this, LegacyText("Use up to 64 extensions containing letters or digits, separated by commas. No paths or wildcards other than *.ext.",
            "Έως 64 επεκτάσεις με γράμματα ή ψηφία, χωρισμένες με κόμμα. Όχι διαδρομές ή χαρακτήρες μπαλαντέρ εκτός από *.ext."), Model.Title);
        return null;
    }

    private bool ConfirmLegacyRouting(string action) => MessageBox.Show(this, action + "\n\n" + LegacyText(
        "This uses the shared desktop routing engine. It enables global file routing and periodic updates, including other enabled rules. Existing and new matching desktop files may appear as references; no original file is moved or deleted. Higher-priority rules win; otherwise earlier rules win. With tabs, the existing container-level destination is used.",
        "Χρησιμοποιείται ο κοινός μηχανισμός ταξινόμησης. Ενεργοποιείται η γενική ταξινόμηση και η περιοδική ενημέρωση, μαζί με τους άλλους ενεργούς κανόνες. Υφιστάμενα και νέα αρχεία που ταιριάζουν μπορεί να εμφανιστούν ως αναφορές, χωρίς μετακίνηση ή διαγραφή πρωτοτύπων. Προηγούνται οι κανόνες υψηλής προτεραιότητας και μετά οι προγενέστεροι. Με καρτέλες χρησιμοποιείται ο υφιστάμενος προορισμός του container."),
        Model.Title, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes;

    private void ConfigureLegacyExtensions(ContainerHost host)
    {
        if (!CanEditItems) return;
        var extensions = AskLegacyExtensions(host);
        if (extensions == null) return;
        if (extensions.Length == 0)
        {
            if (MessageBox.Show(this, LegacyText("Remove only this container's legacy extension rule?", "Κατάργηση μόνο του κανόνα επεκτάσεων αυτού του container;"), Model.Title,
                MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) != DialogResult.Yes) return;
        }
        else if (!ConfirmLegacyRouting(LegacyText("Activate extension rule: ", "Ενεργοποίηση κανόνα επεκτάσεων: ") + string.Join(", ", extensions))) return;
        host.ConfigureLegacyRouting(Model.Id, extensions, null);
    }

    private void ConfigureLegacyDefault(ContainerHost host, bool enabled)
    {
        if (!CanEditItems) return;
        if (enabled)
        {
            string prior = host.OrganizationStatus?.DefaultTarget is { } previous
                ? host.Containers().FirstOrDefault(c => c.Id == previous)?.Title ?? previous : LegacyText("None", "Κανένας");
            if (!ConfirmLegacyRouting(LegacyText("Set this container as fallback destination. Current destination: ",
                "Ορισμός αυτού του container ως εφεδρικού προορισμού. Τρέχων προορισμός: ") + prior)) return;
        }
        else if (MessageBox.Show(this, LegacyText("Clear this default destination?", "Κατάργηση αυτού του προεπιλεγμένου προορισμού;"), Model.Title,
            MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) != DialogResult.Yes) return;
        host.ConfigureLegacyRouting(Model.Id, null, enabled);
    }

    private async Task CollectLegacyFilesAsync(ContainerHost host)
    {
        if (_legacyCollectBusy || !CanEditItems) return;
        var extensions = AskLegacyExtensions(host);
        if (extensions == null || extensions.Length == 0) return;
        if (MessageBox.Show(this, LegacyText("Add up to 500 matching local desktop file references to this container (first tab if present)? Original files stay unchanged; references already assigned manually elsewhere are skipped.",
            "Προσθήκη έως 500 αναφορών αντίστοιχων τοπικών αρχείων επιφάνειας στο container (στην πρώτη καρτέλα αν υπάρχει); Τα πρωτότυπα παραμένουν ανέπαφα και παραλείπονται οι ήδη καταχωρισμένες χειροκίνητες αναφορές."), Model.Title,
            MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) != DialogResult.Yes) return;
        _legacyCollectBusy = true;
        try
        {
            int count = await host.CollectLegacyReferencesAsync(Model.Id, extensions);
            if (!IsDisposed) MessageBox.Show(this, LegacyText("References added: ", "Προστέθηκαν αναφορές: ") + count, Model.Title);
        }
        catch (OperationCanceledException) { }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or ArgumentException or InvalidOperationException)
        { if (!IsDisposed) MessageBox.Show(this, ex.Message, Model.Title); }
        finally { _legacyCollectBusy = false; }
    }
}
