using System.Text.Json;
using Opsis.Containers;

namespace MotionDesk.Containers;

// Visual slots only. Never create a ContainerItem for a spacer: file operations, history,
// desktop visibility, accessibility and routing continue to receive real references only.
internal static class ContainerSpacers
{
    internal const string Key = "opsisSpacerSlots";
    private const string LegacyKey = "opsisOriginalSpacers";
    private const string MigratedKey = "opsisSpacerSlotsMigrated";
    internal const int Limit = 128;

    internal static int[] Read(Dictionary<string, JsonElement>? extra, int count)
    {
        if (extra?.TryGetValue(Key, out var data) != true || data.ValueKind != JsonValueKind.Array) return [];
        return data.EnumerateArray().Take(Limit).Where(x => x.ValueKind == JsonValueKind.Number && x.TryGetInt32(out _))
            .Select(x => Math.Clamp(x.GetInt32(), 0, count)).Order().ToArray();
    }

    internal static void Set(Container model, IEnumerable<int> slots) =>
        (model.Extra ??= new())[Key] = JsonSerializer.SerializeToElement(slots.Take(Limit).Select(x => Math.Max(0, x)).Order().ToArray());
    internal static void Set(ContainerTab tab, IEnumerable<int> slots) =>
        (tab.Extra ??= new())[Key] = JsonSerializer.SerializeToElement(slots.Take(Limit).Select(x => Math.Max(0, x)).Order().ToArray());

    internal static void NormalizeLegacy(Container model)
    {
        if (model.Extra?.TryGetValue(LegacyKey, out var raw) != true || raw.ValueKind != JsonValueKind.Array ||
            model.Extra.ContainsKey(MigratedKey)) return;
        var byTab = new Dictionary<int, List<int>>();
        foreach (var x in raw.EnumerateArray().Take(Limit))
        {
            if (x.ValueKind != JsonValueKind.Object || !x.TryGetProperty("TabIndex", out var t) ||
                t.ValueKind != JsonValueKind.Number || !t.TryGetInt32(out int tab) ||
                !x.TryGetProperty("BeforeFileCount", out var b) || b.ValueKind != JsonValueKind.Number ||
                !b.TryGetInt32(out int before)) continue;
            if (tab < -1 || tab >= model.Tabs.Count) continue;
            if (model.Tabs.Count > 0 && tab == -1)
                tab = 0; // old root items were appended to first tab; exact original offset is not recoverable from R6.
            if (!byTab.TryGetValue(tab, out var list)) byTab[tab] = list = [];
            list.Add(Math.Max(0, before));
        }
        foreach (var (tab, positions) in byTab)
        {
            if (tab == -1 && !model.Extra.ContainsKey(Key)) Set(model, positions.Select(p => Math.Min(p, model.Items.Count)).Order());
            else if (tab >= 0 && model.Tabs[tab].Extra?.ContainsKey(Key) != true)
                Set(model.Tabs[tab], positions.Select(p => Math.Min(p, model.Tabs[tab].Items.Count)).Order());
        }
        // Keep original raw metadata for audit and rollback; do not reimport after user edits.
        model.Extra[MigratedKey] = JsonSerializer.SerializeToElement(true);
    }

    internal static bool IsManualUnfiltered(Container model)
    {
        static bool Matches(Dictionary<string, JsonElement>? extra, string key, string expected) =>
            extra?.TryGetValue(key, out var value) != true || value.ValueKind != JsonValueKind.String || value.GetString() == expected;
        return Matches(model.Extra, ContainerWindow.SortKey, "manual") && Matches(model.Extra, "opsisContainerViewFilter", "all");
    }

    internal static int[] Active(Container model) => model.TabsEnabled && model.Tabs.Count > 0
        ? Read(model.Tabs[Math.Clamp(model.CurrentTab, 0, model.Tabs.Count - 1)].Extra, model.Tabs[Math.Clamp(model.CurrentTab, 0, model.Tabs.Count - 1)].Items.Count)
        : Read(model.Extra, model.Items.Count);

    internal static void SetActive(Container model, IEnumerable<int> slots)
    {
        if (model.TabsEnabled && model.Tabs.Count > 0) Set(model.Tabs[Math.Clamp(model.CurrentTab, 0, model.Tabs.Count - 1)], slots);
        else Set(model, slots);
    }

    internal static void ClampForList(Container model, List<ContainerItem> items)
    {
        // Persist the new bound after deletion, rather than letting an old gap drift back
        // when a later addition increases the item count again. No write when unchanged.
        if (ReferenceEquals(items, model.Items))
        {
            var positions = Read(model.Extra, int.MaxValue);
            if (positions.Any(p => p > items.Count)) Set(model, positions.Select(p => Math.Min(p, items.Count)));
        }
        else if (model.Tabs.FirstOrDefault(t => ReferenceEquals(t.Items, items)) is { } tab)
        {
            var positions = Read(tab.Extra, int.MaxValue);
            if (positions.Any(p => p > items.Count)) Set(tab, positions.Select(p => Math.Min(p, items.Count)));
        }
    }

    // Gaps are anchored by the number of real items before the gap, not by a path.
    internal static int SlotFor(int item, int[]? gaps) => item + (gaps?.Count(g => g <= item) ?? 0);
    internal static int ItemAt(int slot, int[]? gaps)
    {
        if (slot < 0) return -1;
        int passed = 0;
        foreach (int gap in gaps ?? [])
        {
            int blank = gap + passed;
            if (slot == blank) return -1;
            if (slot < blank) break;
            passed++;
        }
        return slot - passed;
    }
    internal static int ItemsBefore(int slot, int[]? gaps)
    {
        int passed = 0;
        foreach (int gap in gaps ?? []) { if (gap + passed >= slot) break; passed++; }
        return Math.Max(0, slot - passed);
    }
}
