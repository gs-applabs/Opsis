using Opsis.Containers;

namespace MotionDesk.Containers;

internal sealed partial class ContainerHost
{
    internal bool ConfigureLegacyRouting(string id, string[]? extensions, bool? defaultTarget)
    {
        Flush();
        if (!_service.Snapshot().Containers.Any(c => c.Id == id && SupportsTabs(c) && !c.Locked)) return false;
        var package = _organizationPackage ?? EmptyOrganization;
        var updated = extensions != null ? ContainerLegacyRules.SetExtensions(package, id, extensions)
            : ContainerLegacyRules.SetDefault(package, id, defaultTarget == true);
        if (ReferenceEquals(updated, package)) return true;
        // Use the existing backup and organization path. No duplicated timer or shell hook.
        Backup(force: true);
        UpdateFileRules(_ => updated);
        return true;
    }

    internal async Task<int> CollectLegacyReferencesAsync(string id, string[] extensions)
    {
        if (_organizationShutdown.IsCancellationRequested) return 0;
        var token = _organizationShutdown.Token;
        var user = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);
        var common = Environment.GetFolderPath(Environment.SpecialFolder.CommonDesktopDirectory);
        var candidates = await Task.Run(() => DesktopFiles.CollectMatching(user, common, extensions, token), token);
        if (token.IsCancellationRequested || candidates.Count == 0) return 0;
        Flush();
        int added = 0;
        _service.Update(doc =>
        {
            var model = doc.Containers.FirstOrDefault(c => c.Id == id);
            if (model == null || model.Locked || !SupportsTabs(model)) return false;
            // Keep existing manual ownership (including other tabs/containers) intact.
            var assigned = doc.Containers.SelectMany(ContainerLegacyParity.ReferencePaths).ToHashSet(StringComparer.OrdinalIgnoreCase);
            var items = candidates.Where(c => assigned.Add(c.Path)).ToList();
            if (items.Count == 0) return false;
            // Explicit collection goes to the first tab, consistently with container-level routing.
            var destination = model.TabsEnabled && model.Tabs.Count > 0 ? model.Tabs[0].Items : model.Items;
            _layoutHistory.Remember(model);
            if (!_layoutHistorySave.Enabled) _layoutHistorySave.Start();
            destination.AddRange(items);
            ContainerLegacyParity.RecordAdded(model, items.Select(c => c.Path));
            added = items.Count;
            return true;
        });
        if (added > 0) { Sync(); _organizationRevision++; RefreshOrganization(forceRules: true); }
        return added;
    }
}
