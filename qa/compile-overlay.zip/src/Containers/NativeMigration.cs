using Opsis.Containers;
using System.Text.Json;
using LegacyState = MotionDesk.Widgets.DeskContainerState;
using LegacyItem = MotionDesk.Widgets.ContainerItem;

namespace MotionDesk.Containers
{
    /// <summary>
    /// First start of the native containers on a machine that ran the 2.4.x engine: the legacy data is imported READ-ONLY (the old folder stays untouched, so going back to 2.4.x
    /// loses nothing). The Default profile becomes the live layout, every other profile becomes a named layout snapshot. Runs only when the native data file does not exist yet.
    /// </summary>
    internal static class NativeMigration
    {
        public static string? ImportIfNeeded(ContainersStore store, string legacyRoot, IReadOnlyList<MonitorInfo> monitors)
        {
            if (File.Exists(store.Path)) return null;                         // never overwrites what the user already has
            if (!Directory.Exists(Path.Combine(legacyRoot, "Profiles")))
                return ImportOriginalContainers(store, Path.Combine(Path.GetDirectoryName(legacyRoot)!, "deskcontainers"), monitors);
            var (docs, report) = LegacyImporter.Import(legacyRoot, monitors);
            if (docs.Count == 0)
                return ImportOriginalContainers(store, Path.Combine(Path.GetDirectoryName(legacyRoot)!, "deskcontainers"), monitors)
                    ?? "legacy import: nothing importable (" + string.Join("; ", report.Warnings) + ")";
            store.Save(docs[0]);
            var snapDir = Path.Combine(Path.GetDirectoryName(Path.GetFullPath(store.Path)) ?? ".", "container-snapshots");
            for (int i = 1; i < docs.Count; i++) ContainerSnapshots.Save(docs[i], snapDir, docs[i].Profile);
            return $"legacy import: {report.Containers} containers, {report.Items} items, {report.Profiles} profile(s) ({docs.Count - 1} as snapshots), {report.NotImported.Count} not carried";
        }

        // Import the original pre-2.2 engine only when there is no native file and no importable newer profile.
        // Never merge guessed identities into a user's current layout or delete any old files.
        internal static string? ImportOriginalContainers(ContainersStore store, string folder, IReadOnlyList<MonitorInfo> monitors)
        {
            if (File.Exists(store.Path) || !Directory.Exists(folder)) return null;
            var (doc, issues) = ReadOriginalContainers(folder, monitors);
            if (doc.Containers.Count == 0) return "original container import: nothing imported; " + string.Join("; ", issues);
            if (File.Exists(store.Path)) return "original container import: native file already exists";
            store.Save(doc);
            return $"original container import: {doc.Containers.Count} containers; {issues.Count} warnings; source left intact";
        }

        // Shared read-only conversion for first start and explicit snapshot import.
        internal static (ContainersDocument Document, List<string> Issues) ReadOriginalContainers(string folder, IReadOnlyList<MonitorInfo> monitors)
        {
            var doc = new ContainersDocument();
            var issues = new List<string>();
            var paths = Directory.EnumerateFiles(folder, "*_config.json").Take(501).ToArray();
            if (paths.Length > 500) throw new InvalidDataException("Legacy folder contains more than 500 containers.");
            Array.Sort(paths, StringComparer.OrdinalIgnoreCase);
            foreach (string path in paths)
            {
                try
                {
                    if (new FileInfo(path).Length > 16 * 1024 * 1024) throw new InvalidDataException("Legacy container exceeds size limit.");
                    var old = JsonSerializer.Deserialize<LegacyState>(File.ReadAllText(path), new JsonSerializerOptions { PropertyNameCaseInsensitive = true });
                    if (old == null) throw new InvalidDataException("Empty legacy state.");
                    doc.Containers.Add(ConvertOriginal(old, Path.GetFileName(path), monitors, issues));
                }
                catch (Exception ex) when (ex is IOException or InvalidDataException or UnauthorizedAccessException or JsonException or ArgumentException)
                { issues.Add(Path.GetFileName(path) + ": " + ex.Message); }
            }
            (doc.Extra ??= new())["opsisOriginalImportIssues"] = JsonSerializer.SerializeToElement(issues);
            return (doc, issues);
        }

        internal static (List<ContainersDocument> Documents, List<string> Issues) ReadLegacyProfiles(string folder, IReadOnlyList<MonitorInfo> monitors)
        {
            if (!Directory.Exists(folder)) throw new DirectoryNotFoundException(folder);
            var documents = new List<ContainersDocument>();
            var issues = new List<string>();
            if (Directory.Exists(Path.Combine(folder, "Profiles")))
            {
                var (profiles, report) = LegacyImporter.Import(folder, monitors);
                documents.AddRange(profiles.Where(d => d.Containers.Count > 0));
                issues.AddRange(report.Warnings.Select(w => w.ToString() ?? "Legacy warning"));
                issues.AddRange(report.NotImported.Select(w => w.ToString() ?? "Unsupported legacy feature"));
            }
            else
            {
                var (original, warnings) = ReadOriginalContainers(folder, monitors);
                if (original.Containers.Count > 0) documents.Add(original);
                issues.AddRange(warnings);
            }
            if (documents.Count > 100) throw new InvalidDataException("More than 100 importable profiles.");
            return (documents, issues);
        }

        // Fixed safe alphabet and unique suffix avoid path traversal and collisions with existing snapshots.
        internal static string ImportedSnapshotName(string? profile)
        {
            string label = new string((profile ?? "Original").Take(48).Select(c => char.IsLetterOrDigit(c) ? c : '-').ToArray()).Trim('-');
            if (label.Length == 0) label = "Original";
            return "Legacy-" + label + "-" + Guid.NewGuid().ToString("N");
        }

        internal static string SaveImportedSnapshot(ContainersDocument document, string storePath)
        {
            if (document.Containers.Count == 0) throw new InvalidDataException("Empty imported profile.");
            string name = ImportedSnapshotName(document.Profile);
            string directory = Path.Combine(Path.GetDirectoryName(Path.GetFullPath(storePath)) ?? ".", "container-snapshots");
            ContainerSnapshots.Save(document, directory, name);
            return name;
        }

        internal static Container ConvertOriginal(LegacyState old, string sourceName, IReadOnlyList<MonitorInfo> monitors, List<string> issues)
        {
            var id = LayoutImport.StableId("legacy-original:" + sourceName);
            bool portal = !string.IsNullOrWhiteSpace(old.PortalFolder);
            var model = new Container
            {
                Id = id, Title = string.IsNullOrWhiteSpace(old.Title) ? "Container" : old.Title,
                Geometry = LegacyImporter.Normalize(old.X, old.Y, Math.Clamp(old.Width, 120, 16000), Math.Clamp(old.Height, 60, 16000), monitors),
                Locked = old.IsLocked, RolledUp = old.IsRolledUp, ExcludeFromQuickHide = old.ExcludeFromQuickHide,
                UnrolledHeight = Math.Clamp(old.Height, 60, 16000),
                Kind = portal ? ContainerKind.Portal : old.IsNote ? ContainerKind.Note : ContainerKind.Data,
                Extra = new()
            };
            model.Appearance.IconSize = Math.Clamp(old.IconPx, 16, 128);
            model.Appearance.TintOpacity = double.IsFinite(old.WindowOpacity) ? (int)Math.Round(Math.Clamp(old.WindowOpacity, 0, 1) * 100) : 100;
            if (old.AccentColorArgb != 0)
            {
                var color = Color.FromArgb(old.AccentColorArgb);
                model.Appearance.FrameColor = $"#{color.R:X2}{color.G:X2}{color.B:X2}";
            }
            model.TitleBar.FontFamily = string.IsNullOrWhiteSpace(old.TitleFontFamily) ? "Segoe UI" : old.TitleFontFamily;
            model.TitleBar.FontSize = float.IsFinite(old.TitleFontSize) ? Math.Clamp(old.TitleFontSize, 6, 36) : 12;
            model.Extra![ContainerLegacyParity.ShowLabelsKey] = JsonSerializer.SerializeToElement(old.ShowLabels);
            model.Extra[ContainerWindow.SortKey] = JsonSerializer.SerializeToElement(old.SortMode switch
            {
                "Name" => "name", "Size" => "size", "ItemType" => "type", "DateModified" => "modified",
                "DateCreated" => "created", "DateAdded" => "added", "TimesOpened" => "opened-desc", _ => "manual"
            });
            // The newer rule engine routes existing desktop files as well. Do not automatically enable old new-file rules:
            // preserve their exact values for an explicit migration/confirmation rather than change their semantics.
            model.Extra["opsisOriginalAutoCollectExtensions"] = JsonSerializer.SerializeToElement(old.AutoCollectExtensions ?? "");
            model.Extra["opsisOriginalDefaultForNewIcons"] = JsonSerializer.SerializeToElement(old.PlaceNewIconsHereByDefault);
            model.Extra["opsisOriginalSource"] = JsonSerializer.SerializeToElement(sourceName);
            if (!string.IsNullOrWhiteSpace(old.AutoCollectExtensions) || old.PlaceNewIconsHereByDefault)
                issues.Add(sourceName + ": original auto-collect/default rule preserved but requires explicit activation in the new rule engine.");
            var history = new Dictionary<string, ContainerLegacyParity.History>(StringComparer.OrdinalIgnoreCase);
            static bool LocalFolder(string path)
            {
                try { return DesktopFiles.IsLocalPath(path) && new DriveInfo(Path.GetPathRoot(path)!).DriveType == DriveType.Fixed && Directory.Exists(path); }
                catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or ArgumentException or NotSupportedException or System.Security.SecurityException) { return false; }
            }
            var spacers = new List<object>();
            List<ContainerItem> ConvertItems(IEnumerable<LegacyItem> items, int tabIndex = -1, HashSet<string>? excluded = null, int offset = 0)
            {
                var converted = new List<ContainerItem>();
                int position = -1;
                foreach (var item in items)
                {
                    position++;
                    if (item == null || string.IsNullOrWhiteSpace(item.Path)) continue;
                    if (item.Path.StartsWith("::spacer::", StringComparison.Ordinal))
                    {
                        spacers.Add(new { TabIndex = tabIndex, Position = position, BeforeFileCount = offset + converted.Count });
                        issues.Add(sourceName + ": spacer position retained for manual layout; original root-to-tab positions may be approximate");
                        continue;
                    }
                    if (!Path.IsPathFullyQualified(item.Path))
                    { issues.Add(sourceName + ": unsupported non-filesystem reference preserved in original file"); continue; }
                    if (excluded?.Contains(item.Path) == true || converted.Any(i => i.Path.Equals(item.Path, StringComparison.OrdinalIgnoreCase))) continue;
                    var added = item.DateAdded == DateTime.MinValue ? (DateTime?)null : item.DateAdded.ToUniversalTime();
                    if (!history.ContainsKey(item.Path)) history[item.Path] = new(added, Math.Max(0, item.OpenCount));
                    converted.Add(new ContainerItem
                    {
                        Id = LayoutImport.StableId(id + ":" + item.Path), Path = item.Path,
                        DisplayName = Path.GetFileName(item.Path.TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar)),
                        // Probe only fixed local drives, never network/removable references.
                        IsFolder = LocalFolder(item.Path)
                    });
                }
                return converted;
            }
            if (portal) model.Source = old.PortalFolder;
            else if (old.IsNote) model.Source = old.NoteText ?? "";
            else
            {
                var originals = old.Items ?? (old.Paths ?? []).Select(p => new LegacyItem { Path = p }).ToList();
                if (old.Tabs is { Count: > 0 })
                {
                    foreach (var tab in old.Tabs)
                        model.Tabs.Add(new ContainerTab { Name = string.IsNullOrWhiteSpace(tab?.Name) ? "Tab" : tab.Name, Items = ConvertItems(tab?.Items ?? [], model.Tabs.Count) });
                    var tabPaths = model.Tabs.SelectMany(t => t.Items).Select(i => i.Path).ToHashSet(StringComparer.OrdinalIgnoreCase);
                    model.Tabs[0].Items.AddRange(ConvertItems(originals, 0, tabPaths, model.Tabs[0].Items.Count));
                    model.TabsEnabled = true;
                    model.CurrentTab = Math.Clamp(old.ActiveTab, 0, model.Tabs.Count - 1);
                    ContainerHost.EnsureTabTargets(model);
                }
                else model.Items = ConvertItems(originals);
            }
            if (spacers.Count > 0)
            {
                model.Extra["opsisOriginalSpacers"] = JsonSerializer.SerializeToElement(spacers);
                ContainerSpacers.NormalizeLegacy(model);
            }
            model.Extra[ContainerLegacyParity.HistoryKey] = JsonSerializer.SerializeToElement(history);
            return model;
        }
    }
}
