using System.Collections.Specialized;
using Microsoft.VisualBasic.FileIO;
using MotionDesk.Services;
using MotionDesk.UI;
using Opsis.Containers;

namespace MotionDesk.Containers;

internal sealed partial class ContainerWindow
{
    internal const string AutoHeightKey = "opsisAutoHeight";
    internal static bool AutoHeightOf(Container item) => item.Extra?.TryGetValue(AutoHeightKey, out var value) == true &&
        value.ValueKind == System.Text.Json.JsonValueKind.True;

    private readonly HashSet<string> _selection = new(StringComparer.OrdinalIgnoreCase);
    private string? _selectionAnchor;
    private readonly Dictionary<ContainerTab, int> _tabScroll = new();
    private string? _portalDirectory;
    private string? PortalDirectory => _portalDirectory ?? Model.Source;
    private bool CanWritePortal => Model.Kind == ContainerKind.Portal && !Model.Locked &&
        PortalDirectory is { Length: > 0 };

    private void UpdateSelection(int index, bool extend, bool toggle)
    {
        var items = Items;
        if (index < 0 || index >= items.Count)
        {
            if (!extend && !toggle) { _selection.Clear(); _selectionAnchor = null; _selected = -1; }
            return;
        }
        string path = items[index].Path;
        int anchor = extend && _selectionAnchor != null
            ? items.FindIndex(item => string.Equals(item.Path, _selectionAnchor, StringComparison.OrdinalIgnoreCase)) : -1;
        if (!toggle) _selection.Clear();
        if (anchor >= 0)
        {
            for (int i = Math.Min(anchor, index); i <= Math.Max(anchor, index); i++) _selection.Add(items[i].Path);
        }
        else
        {
            if (!toggle || !_selection.Remove(path)) _selection.Add(path);
            _selectionAnchor = path;
        }
        _selected = index;
    }

    private string[] SelectionPaths()
    {
        return Items.Where(item => _selection.Contains(item.Path)).Select(item => item.Path).ToArray();
    }

    private void RestoreFocus(string? path)
    {
        _selected = path == null ? -1 : Items.FindIndex(item => string.Equals(item.Path, path, StringComparison.OrdinalIgnoreCase));
        _selection.IntersectWith(Items.Select(item => item.Path));
    }

    private void ClearSelection()
    {
        _selection.Clear();
        _selected = -1;
        _selectionAnchor = null;
    }

    private void RemoveReferences(IEnumerable<string> paths, bool restoreOriginal = true, List<ContainerItem>? from = null)
    {
        if (!CanEditItems) return;
        var source = from ?? BaseItems;
        var requested = paths.ToHashSet(StringComparer.OrdinalIgnoreCase);
        var removed = source.Where(item => requested.Contains(item.Path)).Select(item => item.Path).ToArray();
        if (removed.Length == 0) return;
        source.RemoveAll(item => requested.Contains(item.Path));
        ContainerSpacers.ClampForList(Model, source);
        _organizationMerged.Clear();
        _sortCache = null; _filteredInput = null;
        ClearSelection();
        if (restoreOriginal) foreach (var path in removed) ItemRemoved?.Invoke(path);
        _scroll = ItemLayout.ClampScroll(_scroll, Items.Count);
        Dirty();
        Changed?.Invoke(Model);
    }

    private static WeakReference<ContainerWindow>? _cutFrom;
    private static uint _cutSequence;
    [System.Runtime.InteropServices.DllImport("user32.dll")]
    private static extern uint GetClipboardSequenceNumber();

    private void CopySelection(bool cut)
    {
        var entries = new StringCollection();
        entries.AddRange(SelectionPaths());
        if (entries.Count == 0) return;
        try
        {
            var clipboard = new DataObject();
            clipboard.SetFileDropList(entries);
            if (cut && CanWritePortal)
                clipboard.SetData("Preferred DropEffect", new MemoryStream(BitConverter.GetBytes(2)));
            Clipboard.SetDataObject(clipboard, true, 4, 40);
            _cutFrom = cut && CanEditItems ? new WeakReference<ContainerWindow>(this) : null;
            _cutSequence = GetClipboardSequenceNumber();
        }
        catch (System.Runtime.InteropServices.ExternalException) { }
    }

    private void PasteSelection()
    {
        try
        {
            var data = Clipboard.GetDataObject();
            if (data?.GetData(DataFormats.FileDrop) is not string[] files || files.Length == 0) return;
            bool nativeCut = data.GetData("Preferred DropEffect") is MemoryStream effect && effect.Length >= 4 &&
                (BitConverter.ToInt32(effect.ToArray()) & 2) != 0;
            if (CanWritePortal) { TransferFiles(files, nativeCut); return; }
            if (!CanEditItems) return;
            var added = AddReferences(files, BaseItems, BaseItems.Count);
            if (added.Length == 0) return;
            if (_cutSequence == GetClipboardSequenceNumber() && _cutFrom?.TryGetTarget(out var source) == true && !source.IsDisposed && source != this)
                source.RemoveReferences(added, restoreOriginal: false);
            _cutFrom = null;
        }
        catch (System.Runtime.InteropServices.ExternalException) { }
    }

    private static readonly FileTransferJournal Transfers = new();

    private static bool IsNetworkPath(string path)
    {
        if (path.StartsWith(@"\\", StringComparison.Ordinal)) return true;
        try
        {
            var root = Path.GetPathRoot(Path.GetFullPath(path));
            return !string.IsNullOrWhiteSpace(root) && new DriveInfo(root).DriveType == DriveType.Network;
        }
        catch (Exception ex) when (ex is IOException or ArgumentException or NotSupportedException or UnauthorizedAccessException)
        { return false; }
    }

    private async void TransferFiles(string[] paths, bool move)
    {
        if (!CanWritePortal || PortalDirectory is not { } folder) return;
        // Network boundaries are intentional: show the actual source and destination
        // BEFORE writing. Never resolve symlinks or touch an unc path just for a preview.
        bool remoteTarget = IsNetworkPath(folder);
        bool crossingBoundary = paths.Any(source => IsNetworkPath(source) != remoteTarget);
        if (crossingBoundary)
        {
            string direction = move ? MainWindow.StudioText("Move", "Μετακίνηση") :
                MainWindow.StudioText("Copy", "Αντιγραφή");
            string shown = string.Join(Environment.NewLine, paths.Take(8));
            if (paths.Length > 8) shown += Environment.NewLine + $"… +{paths.Length - 8}";
            var prompt = direction + Environment.NewLine + Environment.NewLine +
                MainWindow.StudioText("From:", "Από:") + Environment.NewLine + shown +
                Environment.NewLine + Environment.NewLine +
                MainWindow.StudioText("To:", "Προς:") + Environment.NewLine + Path.GetFullPath(folder) +
                Environment.NewLine + Environment.NewLine +
                MainWindow.StudioText("This crosses a local/network boundary. Continue?",
                    "Η ενέργεια περνά μεταξύ τοπικού και δικτυακού δίσκου. Συνέχεια;");
            if (MessageBox.Show(this, prompt, MainWindow.StudioText("Confirm paths", "Επιβεβαίωση διαδρομών"),
                MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2) != DialogResult.Yes) return;
        }
        var result = await Transfers.TransferAsync(paths, folder, move);
        if (IsDisposed) return;
        if (result.Warnings.Length > 0 || result.WithoutUndo > 0)
        {
            string label = MainWindow.StudioText("File transfer", "Μεταφορά αρχείων");
            string message = string.Join(Environment.NewLine, result.Warnings);
            if (result.WithoutUndo > 0) message += Environment.NewLine + MainWindow.StudioText(
                "Some files moved without an undo record.", "Για ορισμένα αρχεία δεν δημιουργήθηκε ιστορικό αναίρεσης.");
            MessageBox.Show(this, message.Trim(), label, MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        RefreshPortal();
    }

    private async void UndoFileTransfer()
    {
        if (!Transfers.CanUndo) return;
        var outcome = await Transfers.UndoAsync((path, directory) =>
        {
            var drive = new DriveInfo(Path.GetPathRoot(path)!);
            if (drive.DriveType is not (DriveType.Fixed or DriveType.Removable))
                throw new IOException("The destination does not provide a local Recycle Bin.");
            if (directory) FileSystem.DeleteDirectory(path, UIOption.OnlyErrorDialogs, RecycleOption.SendToRecycleBin, UICancelOption.ThrowException);
            else FileSystem.DeleteFile(path, UIOption.OnlyErrorDialogs, RecycleOption.SendToRecycleBin, UICancelOption.ThrowException);
        });
        if (IsDisposed) return;
        RefreshPortal();
        if (outcome.Warnings.Length != 0)
        {
            MessageBox.Show(this, MainWindow.StudioText(
                "Undo stopped for items whose paths or contents changed.", "Η αναίρεση δεν εφαρμόστηκε στα στοιχεία των οποίων άλλαξε η θέση ή το περιεχόμενο.") +
                Environment.NewLine + string.Join(Environment.NewLine, outcome.Warnings),
                MainWindow.StudioText("Undo file transfer", "Αναίρεση μεταφοράς"), MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }

    private void OpenPortalFolder(string folder)
    {
        if (Model.Kind != ContainerKind.Portal || !Directory.Exists(folder)) return;
        _portalDirectory = folder;
        ClearSelection();
        _scroll = 0;
        RefreshPortal();
    }

    private bool PortalUp()
    {
        if (_portalDirectory == null || string.Equals(_portalDirectory, Model.Source, StringComparison.OrdinalIgnoreCase)) return false;
        string? parent = Path.GetDirectoryName(Path.TrimEndingDirectorySeparator(_portalDirectory));
        if (parent == null || !Directory.Exists(parent)) parent = Model.Source;
        if (parent == null) return false;
        OpenPortalFolder(parent);
        return true;
    }

    private string[] AddReferences(IEnumerable<string> paths, List<ContainerItem> destination, int index)
    {
        if (!CanEditItems) return [];
        var plan = DropRules.Plan(paths, destination, Math.Clamp(index, 0, destination.Count), Directory.Exists);
        if (plan.Effect != DropEffect.AddReference) return [];
        destination.InsertRange(plan.InsertAt, plan.Add);
        _organizationMerged.Clear();
        _sortCache = null; _filteredInput = null;
        var added = plan.Add.Select(item => item.Path).ToArray();
        ContainerLegacyParity.RecordAdded(Model, added);
        ItemsAdded?.Invoke(added);
        _scroll = ItemLayout.ClampScroll(_scroll, Items.Count);
        Dirty();
        Changed?.Invoke(Model);
        return added;
    }

    private int TabAt(Point point)
    {
        if (point.Y < Metrics.TitleBarHeight || point.Y >= Metrics.Top) return -1;
        return TabRects().FindIndex(bounds => bounds.Contains(point));
    }

    private void MoveTab(int from, int to)
    {
        if (!TabsOn || from < 0 || from >= Model.Tabs.Count || to < 0 || to >= Model.Tabs.Count || to == from) return;
        ContainerHost.EnsureTabTargets(Model);
        var selected = Model.Tabs[Math.Clamp(Model.CurrentTab, 0, Model.Tabs.Count - 1)];
        var tab = Model.Tabs[from];
        Model.Tabs.RemoveAt(from);
        Model.Tabs.Insert(to, tab);
        Model.CurrentTab = Model.Tabs.IndexOf(selected);
        _organizationMerged.Clear();
        Dirty();
        Changed?.Invoke(Model);
    }

    internal const string SortKey = "opsisSortMode";
    private string ItemSort => Model.Extra?.TryGetValue(SortKey, out var value) == true &&
        value.ValueKind == System.Text.Json.JsonValueKind.String ? value.GetString() ?? "manual" : "manual";

    private void ChooseSort(string order)
    {
        if (Model.Kind == ContainerKind.Note) return;
        string? focused = Items.ElementAtOrDefault(_selected)?.Path;
        (Model.Extra ??= new())[SortKey] = System.Text.Json.JsonSerializer.SerializeToElement(order);
        _sortCache = null; _filteredInput = null;
        RestoreFocus(focused);
        if (AutoHeightOf(Model)) LayoutHeight();
        _scroll = ItemLayout.ClampScroll(_scroll, Items.Count);
        Dirty();
        Changed?.Invoke(Model);
    }

    private List<ContainerItem>? _sortInput, _sortCache;
    private string? _sortMode;
    private CancellationTokenSource? _metadataSortCancel;
    private void CancelMetadataSort()
    {
        var pending = _metadataSortCancel;
        _metadataSortCancel = null;
        pending?.Cancel();
        pending?.Dispose();
    }
    private void QueueMetadataSort(List<ContainerItem> items, string order, List<ContainerItem> provisional)
    {
        CancelMetadataSort();
        var pending = _metadataSortCancel = new CancellationTokenSource();
        var token = pending.Token;
        var snapshot = items.ToArray();
        var history = ContainerLegacyParity.ReadHistory(Model);
        // The worker receives a snapshot. All control access and cache swaps stay on the UI thread.
        _ = Task.Run(() => ContainerLegacyParity.Sort(snapshot, order, history, token), token).ContinueWith(task =>
        {
            if (task.IsFaulted) { _ = task.Exception; return; }
            if (!task.IsCompletedSuccessfully || token.IsCancellationRequested) return;
            try
            {
                BeginInvoke(new Action(() =>
                {
                    if (IsDisposed || token.IsCancellationRequested || !ReferenceEquals(_sortCache, provisional) ||
                        !ReferenceEquals(_sortInput, items) || ItemSort != order) return;
                    string? focused = Items.ElementAtOrDefault(_selected)?.Path;
                    _sortCache = task.Result;
                    _filteredInput = null;
                    RestoreFocus(focused);
                    _scroll = ItemLayout.ClampScroll(_scroll, Items.Count);
                    Dirty();
                }));
            }
            catch (InvalidOperationException) { } // Window closed before the worker completed.
        }, CancellationToken.None, TaskContinuationOptions.ExecuteSynchronously, TaskScheduler.Default);
    }
    private List<ContainerItem> Sorted(List<ContainerItem> items)
    {
        var order = ItemSort;
        if (order == "manual") { if (_metadataSortCancel != null) CancelMetadataSort(); return items; }
        // Mutations invalidate the sorted view; static lists reuse it while painting.
        if (!ReferenceEquals(_sortInput, items) || _sortMode != order || _sortCache == null)
        {
            _sortInput = items;
            _sortMode = order;
            if (ContainerLegacyParity.IsMetadataSort(order))
            {
                _sortCache = items.ToList();
                if (IsHandleCreated && !IsDisposed) QueueMetadataSort(items, order, _sortCache);
                return _sortCache;
            }
            CancelMetadataSort();
            string Name(ContainerItem item) => string.IsNullOrEmpty(item.DisplayName) ? Path.GetFileName(item.Path) : item.DisplayName;
            var ordered = order.StartsWith("type", StringComparison.Ordinal)
                ? items.OrderByDescending(item => item.IsFolder).ThenBy(item => Path.GetExtension(item.Path), StringComparer.OrdinalIgnoreCase)
                    .ThenBy(Name, StringComparer.CurrentCultureIgnoreCase)
                : items.OrderBy(Name, StringComparer.CurrentCultureIgnoreCase);
            _sortCache = (order.EndsWith("-desc", StringComparison.Ordinal) ? ordered.Reverse() : ordered).ToList();
        }
        return _sortCache;
    }

    // A display-only filter: it never removes items from the underlying container or portal.
    // The cached snapshot avoids filesystem I/O on the render/animation hot path.
    private const string FilterKey = "opsisContainerViewFilter";
    private string ItemFilter => Model.Extra?.TryGetValue(FilterKey, out var value) == true &&
        value.ValueKind == System.Text.Json.JsonValueKind.String ? value.GetString() ?? "all" : "all";
    private List<ContainerItem>? _filteredInput, _filteredItems;
    private int _filterCount;
    private string? _cachedFilter, _cachedNameQuery;
    private string _nameQuery = ""; // Transient, just as in the original engine.

    private void FindInContainer()
    {
        var query = Ask(MainWindow.StudioText("Find in container (file name)", "Αναζήτηση στο container (όνομα αρχείου)"), _nameQuery);
        if (query != null) SetNameQuery(query);
    }

    private void SetNameQuery(string query)
    {
        if (string.Equals(query, _nameQuery, StringComparison.Ordinal)) return;
        _nameQuery = query;
        _filteredInput = _filteredItems = null;
        _scroll = 0;
        _hover = -1;
        ClearSelection();
        if (AutoHeightOf(Model)) LayoutHeight();
        Dirty();
        PreviewContentChanged?.Invoke();
    }

    private void ChooseFilter(string mode)
    {
        (Model.Extra ??= new())[FilterKey] = System.Text.Json.JsonSerializer.SerializeToElement(mode);
        _filteredInput = _filteredItems = null;
        _filterCount = 0;
        _scroll = 0;
        ClearSelection();
        if (AutoHeightOf(Model)) LayoutHeight();
        Dirty(); Changed?.Invoke(Model);
    }

    private List<ContainerItem> FilterItems(List<ContainerItem> source)
    {
        var mode = ItemFilter;
        if (mode == "all" && _nameQuery.Length == 0) return source;
        if (ReferenceEquals(source, _filteredInput) && _filterCount == source.Count &&
            mode == _cachedFilter && _nameQuery == _cachedNameQuery && _filteredItems != null) return _filteredItems;
        _filteredInput = source;
        _filterCount = source.Count;
        _cachedFilter = mode;
        _cachedNameQuery = _nameQuery;
        var cutoff = DateTime.UtcNow.AddDays(-7);
        _filteredItems = source.Where(item => ContainerLegacyParity.MatchesName(item, _nameQuery) && (mode switch
        {
            "folders" => item.IsFolder,
            "images" => !item.IsFolder && new[] { ".png", ".jpg", ".jpeg", ".webp", ".gif", ".bmp" }
                .Contains(Path.GetExtension(item.Path), StringComparer.OrdinalIgnoreCase),
            "documents" => !item.IsFolder && new[] { ".pdf", ".doc", ".docx", ".txt", ".odt", ".rtf", ".xls", ".xlsx" }
                .Contains(Path.GetExtension(item.Path), StringComparer.OrdinalIgnoreCase),
            "tag" => (item.DisplayName ?? Path.GetFileName(item.Path)).Contains('#'),
            "recent" => SafeRecentlyModified(item.Path, cutoff),
            _ => true
        })).ToList();
        return _filteredItems;
    }

    private static bool SafeRecentlyModified(string path, DateTime cutoff)
    {
        try { return (File.Exists(path) ? File.GetLastWriteTimeUtc(path) :
            Directory.Exists(path) ? Directory.GetLastWriteTimeUtc(path) : DateTime.MinValue) >= cutoff; }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException) { return false; }
    }

    private void SelectAllItems()
    {
        _selection.Clear();
        _selection.UnionWith(Items.Select(item => item.Path));
        if (Items.Count > 0 && _selected < 0) _selected = 0;
        Dirty();
    }

    private void DropEffectFor(DragEventArgs e)
    {
        if (e.Data?.GetDataPresent(DataFormats.FileDrop) != true) { e.Effect = DragDropEffects.None; return; }
        if (CanWritePortal)
        {
            bool moving = (e.KeyState & 4) != 0 && (e.AllowedEffect & DragDropEffects.Move) != 0;
            e.Effect = moving ? DragDropEffects.Move :
                (e.AllowedEffect & DragDropEffects.Copy) != 0 ? DragDropEffects.Copy : DragDropEffects.None;
        }
        else if (CanEditItems)
        {
            e.Effect = (e.AllowedEffect & DragDropEffects.Link) != 0 ? DragDropEffects.Link :
                (e.AllowedEffect & DragDropEffects.Copy) != 0 ? DragDropEffects.Copy : DragDropEffects.None;
        }
        else e.Effect = DragDropEffects.None;
    }
}
