using System.Text.Json;
using Opsis.Containers;

namespace MotionDesk.Containers;

internal readonly record struct ContainerItemLayout(Size Client, ContainerMetrics Grid, bool Rows, int[]? Gaps = null)
{
    internal const string ViewKey = "opsisItemView";
    internal static string ViewOf(Container model) =>
        model.Extra?.TryGetValue(ViewKey, out var view) == true && view.ValueKind == JsonValueKind.String
            ? view.GetString() ?? "grid" : "grid";

    internal static int LeftInset(ContainerMetrics metrics) => Math.Max(1, metrics.Margin / 2);

    internal Rectangle Viewport => ContainerLayout.Viewport(Client, Grid);
    private int GridLeftShift => ContainerLayout.CellRect(0, Client, Grid, 0).Left - LeftInset(Grid);
    internal int Columns => Rows ? 1 : ContainerLayout.Columns(Client.Width, Grid);
    internal int RowHeight => Rows ? Math.Max(Grid.IconSize, Grid.LabelHeight / 2) + Grid.Spacing : Grid.CellHeight;
    private int SlotCount(int count) => count + (Gaps?.Length ?? 0);
    internal int ContentHeight(int count) => Rows ? SlotCount(count) * RowHeight + 2 * Grid.Margin : ContainerLayout.ContentHeight(Client.Width, SlotCount(count), Grid);
    internal int MaxScroll(int count) => Rows ? Math.Max(0, ContentHeight(count) - Viewport.Height) : ContainerLayout.MaxScroll(Client, SlotCount(count), Grid);
    internal int ClampScroll(int offset, int count) => Rows ? Math.Clamp(offset, 0, MaxScroll(count)) : ContainerLayout.ClampScroll(offset, Client, SlotCount(count), Grid);

    internal Rectangle CellRect(int index, int scroll)
    {
        return SlotRect(ContainerSpacers.SlotFor(index, Gaps), scroll);
    }

    private Rectangle SlotRect(int index, int scroll)
    {
        if (!Rows)
        {
            var cell = ContainerLayout.CellRect(index, Client, Grid, scroll);
            cell.X -= GridLeftShift;
            return cell;
        }
        int left = LeftInset(Grid);
        return new Rectangle(left, Viewport.Top + Grid.Margin + index * RowHeight - scroll,
            Math.Max(1, Client.Width - left - Grid.Margin), RowHeight);
    }

    internal (int First, int Last) VisibleRange(int count, int scroll)
    {
        int slots = SlotCount(count);
        if (slots == 0 || Viewport.Height == 0) return (0, -1);
        (int first, int last) = !Rows ? ContainerLayout.VisibleRange(Client, slots, Grid, scroll) :
            (Math.Max(0, (scroll - Grid.Margin) / RowHeight), Math.Min(slots - 1, (scroll + Viewport.Height - Grid.Margin - 1) / RowHeight));
        while (first <= last && ContainerSpacers.ItemAt(first, Gaps) < 0) first++;
        while (last >= first && ContainerSpacers.ItemAt(last, Gaps) < 0) last--;
        if (first > last) return (0, -1);
        return (ContainerSpacers.ItemAt(first, Gaps), Math.Min(count - 1, ContainerSpacers.ItemAt(last, Gaps)));
    }

    private int HitSlot(Point point, int count, int scroll)
    {
        if (!Viewport.Contains(point)) return -1;
        int slots = SlotCount(count);
        if (!Rows)
        {
            point.X += GridLeftShift;
            return ContainerLayout.HitTest(point, Client, slots, Grid, scroll);
        }
        int rowY = point.Y - SlotRect(0, scroll).Top;
        int index = rowY / RowHeight;
        return rowY >= 0 && index < slots && SlotRect(index, scroll).Contains(point) ? index : -1;
    }

    internal int HitTest(Point point, int count, int scroll)
    {
        int item = ContainerSpacers.ItemAt(HitSlot(point, count, scroll), Gaps);
        return item >= 0 && item < count ? item : -1;
    }

    internal int Navigate(int selected, NavKey key, int count, int pageRows)
    {
        if (Gaps is not { Length: > 0 } || key is NavKey.Left or NavKey.Right or NavKey.Home or NavKey.End)
            return ContainerNavigation.Move(selected, key, Columns, count, pageRows);
        if (count == 0) return -1;
        int slot = selected < 0 ? -1 : ContainerSpacers.SlotFor(selected, Gaps);
        for (int i = 0; i <= Gaps.Length; i++)
        {
            int next = ContainerNavigation.Move(slot, key, Columns, SlotCount(count), pageRows);
            int item = ContainerSpacers.ItemAt(next, Gaps);
            if (item >= 0 && item < count) return item;
            if (next == slot) break;
            slot = next;
        }
        return selected >= 0 ? selected : 0;
    }

    internal int HitGap(Point point, int count, int scroll)
    {
        int slot = HitSlot(point, count, scroll);
        if (slot < 0 || Gaps == null) return -1;
        for (int i = 0; i < Gaps.Length; i++) if (Gaps[i] + i == slot) return i;
        return -1;
    }

    internal int DropIndex(Point point, int count, int scroll)
    {
        int slot;
        if (!Rows)
        {
            point.X += GridLeftShift;
            slot = ContainerLayout.DropIndex(point, Client, SlotCount(count), Grid, scroll);
        }
        else slot = Math.Clamp((point.Y - SlotRect(0, scroll).Top + RowHeight / 2) / RowHeight, 0, SlotCount(count));
        return Math.Clamp(ContainerSpacers.ItemsBefore(slot, Gaps), 0, count);
    }

    internal int ScrollIntoView(int index, int count, int scroll)
    {
        if (!Rows) return ContainerLayout.ScrollIntoView(ContainerSpacers.SlotFor(index, Gaps), Client, SlotCount(count), Grid, scroll);
        var row = CellRect(index, scroll);
        if (row.Top < Viewport.Top) scroll += row.Top - Viewport.Top;
        else if (row.Bottom > Viewport.Bottom) scroll += row.Bottom - Viewport.Bottom;
        return ClampScroll(scroll, count);
    }
}
