using System.Text.Json;
using Opsis.Containers;

namespace MotionDesk.Containers;

/// <summary>Presentation-only compatibility with the original DeskContainers. Unknown metadata stays unknown.</summary>
internal static class ContainerLegacyParity
{
    internal const string ShowLabelsKey = "opsisShowItemLabels";
    internal const string HistoryKey = "opsisItemHistory";
    internal sealed record History(DateTime? AddedUtc, int OpenCount);
    internal sealed record SortEntry(ContainerItem Item, long? Key, int Index);

    internal static bool ShowLabels(Container model) =>
        model.Extra?.TryGetValue(ShowLabelsKey, out var value) != true || value.ValueKind != JsonValueKind.False;

    internal static Dictionary<string, History> ReadHistory(Container model)
    {
        var result = new Dictionary<string, History>(StringComparer.OrdinalIgnoreCase);
        if (model.Extra?.TryGetValue(HistoryKey, out var value) != true || value.ValueKind != JsonValueKind.Object) return result;
        foreach (var entry in value.EnumerateObject())
        {
            if (entry.Value.ValueKind != JsonValueKind.Object) continue;
            try
            {
                var history = entry.Value.Deserialize<History>();
                if (history != null) result[entry.Name] = history with { OpenCount = Math.Max(0, history.OpenCount) };
            }
            catch (JsonException) { /* A corrupt entry must not hide the remaining valid history. */ }
        }
        return result;
    }

    internal static void RecordAdded(Container model, IEnumerable<string> paths)
    {
        var history = ReadHistory(model);
        bool changed = false;
        foreach (string path in paths)
            if (!history.ContainsKey(path)) { history[path] = new History(DateTime.UtcNow, 0); changed = true; }
        if (changed) SaveHistory(model, history);
    }

    internal static void RecordOpen(Container model, string path)
    {
        var history = ReadHistory(model);
        if (!history.TryGetValue(path, out var entry)) entry = new History(null, 0);
        history[path] = entry with { OpenCount = entry.OpenCount == int.MaxValue ? int.MaxValue : entry.OpenCount + 1 };
        SaveHistory(model, history);
    }

    internal static IEnumerable<string> ReferencePaths(Container model) =>
        model.Items.Concat(model.Tabs.SelectMany(tab => tab.Items)).Select(item => item.Path);

    // Called after moving references in the same store transaction. Retain history in the
    // source only if another reference still uses it. On a duplicate path, take the earliest
    // known date and the larger count (not sum: repeated tab moves must not inflate counts).
    internal static void TransferHistory(Container source, Container destination, IEnumerable<string> paths)
    {
        var from = ReadHistory(source);
        var to = ReadHistory(destination);
        var retained = ReferencePaths(source).ToHashSet(StringComparer.OrdinalIgnoreCase);
        bool sourceChanged = false, destinationChanged = false;
        foreach (string path in paths.Distinct(StringComparer.OrdinalIgnoreCase))
        {
            if (!from.TryGetValue(path, out var entry)) continue;
            if (to.TryGetValue(path, out var existing))
            {
                DateTime? earliest = entry.AddedUtc;
                if (existing.AddedUtc is DateTime date && (earliest == null || date < earliest.Value)) earliest = date;
                entry = new History(earliest, Math.Max(entry.OpenCount, existing.OpenCount));
            }
            if (!to.TryGetValue(path, out var previous) || previous != entry)
            {
                to[path] = entry;
                destinationChanged = true;
            }
            if (!retained.Contains(path)) sourceChanged |= from.Remove(path);
        }
        if (sourceChanged) SaveHistory(source, from);
        if (destinationChanged) SaveHistory(destination, to);
    }

    internal static void ClearHistory(Container model) => model.Extra?.Remove(HistoryKey);

    private static void SaveHistory(Container model, Dictionary<string, History> history) =>
        (model.Extra ??= new())[HistoryKey] = JsonSerializer.SerializeToElement(history);

    // Original v2.1.0 FindInContainer searched the file name, not the entire path.
    // Also match the current displayed label (e.g. renamed shortcut); no disk access.
    internal static bool MatchesName(ContainerItem item, string query) =>
        string.IsNullOrEmpty(query) ||
        (item.DisplayName ?? "").Contains(query, StringComparison.OrdinalIgnoreCase) ||
        Path.GetFileName(item.Path.TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar))
            .Contains(query, StringComparison.OrdinalIgnoreCase);

    internal static bool IsMetadataSort(string order) => order is
        "size" or "size-desc" or "modified" or "modified-desc" or "created" or "created-desc" or
        "added" or "added-desc" or "opened" or "opened-desc";

    // Run off the window's UI thread. Never recursively enumerate folder sizes, resolve network paths,
    // follow reparse points, or invent creation/added dates for unavailable references.
    internal static List<ContainerItem> Sort(ContainerItem[] items, string order,
        IReadOnlyDictionary<string, History> history, CancellationToken cancel)
    {
        string key = order.Replace("-desc", "", StringComparison.Ordinal);
        var entries = new List<SortEntry>(items.Length);
        for (int i = 0; i < items.Length; i++)
        {
            cancel.ThrowIfCancellationRequested();
            var item = items[i];
            long? metric = null;
            if (key == "opened") metric = history.TryGetValue(item.Path, out var opened) ? opened.OpenCount : 0;
            else if (key == "added") metric = history.TryGetValue(item.Path, out var added) ? added.AddedUtc?.Ticks : null;
            else if (DesktopFiles.IsLocalPath(item.Path))
            {
                try
                {
                    var drive = new DriveInfo(Path.GetPathRoot(item.Path)!);
                    if (drive.DriveType != DriveType.Fixed) { entries.Add(new(item, null, i)); continue; }
                    FileSystemInfo info = item.IsFolder ? new DirectoryInfo(item.Path) : new FileInfo(item.Path);
                    if (info.Exists && (info.Attributes & FileAttributes.ReparsePoint) == 0)
                        metric = key switch
                        {
                            "size" when info is FileInfo file => file.Length,
                            "modified" => info.LastWriteTimeUtc.Ticks,
                            "created" => info.CreationTimeUtc.Ticks,
                            _ => null
                        };
                }
                catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or ArgumentException or NotSupportedException or System.Security.SecurityException) { }
            }
            entries.Add(new(item, metric, i));
        }
        // Unknowns remain last in BOTH directions; tie-breaking is stable (preserves manual order).
        var knownFirst = entries.OrderBy(entry => !entry.Key.HasValue);
        var ordered = order.EndsWith("-desc", StringComparison.Ordinal)
            ? knownFirst.ThenByDescending(entry => entry.Key).ThenBy(entry => entry.Index)
            : knownFirst.ThenBy(entry => entry.Key).ThenBy(entry => entry.Index);
        return ordered.Select(entry => entry.Item).ToList();
    }
}
