namespace MotionDesk.Widgets;

// Monotonic per-window budget. No polling and no global renderer budget consumption.
internal sealed class RecoveryBudget
{
    private readonly Queue<long> _attempts = new();
    internal int? NextDelay(long now)
    {
        while (_attempts.Count > 0 && now - _attempts.Peek() >= 120_000) _attempts.Dequeue();
        if (_attempts.Count >= 4) return null;
        int delay = 1000 << _attempts.Count;
        _attempts.Enqueue(now);
        return delay;
    }
}
