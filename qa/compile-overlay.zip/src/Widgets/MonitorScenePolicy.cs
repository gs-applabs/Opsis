namespace MotionDesk.Widgets;

public sealed record MonitorSceneChoice(string Mode, string Scene);

// Pure policy; topology and supported scene catalog are supplied by the existing host.
internal static class MonitorScenePolicy
{
    internal readonly record struct Display(string Id, string DeviceName);
    internal static string? Key(IEnumerable<Display> displays, string? device)
    {
        if (string.IsNullOrWhiteSpace(device)) return null;
        var all = displays.ToArray();
        var matches = all.Where(d => string.Equals(d.DeviceName, device, StringComparison.OrdinalIgnoreCase)).ToArray();
        if (matches.Length != 1) return null;
        var id = matches[0].Id;
        if (string.IsNullOrWhiteSpace(id) || string.Equals(id, device, StringComparison.OrdinalIgnoreCase)) return null;
        if (all.Count(d => string.Equals(d.Id, id, StringComparison.OrdinalIgnoreCase)) != 1) return null;
        if (id.Length > 512 || id.Any(char.IsControl)) return null;
        return "id:" + id.ToUpperInvariant();
    }
    internal static MonitorSceneChoice Resolve(string baseMode, string globalScene, string? key, IReadOnlyDictionary<string, MonitorSceneChoice>? map, Func<string,bool> isStudio, Func<string?,string> normalize)
    {
        var fallback = new MonitorSceneChoice(baseMode, normalize(globalScene));
        // Global selection/automation/overlay-only remain authoritative. No independent media playlist.
        if (baseMode != "Weather" || key == null || map == null || !map.TryGetValue(key, out var value) || value == null) return fallback;
        return value.Mode == "Weather" ? new MonitorSceneChoice("Weather", normalize(value.Scene)) :
            value.Mode is "Waves" or "Particles" || (value.Mode != null && isStudio(value.Mode)) ? new MonitorSceneChoice(value.Mode, "Classic") : fallback;
    }
}
