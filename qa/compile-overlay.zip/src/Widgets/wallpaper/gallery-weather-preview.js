(() => {
    'use strict';
    const $ = id => document.getElementById(id);
    const scenes = ['Classic','Mediterranean Ocean','Mountain Lake','Rolling Hills','Desert Horizon','Living Forest','Spectrum Weather'];
    const greekScenes = ['Κλασικό Weather','Μεσογειακή Θάλασσα','Ορεινή Λίμνη','Πράσινοι Λόφοι','Ορίζοντας Ερήμου','Ζωντανό Δάσος','Spectrum Weather'];
    const times = ['Dawn','Day','Dusk','Night'], greekTimes = ['Αυγή','Ημέρα','Σούρουπο','Νύχτα'];
    const conditions = ['Clear','PartlyCloudy','Cloudy','Drizzle','Rain','HeavyRain','Thunderstorm','Snow','Fog'];
    const greekConditions = ['Αίθριος','Μερική συννεφιά','Συννεφιά','Ψιχάλα','Βροχή','Έντονη βροχή','Καταιγίδα','Χιόνι','Ομίχλη'];
    const ctx = $('preview').getContext('2d');
    const reduced = matchMedia('(prefers-reduced-motion: reduce)');
    let raf = 0, last = 0, initialized = false, disposed = false;
    function fill(id, values, names, current) {
        const select = $(id); select.replaceChildren();
        values.forEach((value,i) => {const option = document.createElement('option'); option.value = value; option.textContent = names[i]; select.append(option);});
        select.value = values.includes(current) ? current : values[0];
    }
    function stop(){if(raf) cancelAnimationFrame(raf);raf=0;last=0;}
    function canAnimate(){return initialized&&!disposed&&!document.hidden&&$('motion').checked&&!reduced.matches;}
    function frame(t){raf=0;if(!canAnimate())return;if(!last||t-last>=1000/15-1){const dt=last?Math.min(.1,(t-last)/1000):1/15;last=t;window.WeatherWallpaper.draw(ctx,dt,{id:'Low Power'});}raf=requestAnimationFrame(frame);}
    function run(){stop();if(canAnimate())raf=requestAnimationFrame(frame);}
    function drawSelection(){
        if(!initialized||disposed)return;stop();
        const engine=window.WeatherWallpaper;
        // Fixed illustrative Athens coordinates. No location/provider query or user data.
        engine.setConfig({proceduralScene:$('scene').value,weatherSim:$('weather').value,timeSim:$('time').value,windSim:'Auto',realistic:true,landmarks:false,landmarkId:'Off',spatialMode:'Off',glass:false,reducedMotion:!canAnimate(),lat:37.9838,lon:23.7275});
        // Bounded settling for visual weather transition; final frame is still by default.
        for(let i=0;i<24;i++)engine.draw(ctx,.1,{id:'Low Power'});
        engine.draw(ctx,0,{id:'Low Power'});run();
    }
    window.opsisPreviewInit=(scene,greek=false)=>{
        if(disposed)return;
        fill('scene',scenes,greek?greekScenes:scenes,scene);fill('time',times,greek?greekTimes:times,'Day');fill('weather',conditions,greek?greekConditions:conditions,'Clear');
        $('sceneLabel').textContent=greek?'Σκηνικό':'Scene';$('timeLabel').textContent=greek?'Ώρα':'Time';$('weatherLabel').textContent=greek?'Καιρός':'Weather';$('motionLabel').textContent=greek?'Κίνηση (έως 15 FPS)':'Animate (15 FPS max)';$('note').textContent=greek?'Τοπική προσομοίωση, χωρίς αλλαγή των ρυθμίσεων του φόντου.':'Offline simulation. No wallpaper settings are changed.';
        $('motion').checked=false;$('motion').disabled=reduced.matches;
        if(!initialized){window.WeatherWallpaper.resize(960,540);initialized=true;}
        drawSelection();
    };
    for(const id of ['scene','time','weather','motion'])$(id).addEventListener('change',drawSelection);
    document.addEventListener('visibilitychange',()=>{if(document.hidden)stop();else run();});
    reduced.addEventListener('change',()=>{$('motion').disabled=reduced.matches;if(reduced.matches)$('motion').checked=false;drawSelection();});
    window.addEventListener('pagehide',()=>{disposed=true;stop();window.WeatherWallpaper?.release();},{once:true});
})();
