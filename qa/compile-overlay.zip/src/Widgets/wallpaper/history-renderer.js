/* Living History: approved pre-masked local assets only; no own timer/network/API. */
(function(root){
'use strict';
const roles=['night','blue','golden','day'];
const clamp=x=>Math.max(0,Math.min(1,x));
function phase(t,sr,ss){
    if (![t,sr,ss].every(Number.isFinite)||ss<=sr||ss-sr>=1440) return ['night','night',0];
    const day=ss-sr, night=1440-day;
    const edgeDay=Math.min(90,day*.45), edgeNight=Math.min(90,night*.45);
    const gold=Math.min(12,edgeDay*.25), blue=Math.min(40,edgeNight*.5);
    t=((t-sr)%1440+1440)%1440;
    if(t>1440-edgeNight)t-=1440;
    // Scale transitions on short days/nights; wrap around midnight.
    const k=[[-edgeNight,0],[-blue,1],[gold,2],[edgeDay,3],[day-edgeDay,3],[day-gold,2],[day+blue,1],[day+edgeNight,0]];
    for(let i=1;i<k.length;i++) if(t>=k[i-1][0]&&t<k[i][0]){
        const a=k[i-1],b=k[i],u=clamp((t-a[0])/(b[0]-a[0]));return [roles[a[1]],roles[b[1]],u*u*(3-2*u)];
    }
    return ['night','night',0];
}
// Keep one formatter and one minute result; DST and half-hour offsets are handled by Intl.
let clockZone='',clockFormatter=null,clockMinute=null,clockValue=null;
function clockOffset(city,now=Date.now()){
    const zone=city?.sceneTimeZone;
    if(!valid(city)||typeof zone!=='string'||zone.length>80||!Number.isFinite(now))return null;
    if(zone!==clockZone){clockZone=zone;clockFormatter=null;clockMinute=null;clockValue=null;try{clockFormatter=new Intl.DateTimeFormat('en-US',{timeZone:zone,timeZoneName:'shortOffset'});}catch(_){}}
    if(!clockFormatter)return null;
    const minute=Math.floor(now/60000);if(clockMinute===minute)return clockValue;
    clockMinute=minute;clockValue=null;
    try{const name=clockFormatter.formatToParts(new Date(now)).find(p=>p.type==='timeZoneName')?.value;
        if(name==='GMT'||name==='UTC')clockValue=0;
        else{const m=/^GMT([+-])(\d{1,2})(?::(\d{2}))?$/.exec(name||'');if(m)clockValue=(m[1]==='-'?-1:1)*(Number(m[2])*60+Number(m[3]||0));}}
    catch(_){}return clockValue;
}
let id='',slots=new Map(),surface=null,key='',last=false;
const maxAttempts=3, retryBaseMs=2000;
function disposeSlot(s){s.image.onload=s.image.onerror=null;s.image.removeAttribute('src');}
function release(){id='';for(const s of slots.values()) disposeSlot(s); slots.clear();if(surface){surface.width=surface.height=1;surface=null;}key='';last=false;}
function valid(city){return city?.historical===true && /^history-[a-z0-9-]{1,60}$/.test(city.id)&&city.file===`scenes/living-history/${city.id}/day.webp`;}
function select(city,t,sr,ss){
    const next=valid(city)?city.id:'';
    if(next!==id){release();id=next;}
    if(!id)return false;
    let [a,b,u]=phase(t,sr,ss);
    // Quantized blends at the endpoints need only one image (e.g. throughout noon).
    let mix=a===b?0:Math.round(u*64)/64;
    if(mix===0)b=a;else if(mix===1){a=b;mix=0;}
    const wanted=new Set([a,b]),now=Date.now();
    for(const [role,s] of slots) if(!wanted.has(role)){disposeSlot(s);slots.delete(role);}
    for(const role of wanted){
        const previous=slots.get(role);
        if(previous&&(previous.ready||previous.loading&&now<previous.deadline||previous.attempts>=maxAttempts||now<previous.retryAt))continue;
        if(previous)disposeSlot(previous);
        const image=new Image(),attempts=(previous?.attempts||0)+1;
        const s={image,ready:false,loading:true,attempts,retryAt:0,deadline:now+15000};slots.set(role,s);
        const fail=()=>{if(slots.get(role)!==s)return;s.ready=false;s.loading=false;s.retryAt=Date.now()+retryBaseMs*2**(attempts-1);};
        image.onload=()=>{if(slots.get(role)!==s)return;if(image.naturalWidth!==1920||image.naturalHeight!==1080){fail();return;}s.ready=true;s.loading=false;};
        image.onerror=fail;
        image.src=`scenes/living-history/${id}/${role}.webp`;
    }
    let x=slots.get(a),y=slots.get(b);
    if(!x.ready||!y.ready){
        // Keep the last complete blend of THIS scene while the next stage loads. On a
        // cold start use any available approved stage, never a different scene's pixels.
        if(last)return true;
        if(!x.ready&&!y.ready)return false;
        if(x.ready){y=x;b=a;}else{x=y;a=b;}mix=0;
    }
    const nextKey=`${a}/${b}/${mix}`;
    if(key!==nextKey){
        if(!surface){surface=document.createElement('canvas');surface.width=1920;surface.height=1080;}
        const g=surface.getContext('2d');g.clearRect(0,0,1920,1080);
        g.globalCompositeOperation='source-over';g.globalAlpha=1-mix;g.drawImage(x.image,0,0);
        if(mix){g.globalCompositeOperation='lighter';g.globalAlpha=mix;g.drawImage(y.image,0,0);}
        g.globalCompositeOperation='source-over';g.globalAlpha=1;key=nextKey;last=true;
    }
    return last;
}
function draw(g,w,h,focus){
    if(!last||!surface)return false;
    const scale=Math.max(w/1920,h/1080),ww=1920*scale,hh=1080*scale;
    g.drawImage(surface,(w-ww)*clamp(Number.isFinite(focus)?focus:.5),(h-hh)*.5,ww,hh);return true;
}
root.OpsisLivingHistory={phase,valid,clockOffset,select,draw,release,stats:()=>({slots:slots.size,ready:last})};
if(typeof module!=='undefined')module.exports=root.OpsisLivingHistory;
})(typeof window==='undefined'?globalThis:window);
