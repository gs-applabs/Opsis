/* OPSIS P2.5: foreground renderer on the existing WeatherWallpaper canvas.
   No additional timers, network, shaders, video or weather provider. */
(function(root){'use strict';
 const names=['Classic','Mediterranean Ocean','Mountain Lake','Rolling Hills','Desert Horizon','Living Forest','Spectrum Weather'];
 const clamp=(v,a=0,b=1)=>Math.max(a,Math.min(b,v));
 const normalize=s=>names.includes(s)?s:'Classic';
 const mix=(a,b,t)=>a.map((v,i)=>Math.round(v+(b[i]-v)*clamp(t)));
 const rgb=(c,a=1)=>`rgba(${c.join(',')},${clamp(a)})`;
 const noise=(i,j)=>{let n=Math.sin(i*127.1+j*311.7)*43758.5453;return n-Math.floor(n);};
 let cache=null, groundSurface=null, groundKey='', groundBuilds=0, groundHits=0;
 let mountainSurface=null, mountainKey='', mountainBuilds=0, mountainHits=0;
 // Only one bounded foreground bitmap per renderer. No timer or shared GPU context.
 function dropGround(){if(groundSurface){groundSurface.width=groundSurface.height=1;groundSurface=null;}groundKey='';}
 function dropMountain(){if(mountainSurface){mountainSurface.width=mountainSurface.height=1;mountainSurface=null;}mountainKey='';}
 function layerStats(){return {groundBuilds,groundHits,groundPixels:groundSurface?groundSurface.width*groundSurface.height:0,mountainBuilds,mountainHits,mountainPixels:mountainSurface?mountainSurface.width*mountainSurface.height:0};}
 function quantize(v,steps){return Math.round(clamp(Number.isFinite(v)?v:0)*steps)/steps;}
 function bakedEnvironment(e){return {...e,ambient:quantize(e.ambient,64),cloud:quantize(e.cloud,32),fog:quantize(e.fog,32),snowCover:quantize(e.snowCover,32),horizon:e.horizon.map(v=>Math.max(0,Math.min(255,Math.round(v/4)*4)))};}
 function cachedGround(g,scene,w,h,hz,e,paint){
   if(!(w>0&&h>hz))return;
   const q=bakedEnvironment(e), span=h-hz;
   const maxPixels=e.low?230400:518400, scale=Math.min(1,Math.sqrt(maxPixels/(w*span)),1920/w,1080/span);
   const cw=Math.max(1,Math.floor(w*scale)),ch=Math.max(1,Math.floor(span*scale));
   // Spectrum motion is still live; expensive gradient layers are evaluated at a bounded cadence.
   const rate=e.low?6:15;
   q.time=e.reduced?0:Math.floor((Number.isFinite(e.time)?e.time:0)*rate)/rate;
   const k=[scene,w,h,hz,cw,ch,q.ambient,q.cloud,q.fog,q.snowCover,...q.horizon,e.low?1:0,scene==='Spectrum Weather'?q.time:0].join('|');
   if(k!==groundKey||!groundSurface){
     if(!groundSurface)groundSurface=document.createElement('canvas');
     if(groundSurface.width!==cw||groundSurface.height!==ch){groundSurface.width=cw;groundSurface.height=ch;}
     const c=groundSurface.getContext('2d',{alpha:false});
     if(!c){dropGround();paint(g,q);return;}
     c.setTransform(cw/w,0,0,ch/span,0,-hz*ch/span);c.globalAlpha=1;c.globalCompositeOperation='source-over';
     paint(c,q);groundKey=k;groundBuilds++;
   }else groundHits++;
   g.drawImage(groundSurface,0,hz,w,span);
 }

 // A deterministic, bounded 1D fractal field. Terrain never changes with time or weather.
 function terrainNoise(x,seed){
   let v=0, amplitude=.5;
   for(let octave=0;octave<5;octave++){
     const n=x*(4<<octave), i=Math.floor(n), f=n-i, u=f*f*(3-2*f);
     v+=amplitude*(noise(i,seed+octave*19)*(1-u)+noise(i+1,seed+octave*19)*u);
     amplitude*=.5;
   }
   return v;
 }
 function contourPath(pts,lower){const p=new Path2D();p.moveTo(pts[0][0],lower);for(const q of pts)p.lineTo(q[0],q[1]);p.lineTo(pts.at(-1)[0],lower);p.closePath();return p;}
 // Cache rock/snow detail in world geometry, not frame-sized bitmaps.
 function ridgeDetails(pts,h,hz,seed){
   const rock=new Path2D(), snow=new Path2D(), facets=new Path2D();
   for(let i=2;i<pts.length-2;i+=2){
     const [x,y]=pts[i], extent=hz-y;
     if(extent<h*.08)continue;
     const dx=(noise(i,seed)-.5)*h*.045;
     rock.moveTo(x,y);rock.lineTo(x+dx,y+extent*.45);rock.lineTo(x+dx*1.35,y+extent*.78);
     facets.moveTo(x,y);facets.lineTo(x+dx,y+extent*.45);facets.lineTo(x+dx*1.35,y+extent*.78);facets.lineTo(x+dx*.5,y+extent*.55);facets.closePath();
   }
   snow.moveTo(pts[0][0],pts[0][1]);for(const q of pts)snow.lineTo(q[0],q[1]);
   for(let i=pts.length-1;i>=0;i--){const [x,y]=pts[i];snow.lineTo(x,y+Math.max(0,hz-y)*(.13+.22*noise(i,seed+11)));}snow.closePath();
   return {rock,snow,facets};
 }

 // A bounded reusable tree silhouette, with uneven conifer branches instead of a single triangle.
 let canopy=null;
 function treePath(){
   if(canopy)return canopy;
   const path=new Path2D();path.moveTo(0,-1);
   for(let j=1;j<=6;j++){
     const y=-1+j*.145, span=.055+j*.040;
     path.lineTo(span*.55,y-.075);path.lineTo(span,y+.025);path.lineTo(span*.31,y-.005);
   }
   path.lineTo(.055,0);path.lineTo(-.055,0);
   for(let j=6;j>=1;j--){const y=-1+j*.145,span=.055+j*.040;path.lineTo(-span*.31,y-.005);path.lineTo(-span,y+.025);path.lineTo(-span*.55,y-.075);}
   path.closePath();return canopy=path;
 }
 function cloudShadow(g,w,h,hz,e){
   const strength=clamp(e.cloud)*clamp(e.ambient)*(1-clamp(e.fog))*.28;
   if(strength<.015)return;
   const t=e.reduced?0:e.time, drift=(Math.sin(t*.035)*.12+.5)*w;
   const gr=g.createLinearGradient(drift-w*.55,hz,drift+w*.55,h);
   gr.addColorStop(0,'rgba(9,17,30,0)');gr.addColorStop(.38,rgb([9,17,30],strength));gr.addColorStop(.66,rgb([9,17,30],strength*.65));gr.addColorStop(1,'rgba(9,17,30,0)');
   g.fillStyle=gr;g.fillRect(0,hz,w,h-hz);
 }
 function dustVeil(g,w,h,hz,e){
   // Wind-driven visual sand haze, only for this fictional desert scene; not a measured dust concentration.
   const strength=clamp((e.wind-25)/45)*clamp(e.ambient)*(1-clamp(e.fog))*.20;
   if(strength<.01)return;
   const shift=e.reduced?0:Math.sin(e.time*.12)*h*.035;
   const gr=g.createLinearGradient(0,hz+shift,0,hz+(h-hz)*.72);
   gr.addColorStop(0,'rgba(220,176,119,0)');gr.addColorStop(.35,rgb([220,176,119],strength));gr.addColorStop(1,'rgba(220,176,119,0)');
   g.fillStyle=gr;g.fillRect(0,hz,w,h-hz);
 }
 function profile(scene,w,h,hz){
   const key=scene+'|'+w+'|'+h+'|'+hz;if(cache?.key===key)return cache;
   if(groundKey&&!groundKey.startsWith(scene+'|'+w+'|'+h+'|'+hz+'|'))dropGround();
   const layers=[];
   const count=scene==='Mountain Lake'?3:scene==='Desert Horizon'?3:scene==='Living Forest'?4:3;
   for(let j=0;j<count;j++){
     const pts=Array.from({length:129},(_,i)=>{
       const x=i/128;let v;
       if(scene==='Mountain Lake')v=.04+.23*terrainNoise(x,j*27+13)+.10*Math.abs(Math.sin(x*6.7+j*1.1));
       else {
         // Foreground cache begins at the horizon. Keep successive crest lines
         // INSIDE it: older above-horizon paths were all clipped to the same rectangle.
         const span=h-hz, depth=.09+j*.76/Math.max(1,count-1);
         const wave=scene==='Desert Horizon'
           ? .095*Math.sin(x*5.9+j*1.45)+.027*Math.sin(x*12+j*.8)
           : .075*Math.sin(x*6.8+j*1.8)+.025*Math.sin(x*13+j);
         return [x*w,hz+span*clamp(depth+wave,0,.98)];
       }
       return [x*w,hz-v*h*(1-j*.16)+j*h*.016];
     });
     const path=contourPath(pts,h), crest=new Path2D();
     crest.moveTo(pts[0][0],pts[0][1]);for(const pt of pts.slice(1))crest.lineTo(pt[0],pt[1]);
     layers.push({pts,path,crest,...(scene==='Mountain Lake'?ridgeDetails(pts,h,hz,j*31):{})});
   }
   const trees=Array.from({length:100},(_,i)=>({x:noise(i,5)*w,y:hz+(h-hz)*noise(i,6)*.9,size:(.035+.13*noise(i,7))*h,phase:noise(i,8)*6.28})).sort((a,b)=>a.y-b.y);
   return cache={key,layers,trees};
 }
 function ridgeY(scene,w,h,hz,x){if(scene!=='Mountain Lake')return hz;const pos=clamp(x/w)*128,i=Math.floor(pos),f=pos-i;return Math.min(...profile(scene,w,h,hz).layers.map(l=>l.pts[i][1]*(1-f)+l.pts[Math.min(128,i+1)][1]*f));}
 function sky(g,scene,w,h,hz,env){
   if(scene!=='Mountain Lake'){dropMountain();return;}
   if(!(w>0&&h>0&&hz>0&&hz<=h))return;
   // Only the static mountains are cached; sun, moon, clouds and water are drawn by the existing engine.
   const q=bakedEnvironment(env), limit=env.low?230400:921600;
   const scale=Math.min(1,Math.sqrt(limit/(w*h)),1920/w,1080/h);
   const cw=Math.max(1,Math.floor(w*scale)),ch=Math.max(1,Math.floor(h*scale));
   const key=[w,h,hz,cw,ch,q.ambient,q.fog,q.snowCover,...q.horizon,env.low?1:0].join('|');
   if(mountainKey!==key||!mountainSurface){
     if(!mountainSurface)mountainSurface=document.createElement('canvas');
     if(mountainSurface.width!==cw||mountainSurface.height!==ch){mountainSurface.width=cw;mountainSurface.height=ch;}
     const c=mountainSurface.getContext('2d',{alpha:true});
     if(!c){dropMountain();paintMountain(g,w,h,hz,q);return;}
     c.setTransform(1,0,0,1,0,0);c.clearRect(0,0,cw,ch);c.setTransform(cw/w,0,0,ch/h,0,0);
     paintMountain(c,w,h,hz,q);mountainKey=key;mountainBuilds++;
   }else mountainHits++;
   g.drawImage(mountainSurface,0,0,w,h);
 }
 function paintMountain(g,w,h,hz,env){
   const amb=clamp(env.ambient), haze=env.horizon;
   for(const [i,l] of profile('Mountain Lake',w,h,hz).layers.entries()){
     const c=mix([12,23,39],[65+i*10,93+i*8,107+i*6],amb);
     g.fillStyle=rgb(mix(c,haze,.25+clamp(env.fog)*.4));g.fill(l.path);
     if(!env.low){g.save();g.clip(l.path);g.lineWidth=Math.max(.6,w/2100);g.strokeStyle=rgb(mix(c,[7,16,28],.5),.23*(1-clamp(env.fog)));g.stroke(l.rock);
       g.fillStyle=rgb(mix(c,[175,188,198],.38),.14*amb*(1-clamp(env.fog)));g.fill(l.facets);
       const snow=clamp(env.snowCover);if(snow>.015){g.fillStyle=rgb(mix([60,78,101],[230,237,242],amb),snow*(1-clamp(env.fog)*.5)*.8);g.fill(l.snow);}g.restore();}

   }
 }
 function rippleSamples(count){const bands=Array.from({length:8},()=>[]);for(let i=0;i<count;i++){const z=.06+.94*noise(i,102);bands[Math.min(7,Math.floor(z*8))].push({z,x:noise(i,103),dir:i%2?1:-1});}return bands;}
 const lakeRipples=rippleSamples(42),oceanRipples=rippleSamples(68);
 // Adds perspective micro-ripples to the existing water engine, not another reflection renderer.
 function waterDetail(g,scene,w,h,hz,e){
   if(scene!=='Mediterranean Ocean'&&scene!=='Mountain Lake')return;
   if(e.low||w<2||h<=hz)return;
   const lake=scene==='Mountain Lake', t=e.reduced?0:e.time, wind=clamp(e.wind/75), a=clamp(e.ambient), fog=clamp(e.fog);
   const samples=lake?lakeRipples:oceanRipples;
   const color=mix([155,181,212],[221,234,228],a);
   g.save();try{g.beginPath();g.rect(0,hz,w,h-hz);g.clip();g.lineWidth=Math.max(.55,w/2400);
     for(let band=0;band<8;band++){
       const zMid=(band+.5)/8, alpha=(.045+.08*a)*(.35+wind*.65)*(1-fog)*(.4+.6*zMid);
       g.strokeStyle=rgb(color,alpha);g.beginPath();
       for(const q of samples[band]){
         const z=q.z,y=hz+(h-hz)*z*z,span=(.008+z*z*.044)*(lake?1:1.55)*w;
         const position=q.x+t*(.004+wind*.01)*q.dir,x=(position-Math.floor(position))*w;
         g.moveTo(x-span,y);g.quadraticCurveTo(x,y-(lake?.3:1.2)*z,x+span,y+.4*z);
       }
       g.stroke();
     }
   }finally{g.restore();}
 }
 function forestLight(g,w,h,hz,e){
   const power=clamp(e.ambient)*Math.max(0,1-clamp(e.cloud)*1.25)*(.04+.15*clamp(e.fog))*(1-clamp(e.snowCover)*.2);
   if(e.low||power<.02)return;
   // Soft shafts from the bright sky through the canopy. No new timer or image buffer.
   g.save();try{g.beginPath();g.rect(0,hz,w,h-hz);g.clip();
     for(let j=0;j<4;j++){const x=w*(.12+j*.19), end=x-w*.24;
       const gr=g.createLinearGradient(x,hz,end,h);gr.addColorStop(0,rgb([239,224,175],power));gr.addColorStop(1,rgb([239,224,175],0));g.fillStyle=gr;
       g.beginPath();g.moveTo(x-w*.012,hz);g.lineTo(x+w*.012,hz);g.lineTo(end+w*.095,h);g.lineTo(end-w*.03,h);g.closePath();g.fill();}
   }finally{g.restore();}
 }
 function gradient(g,y,h,top,bottom){const gr=g.createLinearGradient(0,y,0,h);gr.addColorStop(0,rgb(top));gr.addColorStop(1,rgb(bottom));return gr;}
 function ground(g,scene,w,h,hz,e){
   if(scene!=='Mountain Lake')dropMountain();
   if(scene==='Classic'||scene==='Mediterranean Ocean'||scene==='Mountain Lake'){dropGround();return false;}
   const a=clamp(e.ambient), t=e.reduced?0:e.time, wind=clamp(e.wind/60), haze=e.horizon;
   const p=profile(scene,w,h,hz);
   g.save();
   try{
     if(scene==='Spectrum Weather'){
       cachedGround(g,scene,w,h,hz,e,(c,q)=>{
         const a=q.ambient,t=q.time,haze=q.horizon;
         const colors=[mix([17,14,39],[56,102,160],a),mix([42,19,65],[148,73,170],a),mix([8,31,43],[45,169,157],a)].map(col=>mix(col,haze,clamp(q.cloud*.45+q.fog*.25)));
         c.fillStyle=gradient(c,hz,h,colors[0],colors[2]);c.fillRect(0,hz,w,h-hz);
         const count=q.low?4:7;
         for(let j=0;j<count;j++){
           const x=w*(j/(count-1)),y=hz+(h-hz)*(.42+.15*Math.sin(j+t*.12)),r=w*.30;
           const gr=c.createRadialGradient(x,y,0,x,y,r);gr.addColorStop(0,rgb(colors[j%3],.65));gr.addColorStop(1,rgb(colors[j%3],0));c.fillStyle=gr;c.fillRect(0,hz,w,h-hz);
           c.strokeStyle=rgb(mix(colors[j%3],haze,.5),.40);c.lineWidth=Math.max(1,w/1100);c.beginPath();c.moveTo(-w*.1,hz+(h-hz)*j/count);c.bezierCurveTo(w*.25,y-h*.09,w*.62,y+h*.09,w*1.1,hz+(h-hz)*(count-j)/count);c.stroke();
           if(!q.low){c.strokeStyle=rgb([215,234,246],.12*a*(1-q.fog));c.lineWidth=Math.max(.6,w/2100);c.beginPath();c.moveTo(-w*.1,hz+(h-hz)*j/count+2);c.bezierCurveTo(w*.25,y-h*.09+2,w*.62,y+h*.09+2,w*1.1,hz+(h-hz)*(count-j)/count+2);c.stroke();}
         }
       });
       return true;
     }
     const sand=scene==='Desert Horizon', forest=scene==='Living Forest';
     const day=sand?[191,136,82]:forest?[46,83,60]:[105,137,68];
     const night=sand?[30,25,36]:[12,25,31];
     cachedGround(g,scene,w,h,hz,e,(c,q)=>{
       const base=mix(night,day,q.ambient*(1-.35*q.cloud));
       c.fillStyle=gradient(c,hz,h,mix(base,q.horizon,.25),mix(base,[9,15,20],.45));c.fillRect(0,hz,w,h-hz);
       for(const [i,l] of p.layers.entries()){
         const depth=i/Math.max(1,p.layers.length-1);
         let color=mix(base,q.horizon,(1-depth)*(.36+q.fog*.33)+q.fog*.16);
         color=mix(color,sand?[87,53,40]:[9,19,25],depth*.23);
         if(!sand)color=mix(color,[205,216,225],q.snowCover*.7);
         const top=l.pts.reduce((a,p)=>Math.min(a,p[1]),h);
         c.fillStyle=gradient(c,top,h,color,mix(color,sand?[105,65,41]:[8,16,19],.27));c.fill(l.path);
         // A subtle lit crest belongs to the baked geometry, never to the animated wind.
         if(!q.low&&q.ambient>.08){c.save();c.clip(l.path);c.strokeStyle=rgb(mix(color,sand?[252,218,162]:[202,219,159],.4),.15*q.ambient*(1-q.fog));c.lineWidth=Math.max(.7,w/1600);c.stroke(l.crest);c.restore();}
       }
       // Subtle desert striations are part of the stable terrain, not animated geometry.
       if(sand){const count=q.low?9:19;for(let i=0;i<count;i++){const y=hz+(h-hz)*(i/(count-1))**1.5;c.strokeStyle=rgb(mix(base,[245,209,153],.35),.12*q.ambient);c.beginPath();c.moveTo(0,y);c.bezierCurveTo(w*.25,y-h*.028,w*.70,y+h*.025,w,y-h*.007);c.stroke();}}
     });
     if(!sand){
       const n=e.low?24:forest?100:52;
       for(let i=0;i<n;i++){const q=p.trees[Math.min(p.trees.length-1,Math.floor((i+.5)*p.trees.length/n))],s=q.size*(forest?1:.42);const sway=e.reduced?0:Math.sin(t*.9+q.phase)*wind*s*.08;
         const depth=clamp((q.y-hz)/(h-hz)), foliage=mix(mix([8,19,23],forest?[32,75,48]:[62,100,47],a),haze,(1-depth)*(.14+clamp(e.fog)*.4));
         g.fillStyle=rgb(foliage);g.save();g.translate(q.x,q.y);g.transform(s,0,-sway,s,0,0);
         g.fill(treePath());
         if(!e.low && forest){g.fillStyle=rgb(mix(foliage,[110,128,80],.20*a),.45);g.save();g.scale(.48,.88);g.translate(-.13,-.04);g.fill(treePath());g.restore();}
         g.restore();
         if(forest&&!e.low){g.fillStyle=rgb(mix([13,19,24],[80,67,46],a));g.fillRect(q.x-s*.02,q.y-s*.14,s*.04,s*.18);}
       }
     }
     cloudShadow(g,w,h,hz,e);
     if(forest)forestLight(g,w,h,hz,e);
     if(sand)dustVeil(g,w,h,hz,e);
     return true;
   }finally{g.restore();}
 }
 root.OpsisProceduralWeather={normalize,sky,ground,ridgeY,waterDetail,layerStats,release(){cache=null;canopy=null;dropGround();dropMountain();groundBuilds=groundHits=mountainBuilds=mountainHits=0;}};
})(typeof window==='undefined'?globalThis:window);
