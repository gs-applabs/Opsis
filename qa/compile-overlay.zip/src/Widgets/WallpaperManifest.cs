using System.Text.Json;
using System.Text.Json.Serialization;

namespace MotionDesk.Widgets
{
    /// <summary>One user-adjustable property of a web wallpaper (declared in <c>opsis-wallpaper.json</c> next to its index.html).</summary>
    public sealed class WallpaperProperty
    {
        public string Key { get; set; } = "";
        public string Type { get; set; } = "text";          // slider | checkbox | color | combo | text
        public string Label { get; set; } = "";
        public string LabelEl { get; set; } = "";
        public double Min { get; set; } = 0;
        public double Max { get; set; } = 100;
        public double Step { get; set; } = 1;
        public JsonElement Default { get; set; }
        public List<string> Options { get; set; } = new();

        public string DefaultText => Default.ValueKind switch
        {
            JsonValueKind.String => Default.GetString() ?? "",
            JsonValueKind.Number => Default.GetRawText(),
            JsonValueKind.True => "true",
            JsonValueKind.False => "false",
            _ => Type == "checkbox" ? "false" : Type == "slider" ? Min.ToString(System.Globalization.CultureInfo.InvariantCulture) : "",
        };
    }

    /// <summary>
    /// Description of a web wallpaper: name, author and the properties the user can change in Opsis (sliders, check boxes, colours, lists, text).
    /// The page receives the values (and system/audio data) through window messages, see docs/WALLPAPER_API.md.
    /// </summary>
    public sealed class WallpaperManifest
    {
        public const string FileName = "opsis-wallpaper.json";
        public string Name { get; set; } = "";
        public string Author { get; set; } = "";
        public string WallpaperId { get; set; } = "";
        public string Category { get; set; } = "";
        public string Collection { get; set; } = "";
        public string NameEl { get; set; } = "";
        public string DescriptionEl { get; set; } = "";
        public string Description { get; set; } = "";
        public List<WallpaperProperty> Properties { get; set; } = new();

        private static readonly JsonSerializerOptions Options = new() { PropertyNameCaseInsensitive = true, ReadCommentHandling = JsonCommentHandling.Skip, AllowTrailingCommas = true };

        /// <summary>The manifest of the wallpaper page at <paramref name="indexHtml"/>, or null when there is none / it is not valid.</summary>
        public static WallpaperManifest? LoadFor(string? indexHtml)
        {
            try
            {
                if (string.IsNullOrEmpty(indexHtml)) return null;
                string path = Path.Combine(Path.GetDirectoryName(indexHtml) ?? "", FileName);
                if (!File.Exists(path) || new FileInfo(path).Length > 256 * 1024) return null;
                if ((File.GetAttributes(path) & FileAttributes.ReparsePoint) != 0) return null;
                using var input = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read);
                if (input.Length > 256 * 1024) return null;
                var m = JsonSerializer.Deserialize<WallpaperManifest>(input, Options);
                if (m == null) return null;
                m.Name = BoundedText(m.Name, 120);
                m.Author = BoundedText(m.Author, 120);
                m.Description = BoundedText(m.Description, 2000);
                m.Properties = ValidProperties(m.Properties);
                return m;
            }
            catch (Exception) { return null; }
        }

        // Validate package-provided metadata before it reaches WinForms controls or JS.
        private static string BoundedText(string? value, int limit) =>
            new string((value ?? "").Where(c => !char.IsControl(c)).Take(limit).ToArray());

        private static bool ValidKey(string? key) => !string.IsNullOrWhiteSpace(key) && key.Length <= 64 &&
            key.All(c => !char.IsControl(c) && c != '|') &&
            key.Trim() == key && key is not ("__proto__" or "prototype" or "constructor");

        private static bool ValidSlider(WallpaperProperty p)
        {
            if (!double.IsFinite(p.Min) || !double.IsFinite(p.Max) || !double.IsFinite(p.Step) ||
                p.Min >= p.Max || p.Step <= 0) return false;
            double lo = p.Min / p.Step, hi = p.Max / p.Step;
            // FlatSlider takes int ticks; avoid overflow, degenerate ranges and huge tick counts.
            return double.IsFinite(lo) && double.IsFinite(hi) && Math.Abs(lo) <= 1_000_000 &&
                Math.Abs(hi) <= 1_000_000 && Math.Round(lo) < Math.Round(hi) &&
                Math.Round(hi) - Math.Round(lo) <= 100_000;
        }

        private static bool TryNormalize(WallpaperProperty p, string? value, out string normalized)
        {
            normalized = "";
            if (value == null || value.Length > 4096) return false;
            switch (p.Type)
            {
                case "slider":
                    if (!ValidSlider(p) || !double.TryParse(value, System.Globalization.NumberStyles.Float,
                        System.Globalization.CultureInfo.InvariantCulture, out double n) || !double.IsFinite(n)) return false;
                    normalized = Math.Clamp(n, p.Min, p.Max).ToString("R", System.Globalization.CultureInfo.InvariantCulture);
                    return true;
                case "checkbox":
                    if (!bool.TryParse(value, out bool yes)) return false;
                    normalized = yes ? "true" : "false"; return true;
                case "combo":
                    if (p.Options == null || !p.Options.Contains(value, StringComparer.Ordinal)) return false;
                    normalized = value; return true;
                case "color":
                    // Documented package colors are HTML hex. Named HTML colors are retained for older packages.
                    if (!(value.Length is 4 or 7 && value[0] == '#' && value.Skip(1).All(Uri.IsHexDigit)) &&
                        !(value.Length is >= 1 and <= 32 && value.All(c => c is >= 'a' and <= 'z' or >= 'A' and <= 'Z'))) return false;
                    normalized = value; return true;
                case "text": normalized = value; return true;
                default: return false;
            }
        }

        internal static string NormalizeValue(WallpaperProperty p, string? value)
        {
            if (TryNormalize(p, value, out var result) || TryNormalize(p, p.DefaultText, out result)) return result;
            return p.Type switch
            {
                "slider" => p.Min.ToString("R", System.Globalization.CultureInfo.InvariantCulture),
                "checkbox" => "false", "color" => "#FFFFFF", "combo" => p.Options?.FirstOrDefault() ?? "", _ => ""
            };
        }

        private static List<WallpaperProperty> ValidProperties(List<WallpaperProperty>? raw)
        {
            var result = new List<WallpaperProperty>();
            var keys = new HashSet<string>(StringComparer.Ordinal);
            foreach (var p in raw ?? new List<WallpaperProperty>())
            {
                if (p == null || !ValidKey(p.Key) || p.Type is not ("slider" or "checkbox" or "color" or "combo" or "text")) continue;
                if (p.Type == "slider" && !ValidSlider(p)) continue;
                p.Label = BoundedText(p.Label, 160); p.LabelEl = BoundedText(p.LabelEl, 160);
                p.Options = (p.Options ?? new List<string>()).Where(v => v != null && v.Length is > 0 and <= 256 && !v.Any(char.IsControl))
                    .Distinct(StringComparer.Ordinal).Take(100).ToList();
                if (p.Type == "combo" && p.Options.Count == 0) continue;
                if (!keys.Add(p.Key)) continue;
                result.Add(p);
                if (result.Count == 40) break;
            }
            return result;
        }

        private static string StoreKey(string source, string key) => source + "|" + key;

        public static string GetValue(WallpaperSettings s, string source, WallpaperProperty p) =>
            NormalizeValue(p, s.PageProperties != null && s.PageProperties.TryGetValue(StoreKey(source, p.Key), out var v) ? v : null);

        public static void SetValue(WallpaperSettings s, string source, string key, string value)
        {
            if (!ValidKey(key)) return;
            s.PageProperties ??= new Dictionary<string, string>();
            s.PageProperties[StoreKey(source, key)] = value;
        }

        /// <summary>{ "key": value, ... } with numbers and booleans typed, as the page expects.</summary>
        public static string ValuesJson(WallpaperSettings s, string source, WallpaperManifest m)
        {
            var d = new Dictionary<string, object>();
            foreach (var p in m.Properties)
            {
                string v = GetValue(s, source, p);
                d[p.Key] = p.Type switch
                {
                    "slider" => double.TryParse(v, System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out var n) && double.IsFinite(n) ? Math.Clamp(n, p.Min, p.Max) : p.Min,
                    "checkbox" => v.Equals("true", StringComparison.OrdinalIgnoreCase),
                    _ => v,
                };
            }
            return JsonSerializer.Serialize(d);
        }
    }
}
