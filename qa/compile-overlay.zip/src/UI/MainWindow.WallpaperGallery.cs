using System.Drawing.Drawing2D;
using MotionDesk.Services;
using MotionDesk.Widgets;

namespace MotionDesk.UI;

public sealed partial class MainWindow
{
    private FlowLayoutPanel WeatherDepthPicker(string selected)
    {
        var spatialRow = new FlowLayoutPanel { AutoSize = true, WrapContents = false, Margin = new Padding(0, 5, 0, 8) };
        spatialRow.Controls.Add(new Label { Text = StudioText("Weather scene depth", "Βάθος καιρού / σκηνής"),
            Width = 190, Height = 30, TextAlign = ContentAlignment.MiddleLeft,
            ForeColor = UiTheme.TextSecondary, Font = UiTheme.FontBody });
        var spatialModes = new[] { "Off", "2.5D", "3D" };
        var spatialLabels = new[] {
            StudioText("Off — classic 2D", "Κλειστό — κλασικό 2D"),
            StudioText("2.5D — parallax", "2.5D — παράλλαξη βάθους"),
            StudioText("3D — landscapes and monuments", "3D — τοπία και μνημεία")
        };
        var spatialPicker = new FlatComboBox { Width = 330 };
        var currentSpatial = Array.IndexOf(spatialModes, selected);
        spatialPicker.SetItems(spatialLabels, spatialLabels[Math.Max(0, currentSpatial)]);
        spatialPicker.SelectedIndexChanged += (_, _) =>
        {
            if (spatialPicker.SelectedIndex is >= 0 and < 3)
                WallpaperHostEngine.Instance.SetWeatherSpatialMode(spatialModes[spatialPicker.SelectedIndex]);
        };
        spatialRow.Controls.Add(spatialPicker);
        return spatialRow;
    }

    // P1.1: one in-memory projection of the existing catalogs; never mutate the playlist.
    private string _galleryQuery = "", _galleryCategory = "all", _gallerySort = "catalog", _galleryType = "all";
    private bool _galleryList, _galleryFavoritesOnly;
    private int _galleryPage;
    private string _galleryResolution = "all", _galleryFps = "all", _galleryCodec = "all";
    private int _galleryTileWidth = 244;
    private int _galleryScroll;
    private bool _galleryRestored;
    private void RestoreGalleryPreferences()
    {
        if (_galleryRestored) return;
        _galleryRestored = true;
        var pref = AppSettings.Load();
        _galleryFavorites.UnionWith((pref.WallpaperGalleryFavorites ?? new()).Where(x => !string.IsNullOrEmpty(x) && x.Length <= 240).Take(2048));
        _galleryRecent.AddRange((pref.WallpaperGalleryRecent ?? new()).Where(x => !string.IsNullOrEmpty(x) && x.Length <= 240).Distinct(StringComparer.OrdinalIgnoreCase).Take(64));
        var view = pref.WallpaperGalleryView ?? new();
        string Read(string key, string fallback, params string[] allowed) => view.TryGetValue(key, out var value) && value != null && allowed.Contains(value) ? value : fallback;
        _galleryCategory = Read("category", "all", "all", "nature", "abstract", "technology", "space", "weather", "history", "spectrum", "europe", "greece", "islands", "custom", "addons");
        _gallerySort = Read("sort", "catalog", "catalog", "asc", "desc", "recent", "size", "date", "category");
        _galleryType = Read("type", "all", "all", "video", "image", "web", "weather", "procedural");
        _galleryResolution = Read("resolution", "all", "all", "1080", "2160", "unknown");
        _galleryFps = Read("fps", "all", "all", "30", "60", "unknown");
        _galleryCodec = Read("codec", "all", "all", "h264", "vp9", "av1", "hevc", "other", "unknown");
        _galleryList = Read("list", "false", "true", "false") == "true";
        _galleryFavoritesOnly = Read("favorites", "false", "true", "false") == "true";
        if (view.TryGetValue("query", out var q) && q != null && q.Length <= 200) _galleryQuery = q;
        if (view.TryGetValue("width", out var width) && int.TryParse(width, out var w)) _galleryTileWidth = Math.Clamp(w, 180, 380);
        if (view.TryGetValue("page", out var index) && int.TryParse(index, out var n)) _galleryPage = Math.Clamp(n, 0, 1000);
        if (view.TryGetValue("scroll", out var scroll) && int.TryParse(scroll, out var y)) _galleryScroll = Math.Clamp(y, 0, 1000000);
    }
    private void SaveGalleryPreferences()
    {
        var pref = AppSettings.Load();
        var favorites = _galleryFavorites.OrderBy(x => x, StringComparer.OrdinalIgnoreCase).Take(2048).ToList();
        var recent = _galleryRecent.Take(64).ToList();
        var view = new Dictionary<string, string> { ["category"] = _galleryCategory, ["sort"] = _gallerySort, ["type"] = _galleryType,
            ["resolution"] = _galleryResolution, ["fps"] = _galleryFps, ["codec"] = _galleryCodec, ["list"] = _galleryList ? "true" : "false", ["favorites"] = _galleryFavoritesOnly ? "true" : "false",
            ["query"] = _galleryQuery, ["width"] = _galleryTileWidth.ToString(), ["page"] = _galleryPage.ToString(), ["scroll"] = _galleryScroll.ToString() };
        var old = pref.WallpaperGalleryView ?? new();
        if (favorites.SequenceEqual(pref.WallpaperGalleryFavorites ?? new()) && recent.SequenceEqual(pref.WallpaperGalleryRecent ?? new()) && view.Count == old.Count && view.All(p => old.TryGetValue(p.Key, out var value) && value == p.Value)) return;
        pref.WallpaperGalleryView = view;
        pref.WallpaperGalleryFavorites = favorites;
        pref.WallpaperGalleryRecent = recent;
        try { pref.Save(); }
        catch (Exception ex) { if (!IsDisposed) MessageBox.Show(this, ex.Message, "Opsis", MessageBoxButtons.OK, MessageBoxIcon.Warning); }
    }
    private readonly HashSet<string> _galleryFavorites = new(StringComparer.OrdinalIgnoreCase);
    private readonly List<string> _galleryRecent = new();
    private sealed record GalleryRow(string Id, string Mode, string Title, string Detail, string Category,
        string? Asset, bool Animate, OpsisEcosystemGallery.Item? Contribution = null, string? LocalVideo = null, InstalledWallpaperPackages.Entry? LocalPackage = null, WallpaperGalleryCatalog.Entry? BundledPage = null, string? StaticImage = null, string? LandmarkId = null, string? ExternalPoster = null);

    private static string GalleryCategoryFor(string mode) => mode switch
    {
        "Studio Prism" or "Studio Ink" or "Studio Opal" or "Studio Obsidian" or "Studio Silk" or "Waves" or "Particles" => "abstract",
        "Studio Neon" => "technology",
        "Studio Nebula" or "Studio Eclipse" or "Studio Lunar" or "Studio Saturn" or "Studio Meteor" or "Studio Corona" => "space",
        "Weather" => "weather",
        WallpaperSettings.AthensMode => "history",
        "Video" or "Image" or "Page" or "Desktop" => "custom",
        _ => "nature"
    };

    private static string GalleryContributionCategory(string category) => category.Trim().ToLowerInvariant() switch
    {
        "nature" or "φύση" => "nature", "abstract" or "αφηρημένα" => "abstract",
        "tech" or "technology" or "τεχνολογία" => "technology", "space" or "διάστημα" => "space",
        "weather" or "καιρός" => "weather", "historical cities" or "living history" or "history" or "historical" or "ιστορικά" => "history",
        "opsis spectrum" or "spectrum" or "seasonal" or "spectrum/seasonal" or "spectrum / seasonal" => "spectrum",
        "europe" or "european capitals" or "ευρώπη" => "europe", "greek landmarks" or "greece" or "ελλάδα" => "greece",
        "islands" or "greek islands" or "νησιά" => "islands", _ => "addons"
    };

    private static string GalleryTypeFor(GalleryRow row) => row.Mode switch
    {
        "Video" => "video", "Image" or "Desktop" => "image", "Page" => "web", "Weather" => "weather", _ => "procedural"
    };

    private void ShowWallpaper()
    {
        _currentPageKey = "Wallpaper";
        RestoreGalleryPreferences();
        var page = CreatePagePanel();
        var host = WallpaperHostEngine.Instance;
        var shell = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 2, Margin = Padding.Empty, Padding = Padding.Empty };
        shell.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        shell.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        shell.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        var toolbar = new FlowLayoutPanel { AutoSize = true, AutoSizeMode = AutoSizeMode.GrowAndShrink, Dock = DockStyle.Fill,
            FlowDirection = FlowDirection.TopDown, WrapContents = false, Margin = Padding.Empty, Padding = new Padding(4) };
        shell.Controls.Add(toolbar, 0, 0); shell.Controls.Add(page, 0, 1); page.Dock = DockStyle.Fill;
        AddHeading(toolbar, StudioText("Wallpaper gallery", "Συλλογή φόντων"));
        var actions = new FlowLayoutPanel { AutoSize = true, WrapContents = true, Margin = Padding.Empty };
        var power = StudioButton("", () => { if (host.IsEnabled) host.Disable(); else host.Enable(); }, 180);
        var details = StudioButton(StudioText("Wallpaper settings", "Ρυθμίσεις φόντου"), ShowWallpaperDetails, 180);
        var depth = WeatherDepthPicker(WallpaperSettings.Load().WeatherSpatialMode);
        actions.Controls.AddRange([power, details]); toolbar.Controls.Add(actions); toolbar.Controls.Add(depth);
        string[] sceneIds = ["Classic", "Mediterranean Ocean", "Mountain Lake", "Rolling Hills", "Desert Horizon", "Living Forest", "Spectrum Weather"];
        string[] sceneLabels = [StudioText("Classic Weather", "Κλασικό Weather"), StudioText("Mediterranean Ocean", "Μεσογειακή Θάλασσα"), StudioText("Mountain Lake", "Ορεινή Λίμνη"), StudioText("Rolling Hills", "Πράσινοι Λόφοι"), StudioText("Desert Horizon", "Ορίζοντας Ερήμου"), StudioText("Living Forest", "Ζωντανό Δάσος"), "Spectrum Weather"];
        var scenePicker = new FlatComboBox { Width = 240, AccessibleName = StudioText("Weather scene", "Σκηνικό καιρού") };
        scenePicker.SetItems(sceneLabels, sceneLabels[Math.Max(0, Array.IndexOf(sceneIds, WallpaperSettings.NormalizeWeatherProceduralScene(WallpaperSettings.Load().WeatherProceduralScene)))]);
        actions.Controls.Add(scenePicker);
        var previewWeather = StudioButton(StudioText("Weather preview", "Προεπισκόπηση καιρού"), () =>
        {
            using var preview = new GalleryWeatherPreviewForm(WallpaperSettings.NormalizeWeatherProceduralScene(WallpaperSettings.Load().WeatherProceduralScene), StudioGreek);
            preview.ShowDialog(this);
        }, 180);
        actions.Controls.Add(previewWeather);
        scenePicker.SelectedIndexChanged += (_, _) =>
        {
            if (scenePicker.SelectedIndex < 0 || scenePicker.SelectedIndex >= sceneIds.Length) return;
            var s = WallpaperSettings.Load(); s.WeatherProceduralScene = sceneIds[scenePicker.SelectedIndex]; s.Save();
            if (s.Mode != "Weather" || !host.IsEnabled) host.SetMode("Weather"); else _ = host.RefreshAllAsync();
        };
        var filters = new FlowLayoutPanel { AutoSize = true, WrapContents = true, Margin = Padding.Empty };
        var search = new TextBox { Width = 190, MaxLength = 200, Text = _galleryQuery, PlaceholderText = StudioText("Search wallpapers", "Αναζήτηση φόντων"), AccessibleName = StudioText("Search wallpapers", "Αναζήτηση φόντων") };
        string[] categories = ["all", "nature", "abstract", "technology", "space", "weather", "history", "spectrum", "europe", "greece", "islands", "custom", "addons"];
        string[] categoryLabels = [StudioText("All", "Όλα"), StudioText("Nature", "Φύση"), StudioText("Abstract", "Αφηρημένα"), StudioText("Technology", "Τεχνολογία"), StudioText("Space", "Διάστημα"), StudioText("Weather", "Καιρός"), StudioText("Living history", "Ζωντανή ιστορία"), StudioText("Spectrum / Seasonal", "Spectrum / Εποχικά"), StudioText("Europe", "Ευρώπη"), StudioText("Greece", "Ελλάδα"), StudioText("Islands", "Νησιά"), StudioText("Custom", "Προσωπικά"), StudioText("Add-ons", "Πρόσθετα")];
        string[] sorts = ["catalog", "asc", "desc", "recent", "size", "date", "category"];
        string[] sortLabels = [StudioText("Catalog order", "Σειρά καταλόγου"), StudioText("Name A–Z", "Όνομα Α–Ω"), StudioText("Name Z–A", "Όνομα Ω–Α"), StudioText("Recently used", "Πρόσφατα"), StudioText("Largest file", "Μέγεθος αρχείου"), StudioText("Newest file", "Νεότερο αρχείο"), StudioText("Category", "Κατηγορία")];
        var category = new FlatComboBox { Width = 150, AccessibleName = StudioText("Category", "Κατηγορία") };
        category.SetItems(categoryLabels, categoryLabels[Math.Max(0, Array.IndexOf(categories, _galleryCategory))]);
        var sort = new FlatComboBox { Width = 150, AccessibleName = StudioText("Sort", "Ταξινόμηση") };
        sort.SetItems(sortLabels, sortLabels[Math.Max(0, Array.IndexOf(sorts, _gallerySort))]);
        string[] types = ["all", "video", "image", "web", "weather", "procedural"];
        string[] typeLabels = [StudioText("All types", "Όλοι οι τύποι"), StudioText("Video", "Βίντεο"), StudioText("Image / GIF", "Εικόνα / GIF"), StudioText("Web", "Ιστός"), StudioText("Weather", "Καιρός"), StudioText("Procedural", "Δυναμικά γραφικά")];
        var type = new FlatComboBox { Width = 145, AccessibleName = StudioText("Type", "Τύπος") };
        type.SetItems(typeLabels, typeLabels[Math.Max(0, Array.IndexOf(types, _galleryType))]);
        var list = new CheckBox { AutoSize = true, Text = StudioText("List", "Λίστα"), Checked = _galleryList };
        var favorites = new CheckBox { AutoSize = true, Text = StudioText("Favorites", "Αγαπημένα"), Checked = _galleryFavoritesOnly };
        filters.Controls.AddRange([search, category, type, sort, list, favorites]); toolbar.Controls.Add(filters);
        var metaBar = new FlowLayoutPanel { AutoSize = true, WrapContents = true, Margin = Padding.Empty };
        string[] resolutions = ["all", "1080", "2160", "unknown"];
        string[] resolutionLabels = [StudioText("All resolutions", "Όλες οι αναλύσεις"), "1080p+", "4K+", StudioText("Unknown", "Άγνωστη")];
        var resolution = new FlatComboBox { Width = 145, AccessibleName = StudioText("Resolution", "Ανάλυση") };
        resolution.SetItems(resolutionLabels, resolutionLabels[Math.Max(0, Array.IndexOf(resolutions, _galleryResolution))]);
        string[] rates = ["all", "30", "60", "unknown"];
        string[] rateLabels = [StudioText("All frame rates", "Όλα τα FPS"), "30 FPS+", "60 FPS+", StudioText("Unknown FPS", "Άγνωστα FPS")];
        var rate = new FlatComboBox { Width = 135, AccessibleName = "FPS" };
        rate.SetItems(rateLabels, rateLabels[Math.Max(0, Array.IndexOf(rates, _galleryFps))]);
        string[] codecs = ["all", "h264", "vp9", "av1", "hevc", "other", "unknown"];
        string[] codecLabels = [StudioText("All codecs", "Όλοι οι codecs"), "H.264", "VP9", "AV1", "HEVC", StudioText("Other codec", "Άλλος codec"), StudioText("Unknown codec", "Άγνωστος codec")];
        var codecPicker = new FlatComboBox { Width = 145, AccessibleName = StudioText("Video codec", "Codec βίντεο") };
        codecPicker.SetItems(codecLabels, codecLabels[Math.Max(0, Array.IndexOf(codecs, _galleryCodec))]);
        var tileWidth = new NumericUpDown { Minimum = 180, Maximum = 380, Increment = 20, Value = _galleryTileWidth, Width = 70, AccessibleName = StudioText("Tile width", "Πλάτος πλακιδίου") };
        var scan = new Button { AutoSize = true, Text = StudioText("Read video metadata", "Ανάγνωση metadata") };
        var packages = StudioButton(StudioText("Packages", "Πακέτα"), () =>
        {
            using var dialog = new Form { Text = StudioText("Wallpaper packages", "Πακέτα φόντων"), Size = new Size(740, 410), StartPosition = FormStartPosition.CenterParent, BackColor = UiTheme.PageBackground };
            var panel = CreatePagePanel(); panel.Dock = DockStyle.Fill;
            BuildPackageRow(panel); dialog.Controls.Add(panel);
            var restoreHidden = MediaButton(StudioText("Restore hidden packages", "Επαναφορά κρυμμένων πακέτων"));
            restoreHidden.Click += (_, _) =>
            {
                try
                {
                    var pref = AppSettings.Load();
                    if (pref.WallpaperGalleryHiddenPackages?.Count > 0) { pref.WallpaperGalleryHiddenPackages.Clear(); pref.Save(); ShowWallpaper(); }
                }
                catch (Exception ex) { MessageBox.Show(this, ex.Message, "Opsis"); }
            };
            panel.Controls.Add(restoreHidden);
            EventHandler closeOnPageChange = (_, _) => { if (!dialog.IsDisposed) dialog.Close(); };
            page.Disposed += closeOnPageChange;
            try { dialog.ShowDialog(this); } finally { page.Disposed -= closeOnPageChange; }
        }, 130);
        var inspectPackage = new Button { AutoSize = true, Text = StudioText("Inspect ZIP", "Έλεγχος ZIP") };
        inspectPackage.Click += async (_, _) =>
        {
            using var dialog = new OpenFileDialog { Filter = "Wallpaper ZIP (*.zip)|*.zip" };
            if (dialog.ShowDialog(this) != DialogResult.OK) return;
            string path = dialog.FileName;
            inspectPackage.Enabled = false;
            try
            {
                var report = await Task.Run(() => WallpaperPackages.Inspect(path));
                if (page.IsDisposed) return;
                string summary = $"{report.EntryPoint}\n{report.Files.Count} files · {report.UncompressedBytes / 1048576d:F1} MiB · {report.ScriptCount} HTML/JS\n\n" + string.Join(Environment.NewLine, report.Files.Take(24));
                MessageBox.Show(this, summary + "\n\n" + StudioText("Inspection only; files were not imported or executed.", "Μόνο έλεγχος: δεν έγινε εισαγωγή ή εκτέλεση αρχείων."), "Opsis", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex) { if (!page.IsDisposed) MessageBox.Show(this, ex.Message, "Opsis", MessageBoxButtons.OK, MessageBoxIcon.Warning); }
            finally { if (!inspectPackage.IsDisposed) inspectPackage.Enabled = true; }
        };
        metaBar.Controls.AddRange([resolution, rate, codecPicker, tileWidth, scan, packages, inspectPackage]); toolbar.Controls.Add(metaBar);
        var navigation = new FlowLayoutPanel { AutoSize = true, WrapContents = true, Margin = Padding.Empty };
        var count = new Label { AutoSize = true, ForeColor = UiTheme.TextSecondary, Font = UiTheme.FontBody, Padding = new Padding(4, 8, 4, 0) };
        var previous = new Button { Text = "‹", Width = 44, Height = 30, FlatStyle = FlatStyle.Flat };
        var next = new Button { Text = "›", Width = 44, Height = 30, FlatStyle = FlatStyle.Flat };
        previous.AccessibleName = StudioText("Previous page", "Προηγούμενη σελίδα"); next.AccessibleName = StudioText("Next page", "Επόμενη σελίδα");
        navigation.Controls.AddRange([previous, next, count]); toolbar.Controls.Add(navigation);
        var library = new Panel { AutoSize = false, Margin = Padding.Empty };
        page.Controls.Add(library);
        var rows = new List<GalleryRow>();
        void Add(string mode, string title, string detail, string? asset = null, bool animate = false) =>
            rows.Add(new("builtin:" + mode, mode, title, detail, GalleryCategoryFor(mode), asset, animate));
        foreach (var scene in StudioWallpaperCatalog.Scenes) Add(scene.Mode, scene.Title(StudioGreek), scene.Detail(StudioGreek), scene.Asset, true);
        Add("Weather", StudioText("Weather", "Καιρός"), StudioText("Live weather and Greek landscapes", "Ζωντανός καιρός και ελληνικά τοπία"), "weather");
        Add(WallpaperSettings.AthensMode, WallpaperModeLabel(WallpaperSettings.AthensMode), StudioText("Seasonal light across the Acropolis", "Μεταβαλλόμενο φως πάνω στην Ακρόπολη"), "athens");
        Add("Video", StudioText("Videos", "Βίντεο"), StudioText("Loop your video library", "Αναπαραγωγή της βιβλιοθήκης σου"));
        Add("Image", StudioText("Image or GIF", "Εικόνα ή GIF"), StudioText("Choose a file", "Επιλογή αρχείου"));
        Add("Page", StudioText("Web page", "Ιστοσελίδα"), StudioText("Open a web wallpaper", "Άνοιγμα διαδικτυακού φόντου"));
        Add("Desktop", StudioText("Windows wallpaper", "Φόντο Windows"), StudioText("Show your system wallpaper", "Εμφάνιση του φόντου των Windows"));
        Add("Waves", StudioText("Waves", "Κύματα"), StudioText("Audio-reactive ribbons", "Κορδέλες που αντιδρούν στον ήχο"));
        Add("Particles", StudioText("Particles", "Σωματίδια"), StudioText("Floating particles", "Αιωρούμενα σωματίδια"));
        var settingsAtOpen = WallpaperSettings.Load();
        foreach (var path in settingsAtOpen.VideoPaths.Where(path => File.Exists(path) && GalleryVideoMetadata.IsSupported(path)).Distinct(StringComparer.OrdinalIgnoreCase).Take(1000))
        {
            var id = "video:" + Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(System.Text.Encoding.UTF8.GetBytes(Path.GetFullPath(path).ToUpperInvariant())));
            rows.Add(new(id, "Video", Path.GetFileNameWithoutExtension(path), Path.GetExtension(path), "custom", null, false, null, path));
        }
        // Preserve the R13 built-in Spectrum images and curated landscape choices in the unified catalog.
        var spectrumDirectory = Path.Combine(AppContext.BaseDirectory, "wallpapers", "samples", "opsis-glass-signature", "static");
        var spectrumNames = new[] { ("Blue", "Μπλε"), ("Violet", "Μωβ"), ("Magenta", "Φούξια"), ("Amber", "Πορτοκαλί"), ("Lime", "Λαχανί"), ("Emerald", "Σμαραγδί") };
        for (int i = 0; i < spectrumNames.Length; i++)
        {
            var name = spectrumNames[i];
            var path = Path.Combine(spectrumDirectory, $"OPSIS-Spectrum-{i + 1:00}-{name.Item1}-1920x1080.png");
            if (File.Exists(path)) rows.Add(new("spectrum:" + name.Item1, "Image", "OPSIS Spectrum — " + StudioText(name.Item1, name.Item2), "OPSIS Spectrum", "spectrum", null, false, StaticImage: path, ExternalPoster: path));
        }
        foreach (var city in LandmarkCatalog.Scenes.Where(city => city.File?.StartsWith("scenes/europe/", StringComparison.Ordinal) == true || city.Historical))
        {
            var path = Path.Combine(AppContext.BaseDirectory, "widgets", "wallpaper", city.File ?? "");
            if (File.Exists(path)) rows.Add(new("landmark:" + city.Id, "Weather", StudioText(city.NameEn, city.Name), city.Historical ? "Living History" : "Weather", city.Historical || city.Id == "ancient-rome-320" ? "history" : "europe", null, false, LandmarkId: city.Id, ExternalPoster: path));
        }
        var importImages = StudioButton(StudioText("Install image pack", "Εγκατάσταση συλλογής εικόνων"), () =>
        {
            using var picker = new OpenFileDialog { Filter = "Opsis image packs (*.zip)|*.zip", CheckFileExists = true };
            if (picker.ShowDialog(this) != DialogResult.OK) return;
            if (MessageBox.Show(this, StudioText("Install data-only wallpapers from this ZIP? No files will be executed.", "Εγκατάσταση μόνο εικόνων από αυτό το ZIP; Δεν θα εκτελεστεί κανένα αρχείο."), "Opsis", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) != DialogResult.Yes) return;
            try { int count = OpsisEcosystemGallery.ImportWallpaperPack(picker.FileName); MessageBox.Show(this, count + " wallpaper images installed.", "Opsis"); ShowWallpaper(); }
            catch (Exception ex) { MessageBox.Show(this, ex.Message, "Opsis", MessageBoxButtons.OK, MessageBoxIcon.Warning); }
        }, 195);
        actions.Controls.Add(importImages);
        var metadata = new Dictionary<string, GalleryVideoMetadata>(StringComparer.OrdinalIgnoreCase);
        var scanLifetime = new System.Threading.CancellationTokenSource();
        string? VideoPath(GalleryRow row) => row.LocalVideo ?? (row.Mode == "Video" ? row.Contribution?.AssetPath : null);
        GalleryVideoMetadata? Meta(GalleryRow row) => metadata.TryGetValue(row.Id, out var value) ? value : null;
        bool MatchMetadata(GalleryRow row)
        {
            var m = Meta(row);
            bool resolutionOk = _galleryResolution switch { "1080" => m?.Height >= 1080, "2160" => m?.Height >= 2160, "unknown" => m == null || m.Height <= 0, _ => true };
            bool fpsOk = _galleryFps switch { "30" => m?.Fps >= 29.97, "60" => m?.Fps >= 59.94, "unknown" => m == null || m.Fps <= 0, _ => true };
            // Non-video entries cannot match a video-only codec filter, even "unknown".
            string? actual = m?.Codec?.Trim().ToLowerInvariant();
            bool codecOk = _galleryCodec == "all" || (VideoPath(row) != null && (_galleryCodec switch
            {
                "unknown" => string.IsNullOrEmpty(actual),
                "other" => !string.IsNullOrEmpty(actual) && actual is not ("h264" or "vp9" or "av1" or "hevc"),
                _ => actual == _galleryCodec
            }));
            return resolutionOk && fpsOk && codecOk;
        }
        var visible = new List<(GalleryRow Row, Button Button)>();
        const int pageSize = 96; // bounded logical page; only viewport rows plus overscan have controls
        GalleryRow[] pageRows = Array.Empty<GalleryRow>();
        var realized = new Dictionary<int, Button>();
        bool viewportQueued = false, rendering = false;
        int columns = 1, tileW = 120, tileH = 145, strideY = 157, strideX = 132;
        void QueueViewport()
        {
            if (viewportQueued || page.IsDisposed || page.Disposing || !page.IsHandleCreated) return;
            viewportQueued = true;
            try { page.BeginInvoke(new Action(() => { viewportQueued = false; UpdateViewport(); })); }
            catch (InvalidOperationException) { viewportQueued = false; }
        }
        var debounce = new System.Windows.Forms.Timer { Interval = 180 };
        // Coalesce preference writes; never defer the actual wallpaper/playlist settings.
        var preferenceSave = new System.Windows.Forms.Timer { Interval = 1200 };
        preferenceSave.Tick += (_, _) => { preferenceSave.Stop(); SaveGalleryPreferences(); };
        void QueuePreferenceSave() { preferenceSave.Stop(); preferenceSave.Start(); }
        void FlushPreferenceSave() { preferenceSave.Stop(); SaveGalleryPreferences(); }
        var menu = new ContextMenuStrip();
        bool IsActive(GalleryRow row, WallpaperSettings settings)
        {
            if (!host.IsEnabled || row.Mode != settings.Mode) return false;
            if (row.LandmarkId != null) return settings.WeatherLandmarks && settings.WeatherLandmarkId == row.LandmarkId && WallpaperSettings.NormalizeWeatherProceduralScene(settings.WeatherProceduralScene) == "Classic";
            if (row.BundledPage != null) return string.Equals(row.BundledPage.IndexPath, MediaSource.LocalPagePath(settings.PageSource), StringComparison.OrdinalIgnoreCase);
            if (row.StaticImage != null) return string.Equals(row.StaticImage, settings.ImagePath, StringComparison.OrdinalIgnoreCase);
            if (row.Mode == "Video") return VideoPath(row) is string video ? string.Equals(video, settings.CurrentPlaylistFile(), StringComparison.OrdinalIgnoreCase) : !rows.Any(r => VideoPath(r) != null && string.Equals(VideoPath(r), settings.CurrentPlaylistFile(), StringComparison.OrdinalIgnoreCase));
            if (row.LocalPackage != null) return string.Equals(row.LocalPackage.Index, MediaSource.LocalPagePath(settings.PageSource), StringComparison.OrdinalIgnoreCase);
            if (row.Contribution != null) return string.Equals(row.Contribution.AssetPath, settings.ImagePath, StringComparison.OrdinalIgnoreCase);
            if (row.Mode == "Image") return !rows.Any(r => r.Mode == "Image" && (r.StaticImage != null || r.Contribution != null) && string.Equals(r.StaticImage ?? r.Contribution?.AssetPath, settings.ImagePath, StringComparison.OrdinalIgnoreCase));
            if (row.Mode == "Page") return !rows.Any(r => r.Mode == "Page" && (r.BundledPage != null || r.LocalPackage != null) && string.Equals(r.BundledPage?.IndexPath ?? r.LocalPackage?.Index, MediaSource.LocalPagePath(settings.PageSource), StringComparison.OrdinalIgnoreCase));
            if (row.Mode == "Weather") return !rows.Any(r => r.LandmarkId != null && IsActive(r, settings));
            return true;
        }
        void Sync()
        {
            if (page.IsDisposed || page.Disposing) return;
            var settings = WallpaperSettings.Load();
            power.Text = host.IsEnabled ? StudioText("Disable wallpaper", "Απενεργοποίηση φόντου") : StudioText("Enable wallpaper", "Ενεργοποίηση φόντου");
            depth.Enabled = WallpaperSettings.NormalizeWeatherProceduralScene(settings.WeatherProceduralScene) == "Classic";
            details.Text = settings.Mode == "Weather" ? StudioText("Weather settings", "Ρυθμίσεις Weather") : StudioText("Wallpaper settings", "Ρυθμίσεις φόντου");
            foreach (var (row, button) in visible)
            {
                bool active = IsActive(row, settings);
                if (button is WallpaperTile tile) tile.SetActive(active);
                else button.Text = (active ? "✓ " : "") + row.Title + (_galleryFavorites.Contains(row.Id) ? " ★" : "");
            }
        }
        bool resizing = false;
        void ResizeTiles()
        {
            if (page.IsDisposed || page.Disposing || resizing) return;
            resizing = true;
            try
            {
                int area = Math.Max(160, page.ClientSize.Width - page.Padding.Horizontal - 24);
                if (page.ClientSize.Width <= 0) return;
                columns = _galleryList ? 1 : Math.Clamp(area / _galleryTileWidth, 1, 6);
                tileW = Math.Max(120, area / columns - 12);
                tileH = _galleryList ? 42 : Math.Max(145, (tileW - 14) * 9 / 16 + 61);
                // Bound an individual logical page even at a very wide single-column window.
                tileH = Math.Min(250, tileH);
                strideX = tileW + 12; strideY = tileH + (_galleryList ? 4 : 12);
                library.Size = new Size(area, Math.Max(1, ((pageRows.Length + columns - 1) / columns) * strideY));
                foreach (var bar in new[] { actions, filters, navigation, metaBar }) bar.MaximumSize = new Size(Math.Max(160, toolbar.ClientSize.Width - 8), 0);
                depth.MaximumSize = new Size(Math.Max(160, toolbar.ClientSize.Width - 8), 0); depth.WrapContents = true;
                QueueViewport();
            }
            finally { resizing = false; }
        }
        void UpdateViewport()
        {
            if (rendering || resizing || page.IsDisposed || page.Disposing || !page.IsHandleCreated) return;
            if (page.ClientSize.Height <= 0) return;
            // Client-coordinate location incorporates AutoScrollPosition, including mouse wheel forwarding.
            int top = Math.Max(0, -library.Top);
            int bottom = Math.Max(top, page.ClientSize.Height - library.Top);
            var (first, last) = GalleryViewport.Range(pageRows.Length, columns, strideY, top, bottom);
            library.SuspendLayout();
            try
            {
                foreach (int i in realized.Keys.Where(i => i < first || i >= last).ToArray())
                {
                    var button = realized[i];
                    if (button.ContainsFocus) search.Focus();
                    if (menu.Visible && ReferenceEquals(menu.SourceControl, button)) menu.Close();
                    realized.Remove(i); visible.RemoveAll(x => ReferenceEquals(x.Button, button)); button.Dispose();
                }
                for (int i = first; i < last; i++)
                {
                    if (!realized.TryGetValue(i, out var button))
                    {
                        button = CreateGalleryButton(pageRows[i]);
                        realized.Add(i, button); visible.Add((pageRows[i], button)); library.Controls.Add(button);
                    }
                    button.Bounds = new Rectangle((i % columns) * strideX, (i / columns) * strideY, tileW, tileH);
                }
            }
            finally { library.ResumeLayout(false); }
            Sync();
        }
        void Choose(GalleryRow row)
        {
            try
            {
                if (row.BundledPage is { } bundled)
                {
                    var valid = WallpaperGalleryCatalog.Discover().FirstOrDefault(x => x.Id == bundled.Id && string.Equals(x.IndexPath, bundled.IndexPath, StringComparison.OrdinalIgnoreCase));
                    if (valid == null) throw new InvalidDataException("Wallpaper is no longer installed.");
                    var cfg = WallpaperSettings.Load(); cfg.PageSource = valid.IndexPath; cfg.Save(); host.SetMode("Page");
                }
                else if (row.StaticImage is { } image)
                {
                    if (!File.Exists(image)) throw new FileNotFoundException("Spectrum wallpaper missing", image);
                    var cfg = WallpaperSettings.Load(); cfg.ImagePath = image; cfg.Save(); host.SetMode("Image");
                }
                else if (row.LandmarkId is { } landmark)
                {
                    var city = LandmarkCatalog.Scenes.FirstOrDefault(x => x.Id == landmark);
                    if (city == null || !File.Exists(row.ExternalPoster)) throw new InvalidDataException("Landscape is no longer installed.");
                    var cfg = WallpaperSettings.Load(); cfg.WeatherProceduralScene = "Classic"; cfg.WeatherLandmarkId = city.Id; cfg.WeatherLandmarks = true; cfg.Save();
                    if (!city.Historical) host.SetWeatherLocation(city.NameEn, city.Lat, city.Lon, "Gallery", city.NameEn);
                    host.SetMode("Weather"); _ = host.RefreshAllAsync();
                }
                else if (row.LocalPackage != null)
                {
                    if (!InstalledWallpaperPackages.StillInstalled(row.LocalPackage)) throw new InvalidDataException("Wallpaper package unavailable.");
                    if (MessageBox.Show(this, StudioText("This local wallpaper can run HTML/JavaScript. Only open packages you trust. Continue?", "Αυτό το τοπικό φόντο μπορεί να εκτελέσει HTML/JavaScript. Άνοιξε μόνο αξιόπιστα πακέτα. Συνέχεια;"), "Opsis", MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2) != DialogResult.Yes) return;
                    if (!InstalledWallpaperPackages.StillInstalled(row.LocalPackage)) throw new InvalidDataException("Wallpaper package changed or unavailable.");
                    var cfg = WallpaperSettings.Load(); cfg.PageSource = row.LocalPackage.Index; cfg.Save(); host.SetMode("Page");
                }
                else if (row.Contribution != null && row.Mode == "Video")
                {
                    var current = OpsisEcosystemGallery.Discover().FirstOrDefault(x => x.PluginId == row.Contribution.PluginId && x.Id == row.Contribution.Id && x.AssetPath == row.Contribution.AssetPath && x.Type.Equals("wallpaper", StringComparison.OrdinalIgnoreCase));
                    if (current == null || !GalleryVideoMetadata.IsSupported(current.AssetPath)) throw new InvalidDataException("Wallpaper contribution no longer available.");
                    var cfg = WallpaperSettings.Load();
                    string media = cfg.VideoPaths.FirstOrDefault(p => string.Equals(p, current.AssetPath, StringComparison.OrdinalIgnoreCase)) ?? current.AssetPath;
                    if (cfg.DisabledVideoPaths.Contains(media)) throw new InvalidOperationException(StudioText("Enable this video in the playlist first.", "Ενεργοποίησε πρώτα το βίντεο στη λίστα αναπαραγωγής."));
                    host.SetVideo(media);
                }
                else if (row.Contribution != null) OpsisEcosystemGallery.ApplyStaticWallpaper(row.Contribution);
                else if (row.LocalVideo != null)
                {
                    if (!File.Exists(row.LocalVideo) || !GalleryVideoMetadata.IsSupported(row.LocalVideo)) throw new InvalidDataException("Video unavailable or unsupported.");
                    if (WallpaperSettings.Load().DisabledVideoPaths.Contains(row.LocalVideo)) throw new InvalidOperationException(StudioText("Enable this video in the playlist first.", "Ενεργοποίησε πρώτα το βίντεο στη λίστα αναπαραγωγής."));
                    host.SetVideo(row.LocalVideo);
                }
                else if (!host.IsEnabled || WallpaperSettings.Load().Mode != row.Mode) host.SetMode(row.Mode);
                _galleryRecent.Remove(row.Id); _galleryRecent.Insert(0, row.Id);
                if (_galleryRecent.Count > 64) _galleryRecent.RemoveAt(64);
                QueuePreferenceSave();
                if (_gallerySort == "recent") Render(); else Sync();
                if (row.Contribution == null && row.LocalVideo == null && row.LocalPackage == null && row.BundledPage == null && row.StaticImage == null && (row.Mode is "Video" or "Image" or "Page")) ShowWallpaperDetails();
            }
            catch (Exception ex) { MessageBox.Show(this, ex.Message, "Opsis", MessageBoxButtons.OK, MessageBoxIcon.Warning); }
        }
        void Render()
        {
            if (page.IsDisposed || page.Disposing) return;
            var compare = System.Globalization.CultureInfo.CurrentCulture.CompareInfo;
            var opts = System.Globalization.CompareOptions.IgnoreCase | System.Globalization.CompareOptions.IgnoreNonSpace;
            string query = _galleryQuery.Trim();
            IEnumerable<GalleryRow> filtered = rows.Where(r => (_galleryCategory == "all" || r.Category == _galleryCategory || (_galleryCategory == "addons" && (r.Contribution != null || r.LocalPackage != null || r.BundledPage != null))) &&
                (_galleryType == "all" || GalleryTypeFor(r) == _galleryType) && MatchMetadata(r) &&
                (!_galleryFavoritesOnly || _galleryFavorites.Contains(r.Id)) && (query.Length == 0 ||
                compare.IndexOf(r.Title + " " + r.Detail + " " + r.Mode + " " + r.Contribution?.Category, query, opts) >= 0));
            filtered = _gallerySort switch {
                "asc" => filtered.OrderBy(r => r.Title, StringComparer.CurrentCultureIgnoreCase).ThenBy(r => r.Id, StringComparer.Ordinal),
                "desc" => filtered.OrderByDescending(r => r.Title, StringComparer.CurrentCultureIgnoreCase).ThenBy(r => r.Id, StringComparer.Ordinal),
                "recent" => filtered.OrderBy(r => { int i = _galleryRecent.IndexOf(r.Id); return i < 0 ? int.MaxValue : i; }),
                "size" => filtered.OrderByDescending(r => Meta(r)?.Bytes ?? -1).ThenBy(r => r.Title, StringComparer.CurrentCultureIgnoreCase),
                "date" => filtered.OrderByDescending(r => Meta(r)?.ModifiedUtc ?? DateTime.MinValue).ThenBy(r => r.Title, StringComparer.CurrentCultureIgnoreCase),
                "category" => filtered.OrderBy(r => r.Category).ThenBy(r => r.Title, StringComparer.CurrentCultureIgnoreCase),
                _ => filtered };
            var matches = filtered.ToArray(); int pages = Math.Max(1, (matches.Length + pageSize - 1) / pageSize);
            _galleryPage = Math.Clamp(_galleryPage, 0, pages - 1);
            previous.Enabled = _galleryPage > 0; next.Enabled = _galleryPage + 1 < pages;
            count.Text = $"{matches.Length} · {_galleryPage + 1}/{pages}";
            rendering = true;
            page.SuspendLayout(); library.SuspendLayout();
            try
            {
                menu.Close(); DisposeChildren(library); visible.Clear(); realized.Clear();
                pageRows = matches.Skip(_galleryPage * pageSize).Take(pageSize).ToArray();
                ResizeTiles(); page.AutoScrollPosition = Point.Empty;
            }
            finally { rendering = false; library.ResumeLayout(); page.ResumeLayout(); }
            UpdateViewport(); QueueViewport();
        }
        Button CreateGalleryButton(GalleryRow row)
        {
        var m = Meta(row);
        string detail = row.Detail + (m == null ? "" : " · " + (m.Width > 0 && m.Height > 0 ? $"{m.Width}×{m.Height}" : "?") + " · " + (m.Fps > 0 ? $"{m.Fps:0.##} FPS" : "? FPS") + " · " + (string.IsNullOrEmpty(m.Codec) ? "?" : m.Codec));
        Button button = _galleryList ? new Button { Text = row.Title, TextAlign = ContentAlignment.MiddleLeft, FlatStyle = FlatStyle.Flat, ForeColor = UiTheme.TextPrimary, BackColor = UiTheme.Surface, Margin = new Padding(0, 0, 8, 4) }
            : new WallpaperTile(row.Mode, row.Title + (_galleryFavorites.Contains(row.Id) ? " ★" : ""), detail, row.Asset, row.Animate, row.ExternalPoster);
        if (row.BundledPage != null) button.Name = "wallpaper-tile-" + row.BundledPage.Id;
        button.AccessibleName = row.Title;
        button.AccessibleDescription = detail + (row.Mode == "Video" ? " · " + StudioText("WebView2 decoder support and GPU load require device verification", "Η υποστήριξη decoder WebView2 και το φορτίο GPU απαιτούν έλεγχο συσκευής") : ""); button.Tag = row;
        button.Click += (_, _) => Choose(row); button.ContextMenuStrip = menu;
            if (button is WallpaperTile posterTile && (VideoPath(row) ?? (row.Mode == "Image" ? row.Contribution?.AssetPath : null)) is string mediaPath) _ = posterTile.LoadGalleryPosterAsync(mediaPath);
            return button;
        }
        resolution.SelectedIndexChanged += (_, _) => { if (resolution.SelectedIndex >= 0 && resolution.SelectedIndex < resolutions.Length) { _galleryResolution = resolutions[resolution.SelectedIndex]; ChangeFilter(); } };
        codecPicker.SelectedIndexChanged += (_, _) => { if (codecPicker.SelectedIndex >= 0 && codecPicker.SelectedIndex < codecs.Length) { _galleryCodec = codecs[codecPicker.SelectedIndex]; ChangeFilter(); } };
        rate.SelectedIndexChanged += (_, _) => { if (rate.SelectedIndex >= 0 && rate.SelectedIndex < rates.Length) { _galleryFps = rates[rate.SelectedIndex]; ChangeFilter(); } };
        tileWidth.ValueChanged += (_, _) => { _galleryTileWidth = (int)tileWidth.Value; ResizeTiles(); QueuePreferenceSave(); };
        scan.Click += async (_, _) =>
        {
            scan.Enabled = false;
            var token = scanLifetime.Token;
            try
            {
                var candidates = rows.Where(r => VideoPath(r) is string p && GalleryVideoMetadata.IsSupported(p)).Take(1000).ToArray();
                for (int i = 0; i < candidates.Length; i += 2)
                {
                    var batch = candidates.Skip(i).Take(2).ToArray();
                    var values = await Task.WhenAll(batch.Select(r => GalleryVideoMetadata.ReadAsync(VideoPath(r)!, token)));
                    if (token.IsCancellationRequested || page.IsDisposed) return;
                    for (int n = 0; n < batch.Length; n++) if (values[n] is { } v) metadata[batch[n].Id] = v;
                    count.Text = $"Metadata {Math.Min(i + 2, candidates.Length)}/{candidates.Length}";
                }
                Render();
            }
            catch (OperationCanceledException) { }
            catch (Exception ex) { if (!page.IsDisposed) MessageBox.Show(this, ex.Message, "Opsis"); }
            finally { if (!scan.IsDisposed) scan.Enabled = true; }
        };
        previous.Click += (_, _) => { if (_galleryPage > 0) { _galleryPage--; Render(); QueuePreferenceSave(); } };
        next.Click += (_, _) => { _galleryPage++; Render(); QueuePreferenceSave(); };
        void ChangeFilter() { _galleryPage = 0; Render(); QueuePreferenceSave(); }
        search.TextChanged += (_, _) => { _galleryQuery = search.Text; debounce.Stop(); debounce.Start(); };
        debounce.Tick += (_, _) => { debounce.Stop(); ChangeFilter(); };
        category.SelectedIndexChanged += (_, _) => { if (category.SelectedIndex >= 0 && category.SelectedIndex < categories.Length) { _galleryCategory = categories[category.SelectedIndex]; ChangeFilter(); } };
        type.SelectedIndexChanged += (_, _) => { if (type.SelectedIndex >= 0 && type.SelectedIndex < types.Length) { _galleryType = types[type.SelectedIndex]; ChangeFilter(); } };
        sort.SelectedIndexChanged += (_, _) => { if (sort.SelectedIndex >= 0 && sort.SelectedIndex < sorts.Length) { _gallerySort = sorts[sort.SelectedIndex]; ChangeFilter(); } };
        list.CheckedChanged += (_, _) => { _galleryList = list.Checked; Render(); QueuePreferenceSave(); };
        favorites.CheckedChanged += (_, _) => { _galleryFavoritesOnly = favorites.Checked; ChangeFilter(); };
        GalleryRow? menuRow = null;
        var favoriteAction = new ToolStripMenuItem(); menu.Items.Add(favoriteAction);
        var monitorAction = new ToolStripMenuItem(StudioText("Video per monitor", "Βίντεο ανά οθόνη")); menu.Items.Add(monitorAction);
        bool packageBusy = false;
        var verifyPackage = new ToolStripMenuItem(StudioText("Verify against original ZIP…", "Έλεγχος έναντι αρχικού ZIP…"));
        var replacePackage = new ToolStripMenuItem(StudioText("Install repair / upgrade copy…", "Εγκατάσταση αντιγράφου επισκευής / αναβάθμισης…"));
        menu.Items.Add(verifyPackage); menu.Items.Add(replacePackage);
        async Task CompareOrInstallPackage(bool install)
        {
            if (packageBusy || menuRow?.LocalPackage is not InstalledWallpaperPackages.Entry entry) return;
            using var picker = new OpenFileDialog { Filter = "Wallpaper ZIP (*.zip)|*.zip" };
            if (picker.ShowDialog(this) != DialogResult.OK) return;
            string zip = picker.FileName;
            packageBusy = true;
            try
            {
                if (!await Task.Run(() => InstalledWallpaperPackages.StillInstalled(entry))) throw new InvalidDataException("Package unavailable.");
                if (page.IsDisposed) return;
                if (!install)
                {
                    var report = await Task.Run(() => WallpaperPackages.VerifyAgainstArchive(entry.Index, zip));
                    if (page.IsDisposed) return;
                    string summary = StudioText($"Matched {report.MatchedFiles}/{report.ExpectedFiles} · Missing {report.Missing} · Changed {report.Changed} · Unexpected {report.Unexpected}",
                        $"Ταυτίζονται {report.MatchedFiles}/{report.ExpectedFiles} · Λείπουν {report.Missing} · Αλλοιωμένα {report.Changed} · Πρόσθετα {report.Unexpected}");
                    MessageBox.Show(this, summary + "\n\n" + string.Join("\n", report.Details) + "\n\n" + StudioText("Comparison to the selected ZIP, not a publisher signature.", "Σύγκριση με το επιλεγμένο ZIP, όχι υπογραφή εκδότη."), "Opsis", MessageBoxButtons.OK, report.Matches ? MessageBoxIcon.Information : MessageBoxIcon.Warning);
                    return;
                }
                var preview = await Task.Run(() => WallpaperPackages.Inspect(zip));
                // Avoid spending disk space on an identical repair/upgrade copy. An unavailable
                // comparison is not proof of equality; require the explicit installation dialog below.
                WallpaperPackages.PackageVerification? identical = null;
                try { identical = await Task.Run(() => WallpaperPackages.VerifyAgainstArchive(entry.Index, zip)); }
                catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or InvalidDataException) { }
                if (page.IsDisposed) return;
                if (identical?.Matches == true)
                {
                    MessageBox.Show(this, StudioText("Identical package already installed. No new copy was created.", "Το ίδιο πακέτο είναι ήδη εγκατεστημένο. Δεν δημιουργήθηκε νέο αντίγραφο."), "Opsis");
                    return;
                }
                if (page.IsDisposed) return;
                string consent = StudioText($"Install a NEW copy ({preview.Files.Count} files, {preview.UncompressedBytes / 1048576d:F1} MiB)? Only select trusted HTML/JavaScript packages. The current package and active wallpaper remain unchanged. You can select either copy in the Gallery.",
                    $"Εγκατάσταση ΝΕΟΥ αντιγράφου ({preview.Files.Count} αρχεία, {preview.UncompressedBytes / 1048576d:F1} MiB); Επίλεξε μόνο αξιόπιστα HTML/JavaScript πακέτα. Το υπάρχον πακέτο και το ενεργό φόντο παραμένουν ανέπαφα. Μπορείς να επιλέξεις οποιοδήποτε αντίγραφο στη Gallery.");
                if (MessageBox.Show(this, consent, "Opsis", MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2) != DialogResult.Yes) return;
                // Existing transactional importer validates again. The old version is retained; no auto activation.
                string installedIndex = await Task.Run(() => WallpaperPackages.Import(zip));
                // Record ancestry using catalog IDs, not paths from ZIP metadata. An installed copy is
                // never deleted if its lineage cannot be recorded (e.g. catalog cap, settings error).
                var installedEntries = await Task.Run(InstalledWallpaperPackages.Discover);
                var added = installedEntries.FirstOrDefault(x => string.Equals(x.Index, installedIndex, StringComparison.OrdinalIgnoreCase));
                var previous = installedEntries.FirstOrDefault(x => x.Id == entry.Id && string.Equals(x.Index, entry.Index, StringComparison.OrdinalIgnoreCase));
                var pref = AppSettings.Load();
                pref.WallpaperGalleryPackagePrevious ??= new();
                bool linked = added != null && previous != null && PackageLineage.Link(pref.WallpaperGalleryPackagePrevious, added.Id, previous.Id);
                if (linked) pref.Save();
                if (!page.IsDisposed)
                {
                    if (!linked) MessageBox.Show(this, StudioText("New copy installed; rollback link unavailable. Both copies remain on disk.", "Το νέο αντίγραφο εγκαταστάθηκε, αλλά δεν αποθηκεύτηκε σύνδεσμος επαναφοράς. Και τα δύο αντίγραφα παραμένουν στον δίσκο."), "Opsis");
                    ShowWallpaper();
                }
            }
            catch (Exception ex) { if (!page.IsDisposed) MessageBox.Show(this, ex.Message, "Opsis", MessageBoxButtons.OK, MessageBoxIcon.Warning); }
            finally { packageBusy = false; }
        }
        verifyPackage.Click += async (_, _) => await CompareOrInstallPackage(false);
        replacePackage.Click += async (_, _) => await CompareOrInstallPackage(true);
        var rollbackPackage = new ToolStripMenuItem(StudioText("Activate previous package copy…", "Ενεργοποίηση προηγούμενου αντιγράφου…"));
        var hidePackage = new ToolStripMenuItem(StudioText("Hide package from Gallery", "Απόκρυψη πακέτου από Gallery"));
        menu.Items.Add(rollbackPackage); menu.Items.Add(hidePackage);
        var restorePackages = new ToolStripMenuItem(StudioText("Restore hidden packages", "Επαναφορά κρυμμένων πακέτων"));
        menu.Items.Add(restorePackages);
        restorePackages.Click += (_, _) =>
        {
            if (packageBusy) return;
            try
            {
                var pref = AppSettings.Load();
                if (pref.WallpaperGalleryHiddenPackages?.Count > 0) { pref.WallpaperGalleryHiddenPackages.Clear(); pref.Save(); ShowWallpaper(); }
            }
            catch (Exception ex) { MessageBox.Show(this, ex.Message, "Opsis"); }
        };
        rollbackPackage.Click += async (_, _) =>
        {
            if (packageBusy || menuRow?.LocalPackage is not InstalledWallpaperPackages.Entry entry) return;
            string? previousId = PackageLineage.Previous(AppSettings.Load().WallpaperGalleryPackagePrevious, entry.Id);
            if (previousId == null) return;
            packageBusy = true;
            try
            {
                var entries = await Task.Run(InstalledWallpaperPackages.Discover);
                var previous = entries.FirstOrDefault(x => x.Id == previousId);
                if (page.IsDisposed) return;
                if (previous == null || !entries.Any(x => x.Id == entry.Id && x.Index == entry.Index)) throw new InvalidDataException("Package copy unavailable.");
                if (MessageBox.Show(this, StudioText("Activate the previous copy? Only continue for trusted HTML/JavaScript packages. Files will not be deleted.", "Ενεργοποίηση του προηγούμενου αντιγράφου; Συνέχισε μόνο για αξιόπιστα HTML/JavaScript πακέτα. Δεν θα διαγραφούν αρχεία.") + "\n\n" + previous.Title,
                    "Opsis", MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2) != DialogResult.Yes) return;
                if (!await Task.Run(() => InstalledWallpaperPackages.StillInstalled(previous))) throw new InvalidDataException("Previous package copy changed or is unavailable.");
                if (page.IsDisposed) return;
                var cfg = WallpaperSettings.Load(); cfg.PageSource = previous.Index; cfg.Save(); host.SetMode("Page"); Sync();
            }
            catch (Exception ex) { if (!page.IsDisposed) MessageBox.Show(this, ex.Message, "Opsis", MessageBoxButtons.OK, MessageBoxIcon.Warning); }
            finally { packageBusy = false; }
        };
        hidePackage.Click += (_, _) =>
        {
            if (packageBusy || menuRow?.LocalPackage is not InstalledWallpaperPackages.Entry entry || !PackageLineage.ValidId(entry.Id)) return;
            if (MessageBox.Show(this, StudioText("Hide this entry? No files will be removed and the active wallpaper is unchanged. Use Restore hidden packages to undo.", "Απόκρυψη της εγγραφής; Δεν διαγράφονται αρχεία ούτε αλλάζει το ενεργό φόντο. Χρησιμοποίησε Επαναφορά κρυμμένων πακέτων για αναίρεση."), "Opsis", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) != DialogResult.Yes) return;
            try
            {
                var pref = AppSettings.Load(); pref.WallpaperGalleryHiddenPackages ??= new();
                if (!pref.WallpaperGalleryHiddenPackages.Contains(entry.Id))
                {
                    if (pref.WallpaperGalleryHiddenPackages.Count >= PackageLineage.Limit) throw new InvalidOperationException("Hidden package limit reached.");
                    pref.WallpaperGalleryHiddenPackages.Add(entry.Id); pref.Save();
                }
                rows.RemoveAll(r => r.Id == entry.Id); Render();
            }
            catch (Exception ex) { MessageBox.Show(this, ex.Message, "Opsis"); }
        };
        var sceneMonitorAction = new ToolStripMenuItem(StudioText("Scene per monitor (Weather mode)", "Σκηνικό ανά οθόνη (λειτουργία Weather)"));
        menu.Items.Add(sceneMonitorAction);
        menu.Opening += (_, e) =>
        {
            menuRow = menu.SourceControl?.Tag as GalleryRow;
            if (menuRow is not GalleryRow row) { e.Cancel = true; return; }
            verifyPackage.Visible = replacePackage.Visible = row.LocalPackage != null;
            foreach (ToolStripItem old in sceneMonitorAction.DropDownItems.Cast<ToolStripItem>().ToArray()) old.Dispose();
            sceneMonitorAction.DropDownItems.Clear();
            bool supportedScene = row.Mode is "Weather" or "Waves" or "Particles" || StudioWallpaperCatalog.Find(row.Mode) != null;
            sceneMonitorAction.Visible = supportedScene;
            sceneMonitorAction.Enabled = supportedScene && host.IsEnabled && WallpaperSettings.Load().Mode == "Weather";
            if (sceneMonitorAction.Enabled)
            {
                var monitors = MonitorTopologyService.Current();
                var topology = monitors.Select(x => new MonitorScenePolicy.Display(x.Id, x.DeviceName)).ToArray();
                var overrides = WallpaperSettings.Load().ScreenProceduralOverrides;
                var clearAll = new ToolStripMenuItem(StudioText("Clear all scene assignments…", "Διαγραφή όλων των αντιστοιχίσεων…"));
                clearAll.Enabled = overrides?.Count > 0;
                clearAll.Click += (_, _) =>
                {
                    if (MessageBox.Show(this, StudioText("Clear every per-monitor scene assignment, including disconnected monitors?", "Διαγραφή όλων των αντιστοιχίσεων σκηνικών, και για αποσυνδεδεμένες οθόνες;"), "Opsis", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) != DialogResult.Yes) return;
                    try { host.ClearScreenProceduralOverrides(); Sync(); }
                    catch (Exception ex) { MessageBox.Show(this, ex.Message, "Opsis"); }
                };
                sceneMonitorAction.DropDownItems.Add(clearAll);
                foreach (var monitor in monitors)
                {
                    var device = monitor.DeviceName;
                    var key = MonitorScenePolicy.Key(topology, device);
                    var screenMenu = new ToolStripMenuItem(device + (monitor.Primary ? StudioText(" (primary)", " (κύρια)") : ""));
                    sceneMonitorAction.DropDownItems.Add(screenMenu);
                    if (key == null)
                    {
                        screenMenu.Enabled = false;
                        screenMenu.ToolTipText = StudioText("No unique persistent monitor identity", "Δεν υπάρχει μοναδικό μόνιμο αναγνωριστικό οθόνης");
                        continue;
                    }
                    void AddScene(string label, MonitorSceneChoice? choice)
                    {
                        var action = new ToolStripMenuItem(label);
                        MonitorSceneChoice? current = null;
                        if (overrides != null) overrides.TryGetValue(key, out current);
                        action.Checked = choice == current;
                        action.Click += (_, _) =>
                        {
                            try
                            {
                                if (!host.SetScreenProceduralOverride(device, key, choice)) MessageBox.Show(this,
                                    StudioText("Monitor or mode changed. No settings were changed.", "Η οθόνη ή η λειτουργία άλλαξε. Δεν τροποποιήθηκαν οι ρυθμίσεις."), "Opsis");
                                Sync();
                            }
                            catch (Exception ex) { MessageBox.Show(this, ex.Message, "Opsis", MessageBoxButtons.OK, MessageBoxIcon.Warning); }
                        };
                        screenMenu.DropDownItems.Add(action);
                    }
                    AddScene(StudioText("Use shared scene", "Κοινό σκηνικό"), null);
                    if (row.Mode == "Weather")
                        for (int i = 0; i < sceneIds.Length; i++) AddScene(sceneLabels[i], new MonitorSceneChoice("Weather", sceneIds[i]));
                    else AddScene(row.Title, new MonitorSceneChoice(row.Mode, "Classic"));
                }
            }
            verifyPackage.Enabled = replacePackage.Enabled = !packageBusy;
            hidePackage.Visible = row.LocalPackage != null;
            hidePackage.Enabled = !packageBusy;
            rollbackPackage.Visible = row.LocalPackage != null && PackageLineage.Previous(AppSettings.Load().WallpaperGalleryPackagePrevious, row.Id) != null;
            rollbackPackage.Enabled = !packageBusy;
            favoriteAction.Text = _galleryFavorites.Contains(row.Id) ? StudioText("Remove favorite", "Αφαίρεση αγαπημένου") : StudioText("Add favorite", "Προσθήκη αγαπημένου");
            foreach (ToolStripItem old in monitorAction.DropDownItems.Cast<ToolStripItem>().ToArray()) old.Dispose();
            monitorAction.DropDownItems.Clear();
            monitorAction.Visible = VideoPath(row) != null;
            monitorAction.Enabled = host.IsEnabled && WallpaperSettings.Load().Mode == "Video";
            foreach (var screen in Screen.AllScreens)
            {
                string monitor = screen.DeviceName;
                var pin = new ToolStripMenuItem(StudioText("Use on ", "Χρήση στην ") + monitor);
                pin.Click += (_, _) =>
                {
                    try
                    {
                        string? media = VideoPath(row);
                        if (WallpaperSettings.Load().Mode != "Video" || !Screen.AllScreens.Any(x => x.DeviceName == monitor) || media == null || !File.Exists(media) || !GalleryVideoMetadata.IsSupported(media)) return;
                        if (row.Contribution != null && !OpsisEcosystemGallery.Discover().Any(x => x.PluginId == row.Contribution.PluginId && x.Id == row.Contribution.Id && x.AssetPath == media && x.Type.Equals("wallpaper", StringComparison.OrdinalIgnoreCase))) return;
                        if (WallpaperSettings.Load().DisabledVideoPaths.Contains(media)) return;
                        host.SetScreenVideoOverride(monitor, media);
                        Sync();
                    }
                    catch (Exception ex) { MessageBox.Show(this, ex.Message, "Opsis"); }
                };
                var clear = new ToolStripMenuItem(StudioText("Use shared playlist on ", "Κοινή playlist στην ") + monitor);
                clear.Click += (_, _) => { if (Screen.AllScreens.Any(x => x.DeviceName == monitor)) { host.SetScreenVideoOverride(monitor, null); Sync(); } };
                monitorAction.DropDownItems.Add(pin); monitorAction.DropDownItems.Add(clear);
            }
        };
        favoriteAction.Click += (_, _) => { if (menuRow is GalleryRow row) { if (!_galleryFavorites.Remove(row.Id) && _galleryFavorites.Count < 2048) _galleryFavorites.Add(row.Id); QueuePreferenceSave(); Render(); } };
        void OnWallpaperChanged() { if (page.IsDisposed || !page.IsHandleCreated) return; if (!page.InvokeRequired) Sync(); else { try { page.BeginInvoke(Sync); } catch (InvalidOperationException) { } } }
        host.StateChanged += OnWallpaperChanged;
        FormClosingEventHandler saveOnClose = (_, _) => FlushPreferenceSave();
        FormClosing += saveOnClose;
        page.Disposed += (_, _) => { FormClosing -= saveOnClose; if (!IsDisposed && !Disposing) FlushPreferenceSave(); preferenceSave.Stop(); preferenceSave.Dispose(); host.StateChanged -= OnWallpaperChanged; debounce.Stop(); debounce.Dispose(); scanLifetime.Cancel(); scanLifetime.Dispose(); menu.Dispose(); };
        page.Scroll += (_, _) => { _galleryScroll = -page.AutoScrollPosition.Y; QueuePreferenceSave(); foreach (var (_, button) in visible) if (button is WallpaperTile tile) tile.CancelGalleryPreview(); QueueViewport(); };
        library.LocationChanged += (_, _) => { _galleryScroll = -page.AutoScrollPosition.Y; foreach (var (_, button) in visible) if (button is WallpaperTile tile) tile.CancelGalleryPreview(); QueueViewport(); };
        page.HandleCreated += (_, _) => QueueViewport();
        page.SizeChanged += (_, _) => ResizeTiles(); toolbar.SizeChanged += (_, _) => ResizeTiles();
        SetPage("Page.Wallpaper.Title", shell); int savedScroll = _galleryScroll; Render(); page.AutoScrollPosition = new Point(0, savedScroll);
        // Metadata discovery is performed once, not for each search keystroke. Only the existing safe static-image action is exposed.
        async Task DiscoverAsync()
        {
            try
            {
                var items = await Task.Run(OpsisEcosystemGallery.Discover);
                var localPackages = await Task.Run(InstalledWallpaperPackages.Discover);
                var bundledPages = await Task.Run(() => WallpaperGalleryCatalog.Discover());
                bool changed = false;
                if (page.IsDisposed || page.Disposing) return;
                var extensions = new HashSet<string>(StringComparer.OrdinalIgnoreCase) { ".png", ".jpg", ".jpeg", ".webp", ".gif", ".bmp" };
                foreach (var item in items.Where(x => string.Equals(x.Type, "wallpaper", StringComparison.OrdinalIgnoreCase)).Take(1000))
                {
                    bool video = GalleryVideoMetadata.IsSupported(item.AssetPath);
                    if (!video && !extensions.Contains(Path.GetExtension(item.AssetPath))) continue;
                    if (video && rows.Any(r => r.Contribution != null && string.Equals(VideoPath(r), item.AssetPath, StringComparison.OrdinalIgnoreCase))) continue;
                    if (video) rows.RemoveAll(r => r.LocalVideo != null && string.Equals(r.LocalVideo, item.AssetPath, StringComparison.OrdinalIgnoreCase));
                    changed = true;
                    rows.Add(new("addon:" + item.PluginId + ":" + item.Id, video ? "Video" : "Image", item.Title, item.Category + " · " + item.Description, GalleryContributionCategory(item.Category), null, false, item));
                }
                foreach (var item in bundledPages.Where(x => !LandmarkCatalog.Scenes.Any(city => city.Id == x.Id)))
                {
                    if (rows.Any(r => r.BundledPage?.Id == item.Id)) continue;
                    rows.Add(new("bundle:" + item.Id, "Page", StudioText(item.Name, string.IsNullOrWhiteSpace(item.NameEl) ? item.Name : item.NameEl), StudioText(item.Description, item.DescriptionEl), item.Id == "opsis-glass-signature" ? "spectrum" : GalleryContributionCategory(item.Category), null, false, BundledPage: item, ExternalPoster: item.PosterPath)); changed = true;
                }
                var hiddenPackages = (AppSettings.Load().WallpaperGalleryHiddenPackages ?? new()).Where(PackageLineage.ValidId).Take(PackageLineage.Limit).ToHashSet(StringComparer.Ordinal);
                foreach (var entry in localPackages)
                {
                    if (hiddenPackages.Contains(entry.Id)) continue;
                    rows.Add(new(entry.Id, "Page", entry.Title, entry.Detail, "addons", null, false, null, null, entry)); changed = true;
                }
                if (changed) { int scroll = -page.AutoScrollPosition.Y; Render(); page.AutoScrollPosition = new Point(0, scroll); }
            }
            catch (Exception) { /* built-in catalog remains usable when discovery fails */ }
        }
        _ = DiscoverAsync();
    }

    private sealed class WallpaperTile : Button
    {
        private const int Columns = 5, FrameWidth = 288, FrameHeight = 162, Frames = 20;
        private readonly string _subtitle;
        private readonly string? _previewPath;
        private readonly string? _posterPath;
        private Image? _poster;
        private readonly BuiltInWallpaperPreview? _builtIn;
        private bool _posterLoaded;
        private readonly System.Windows.Forms.Timer _timer = new();
        private Image? _preview;
        private bool _pointer, _active;
        private static WallpaperTile? _activePreview;
        private int _frame;

        internal string Mode { get; }

        internal WallpaperTile(string mode, string title, string subtitle, string? asset, bool animate = false, string? externalPoster = null)
        {
            Mode = mode;
            Text = title;
            _subtitle = subtitle;
            AccessibleName = title;
            AccessibleDescription = subtitle;
            Name = "wallpaper-tile-" + (asset ?? mode).ToLowerInvariant();
            FlatStyle = FlatStyle.Flat;
            FlatAppearance.BorderSize = 0;
            UseVisualStyleBackColor = false;
            Cursor = Cursors.Hand;
            DoubleBuffered = true;
            Margin = new Padding(0, 0, 12, 12);
            Size = new Size(250, 206);
            var folder = Path.Combine(AppContext.BaseDirectory, "widgets", "wallpaper", "gallery");
            if (asset != null)
            {
                _posterPath = Path.Combine(folder, asset + ".jpg");
                if (animate) _previewPath = Path.Combine(folder, asset + ".preview.jpg");
            }
            if (externalPoster != null) _posterPath = externalPoster;
            _builtIn = externalPoster == null ? BuiltInWallpaperPreview.Create(mode) : null;
            _timer.Interval = _builtIn?.Animated == true ? 50 : 100;
            _timer.Tick += (_, _) =>
            {
                if (!Visible || !AppSettings.Peek().EnableAnimations || !RectangleToScreen(ClientRectangle).Contains(Cursor.Position)) { _pointer = false; StopPreview(); return; }
                _frame = _builtIn?.Animated == true ? (_frame + 1) % 7200 : (_frame + 1) % (Frames * 2 - 2);
                Invalidate();
            };
        }

        internal void SetActive(bool active)
        {
            if (_active == active) return;
            _active = active;
            Invalidate();
        }

        private static Image? ReadImage(string path, int width = 0)
        {
            try
            {
                if (new FileInfo(path).Length > 32L * 1024 * 1024) return null;
                if (Path.GetExtension(path).Equals(".webp", StringComparison.OrdinalIgnoreCase))
                    return WallpaperPackImage.ReadThumbnail(path, width > 0 ? width : 480);
                using var original = Image.FromFile(path);
                if (original.Width <= 0 || original.Height <= 0 || (long)original.Width * original.Height > 40_000_000) return null;
                return width > 0 ? new Bitmap(original, width, Math.Clamp((int)((long)original.Height * width / original.Width), 1, 960)) : new Bitmap(original);
            }
            catch (Exception ex) when (ex is IOException or ArgumentException or System.Runtime.InteropServices.ExternalException or DllNotFoundException or TypeInitializationException or InvalidDataException) { return null; }
        }

        protected override void OnMouseEnter(EventArgs e) { base.OnMouseEnter(e); _pointer = true; StartPreview(); }
        protected override void OnMouseLeave(EventArgs e) { base.OnMouseLeave(e); _pointer = false; StopPreview(); }
        protected override void OnGotFocus(EventArgs e) { base.OnGotFocus(e); Invalidate(); }
        protected override void OnLostFocus(EventArgs e) { base.OnLostFocus(e); Invalidate(); }
        protected override void OnVisibleChanged(EventArgs e) { base.OnVisibleChanged(e); if (!Visible && !Disposing) StopPreview(); }

        private void StartPreview()
        {
            if (!Visible || !AppSettings.Peek().EnableAnimations) return;
            if (_activePreview != this) _activePreview?.StopPreview();
            _activePreview = this;
            if (_builtIn?.Animated == true) { _builtIn.RefreshPalette(); _timer.Start(); }
            if (_previewPath != null && _preview == null)
            {
                _preview = ReadImage(_previewPath);
                if (_preview != null) { _frame = 0; _timer.Start(); }
            }
            Invalidate();
        }

        internal void CancelGalleryPreview() { _pointer = false; StopPreview(); }
        private System.Threading.CancellationTokenSource? _galleryPosterLifetime;
        internal async Task LoadGalleryPosterAsync(string path)
        {
            if (_galleryPosterLifetime != null || IsDisposed) return;
            _galleryPosterLifetime = new System.Threading.CancellationTokenSource();
            var token = _galleryPosterLifetime.Token;
            Bitmap? bitmap = null;
            try
            {
                bitmap = await VideoMetaService.GetThumbnailAsync(path, token);
                if (bitmap == null || token.IsCancellationRequested || IsDisposed || Disposing) return;
                _poster?.Dispose(); _poster = bitmap; bitmap = null; _posterLoaded = true;
                Invalidate();
            }
            catch (Exception) { /* optional thumbnail */ }
            finally { bitmap?.Dispose(); }
        }


        private void StopPreview()
        {
            if (_activePreview == this) _activePreview = null;
            _timer.Stop();
            _preview?.Dispose();
            _preview = null;
            Invalidate();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            var bounds = Rectangle.Inflate(ClientRectangle, -1, -1);
            if (bounds.Width < 16 || bounds.Height < 68) return;
            e.Graphics.Clear(UiTheme.PageBackground);
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
            using var outline = UiTheme.RoundedPath(bounds, 12);
            using var shell = new SolidBrush(_pointer ? UiTheme.SurfaceHover : UiTheme.Surface);
            e.Graphics.FillPath(shell, outline);
            var photograph = new Rectangle(8, 8, Width - 16, Height - 60);
            var state = e.Graphics.Save();
            using (var crop = UiTheme.RoundedPath(photograph, 7)) e.Graphics.SetClip(crop);
            e.Graphics.InterpolationMode = InterpolationMode.HighQualityBilinear;
            if (!_posterLoaded && _posterPath != null)
            {
                _posterLoaded = true;
                _poster = ReadImage(_posterPath, 480);
            }
            if (_builtIn != null) _builtIn.Draw(e.Graphics, photograph, _frame * .05);
            else if (_preview != null)
            {
                int index = Math.Min(_frame, Frames * 2 - 2 - _frame);
                var frame = new Rectangle(index % Columns * FrameWidth, index / Columns * FrameHeight, FrameWidth, FrameHeight);
                e.Graphics.DrawImage(_preview, photograph, frame, GraphicsUnit.Pixel);
            }
            else if (_poster != null) e.Graphics.DrawImage(_poster, photograph);
            else
            {
                using var gradient = new LinearGradientBrush(photograph, Color.FromArgb(18, 25, 45), Color.FromArgb(52, 73, 109), 26f);
                e.Graphics.FillRectangle(gradient, photograph);
                using var ring = new Pen(Color.FromArgb(95, 177, 198, 233), 2);
                int size = Math.Min(photograph.Height / 2, 56);
                e.Graphics.DrawEllipse(ring, photograph.X + (photograph.Width - size) / 2, photograph.Y + (photograph.Height - size) / 2, size, size);
                TextRenderer.DrawText(e.Graphics, Text, UiTheme.FontBody, photograph, Color.White,
                    TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.EndEllipsis | TextFormatFlags.NoPrefix);
            }
            e.Graphics.Restore(state);
            if (_active)
            {
                using var badge = new SolidBrush(UiTheme.AccentCyan);
                e.Graphics.FillEllipse(badge, Width - 35, 16, 20, 20);
                TextRenderer.DrawText(e.Graphics, "✓", UiTheme.FontBody, new Rectangle(Width - 35, 16, 20, 20),
                    Color.FromArgb(15, 22, 33), TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
            }
            const TextFormatFlags flags = TextFormatFlags.VerticalCenter | TextFormatFlags.EndEllipsis | TextFormatFlags.NoPrefix;
            TextRenderer.DrawText(e.Graphics, Text, UiTheme.FontSubheading,
                new Rectangle(12, Height - 49, Width - 24, 24), UiTheme.TextPrimary, flags);
            TextRenderer.DrawText(e.Graphics, _subtitle, UiTheme.FontBody,
                new Rectangle(12, Height - 25, Width - 24, 17), UiTheme.TextSecondary, flags);
            using var border = new Pen(_active || Focused ? UiTheme.AccentCyan : UiTheme.Border, _active ? 2 : 1);
            e.Graphics.DrawPath(border, outline);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (_activePreview == this) _activePreview = null;
                _timer.Stop();
                _timer.Dispose();
                _galleryPosterLifetime?.Cancel();
                _galleryPosterLifetime?.Dispose();
                _poster?.Dispose();
                _preview?.Dispose();
                _builtIn?.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
