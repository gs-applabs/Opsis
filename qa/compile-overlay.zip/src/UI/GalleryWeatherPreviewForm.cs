using Microsoft.Web.WebView2.WinForms;
using MotionDesk.Widgets;
using MotionDesk.Services;
using System.Text.Json;

namespace MotionDesk.UI;

// Explicit, temporary preview only: same shared environment, no host object,
// no provider, no changes to WallpaperSettings or the running wallpaper.
internal sealed class GalleryWeatherPreviewForm : Form
{
    private readonly WebView2 web = new() { Dock = DockStyle.Fill };
    private readonly Label status = new() { Dock = DockStyle.Top, AutoSize = true, Padding = new Padding(8) };
    internal GalleryWeatherPreviewForm(string scene, bool greek)
    {
        Text = greek ? "Προεπισκόπηση σκηνικού καιρού" : "Weather scene preview";
        StartPosition = FormStartPosition.CenterParent;
        ClientSize = new Size(960, 620); MinimumSize = new Size(520, 400);
        status.Text = greek ? "Φόρτωση τοπικής προεπισκόπησης…" : "Loading local preview…";
        Controls.Add(web); Controls.Add(status);
        Shown += async (_, _) =>
        {
            try
            {
                string path = Path.Combine(AppContext.BaseDirectory, "widgets", "wallpaper", "gallery-weather-preview.html");
                if (!File.Exists(path)) throw new FileNotFoundException("Preview assets missing", path);
                var env = await WebView2Support.CreateEnvironmentAsync();
                if (IsDisposed || Disposing || web.IsDisposed) return;
                await web.EnsureCoreWebView2Async(env);
                if (IsDisposed || Disposing || web.IsDisposed) return;
                var core = web.CoreWebView2 ?? throw new InvalidOperationException("WebView2 unavailable");
                WebView2Support.Harden(core, path, null, _ => { if (!IsDisposed && !Disposing) status.Text = greek ? "Αστοχία προεπισκόπησης. Κλείσε και άνοιξε ξανά." : "Preview failed. Close and reopen."; });
                core.Settings.AreHostObjectsAllowed = false;
                core.Settings.IsWebMessageEnabled = false;
                core.NavigationCompleted += async (_, e) =>
                {
                    if (IsDisposed || Disposing || web.IsDisposed) return;
                    if (!e.IsSuccess) { status.Text = greek ? "Αδυναμία φόρτωσης" : "Preview load failed"; return; }
                    try
                    {
                        string ready = await core.ExecuteScriptAsync("(()=>{if(typeof window.opsisPreviewInit!==\"function\")return false;window.opsisPreviewInit(" + JsonSerializer.Serialize(scene) + "," + (greek ? "true" : "false") + ");return true;})()");
                        if (!IsDisposed && !Disposing) { if (ready == "true") status.Visible = false; else status.Text = greek ? "Αδυναμία αρχικοποίησης προεπισκόπησης" : "Preview initialization failed"; }
                    }
                    catch (Exception ex) { if (!IsDisposed && !Disposing) status.Text = ex.Message; }
                };
                core.Navigate(new Uri(path).AbsoluteUri);
            }
            catch (Exception ex) { if (!IsDisposed && !Disposing) status.Text = ex.Message; }
        };
    }
}
