namespace MotionDesk.UI;

internal static class AppWindowIcon
{
    internal static Icon Value { get; } = Load();

    // Value is shared for the lifetime of the process. Consumers that dispose an icon
    // (e.g. Start Studio and the replacement taskbar) must request an owned copy.
    internal static Icon CreateOwnedCopy() => (Icon)Value.Clone();

    private static Icon Load()
    {
        try { return new Icon(Path.Combine(AppContext.BaseDirectory, "assets", "Opsis.ico")); }
        catch (Exception error) when (error is IOException or UnauthorizedAccessException or ArgumentException or System.Runtime.InteropServices.ExternalException)
        {
            // The executable contains the same canonical brand; no external download needed.
            try { return Icon.ExtractAssociatedIcon(Application.ExecutablePath) ?? SystemIcons.Application; }
            catch (Exception fallback) when (fallback is IOException or UnauthorizedAccessException or ArgumentException or System.Runtime.InteropServices.ExternalException)
            { return SystemIcons.Application; }
        }
    }
}

internal class AppDialog : Form
{
    public AppDialog() => Icon = AppWindowIcon.Value;
}
