using System;
namespace MotionDesk.UI;

// Pure bounds helper: one row overscan above and below; [first,last) is exclusive.
internal static class GalleryViewport
{
    internal static (int First, int Last) Range(int count, int columns, int stride, int top, int bottom)
    {
        if (count <= 0 || columns <= 0 || stride <= 0) return (0, 0);
        int rows = (count - 1) / columns + 1;
        int firstRow = Math.Clamp(Math.Max(0, top) / stride - 1, 0, rows);
        int lastRow = (int)Math.Clamp(((long)Math.Max(top, bottom) + stride - 1) / stride + 1, firstRow, rows);
        return ((int)Math.Min(count, (long)firstRow * columns), (int)Math.Min(count, (long)lastRow * columns));
    }
}
