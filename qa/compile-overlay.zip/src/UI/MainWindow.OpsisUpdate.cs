using System;
using System.Diagnostics;
using System.IO;
using System.Threading.Tasks;
using System.Windows.Forms;
using MotionDesk.Services;
using MotionDesk.Widgets;

namespace MotionDesk.UI;

public sealed partial class MainWindow
{
    private bool _manualOpsisUpdateBusy;

    private void AddOpsisUpdateControls(FlowLayoutPanel panel)
    {
        AddSection(panel, LocalizationManager.T("About.UpdateHeading"));
        var check = AddButton(panel, LocalizationManager.T("About.UpdateCheckNow"), async (_, _) => await CheckOpsisUpdateAsync());
        check.Name = "check-opsis-update";
        check.AccessibleName = LocalizationManager.T("About.UpdateCheckNow");
    }

    private async Task CheckOpsisUpdateAsync()
    {
        if (_manualOpsisUpdateBusy || IsDisposed) return;
        _manualOpsisUpdateBusy = true;
        string T(string key) => LocalizationManager.T(key);
        try
        {
            _statusLabel.Text = T("About.UpdateChecking");
            var result = await UpdateCheckService.CheckAsync();
            if (IsDisposed || Disposing) return;
            if (!result.Succeeded)
            {
                MessageBox.Show(this, T("About.UpdateFailed"), "Opsis", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (result.Update is not { } update)
            {
                MessageBox.Show(this, string.Format(T("About.UpdateUpToDate"), AppVersion.Label), "Opsis", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if (!update.CanInstallAutomatically)
            {
                if (MessageBox.Show(this, string.Format(T("About.UpdateNewer"), update.Version) + "\n" + T("About.UpdateNoDigest"), "Opsis", MessageBoxButtons.OKCancel, MessageBoxIcon.Information) == DialogResult.OK)
                    Process.Start(new ProcessStartInfo(update.PageUrl) { UseShellExecute = true });
                return;
            }
            if (MessageBox.Show(this, string.Format(T("About.UpdateConfirm"), update.Version), T("About.UpdateConfirmTitle"), MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;
            var progress = new Progress<double>(p => { if (!IsDisposed && !Disposing) _statusLabel.Text = string.Format(T("About.UpdateDownloading"), (int)(100 * p)); });
            var verified = await UpdateInstallerService.DownloadAsync(update, progress);
            if (IsDisposed || Disposing) return;
            UpdateInstallerService.LaunchAfterExit(verified.Path, verified.Sha256);
            TrayApplicationContext.RequestExit();
        }
        catch (InvalidDataException ex) when (ex.Message == "hash-mismatch")
        {
            if (!IsDisposed && !Disposing) MessageBox.Show(this, T("About.UpdateVerifyFailed"), "Opsis", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        catch (Exception)
        {
            if (!IsDisposed && !Disposing) MessageBox.Show(this, T("About.UpdateFailed"), "Opsis", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
        finally
        {
            _manualOpsisUpdateBusy = false;
            if (!IsDisposed && !Disposing) _statusLabel.Text = "Opsis";
        }
    }
}
