using System.Drawing.Drawing2D;
using MotionDesk.Services;

namespace MotionDesk.UI;

public sealed partial class MainWindow
{
    private static class SeasonalBrand
    {
        // Orthodox Easter, Julian computus converted to Gregorian (1900–2099).
        internal static DateTime Easter(int year)
        {
            if (year is < 1900 or > 2099) throw new ArgumentOutOfRangeException(nameof(year));
            int d = (19 * (year % 19) + 15) % 30;
            int e = (2 * (year % 4) + 4 * (year % 7) - d + 34) % 7;
            int n = d + e + 114;
            return new DateTime(year, n / 31, n % 31 + 1).AddDays(13);
        }
        internal static string? Select(DateTime day)
        {
            day = day.Date;
            if ((day.Month == 3 && day.Day == 25) || (day.Month == 10 && day.Day == 28)) return "national";
            if ((day.Month == 12 && day.Day >= 15) || (day.Month == 1 && day.Day <= 6)) return "christmas";
            if (day.Year is < 1900 or > 2099) return null;
            DateTime easter = Easter(day.Year);
            if (day >= easter.AddDays(-7) && day <= easter.AddDays(7)) return "easter";
            if (day >= easter.AddDays(-70) && day <= easter.AddDays(-49)) return "carnival";
            return null;
        }
        private static Bitmap? _image;
        private static string? _key;
        private static string? _observed;
        // UI-thread only; preview is intentionally not persisted.
        internal static DateTime? PreviewDate { get; set; }
        internal static string? CurrentKey => AppSettings.Peek().SeasonalBrandEnabled ? Select(PreviewDate ?? DateTime.Today) : null;
        internal static bool Changed()
        {
            var next = CurrentKey;
            if (next == _observed) return false;
            _observed = next;
            return true;
        }
        internal static bool Draw(Graphics g, Rectangle bounds, double phase, bool animate)
        {
            string? key = CurrentKey;
            if (key == null) { Release(); return false; }
            if (_key != key)
            {
                Release(); _key = key;
                try
                {
                    string path = Path.Combine(AppContext.BaseDirectory, "assets", "seasonal-brand", key + ".png");
                    using var file = Image.FromFile(path);
                    if (file.Width != 512 || file.Height != 512) return false;
                    _image = new Bitmap(file);
                }
                catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or ArgumentException or System.Runtime.InteropServices.ExternalException) { }
            }
            if (_image == null || bounds.Width <= 0 || bounds.Height <= 0) return false;
            int side = Math.Min(bounds.Width, bounds.Height);
            bounds = new Rectangle(bounds.X + (bounds.Width-side)/2,bounds.Y + (bounds.Height-side)/2,side,side);
            var state = g.Save();
            try
            {
                g.InterpolationMode = InterpolationMode.HighQualityBicubic;
                g.SmoothingMode = SmoothingMode.AntiAlias;
                g.SetClip(bounds, CombineMode.Intersect);
                g.DrawImage(_image, bounds);
                if (key == "christmas" && animate)
                {
                    using var snow = new SolidBrush(Color.FromArgb(210, Color.White));
                    for (int i = 0; i < 9; i++)
                    {
                        float x = bounds.Left + bounds.Width * ((i * 37 % 97) / 97f);
                        float y = bounds.Top + bounds.Height * (float)((phase * (.06 + i * .006) + i * .173) % 1.0);
                        float r = Math.Max(1f, bounds.Width * (.017f + (i % 3) * .006f));
                        g.FillEllipse(snow, x, y, r, r);
                    }
                }
            }
            finally { g.Restore(state); }
            return true;
        }
        internal static void Release() { _image?.Dispose(); _image = null; _key = null; }
    }

    private void RefreshSeasonalBrand(bool force = false)
    {
        if (!SeasonalBrand.Changed() && !force) return;
        _studioBrand?.Invalidate();
        if (!_usesStudio) _brandDot?.Invalidate();
    }

    private Control BuildSeasonalPreview()
    {
        var row = new FlowLayoutPanel { AutoSize = true, WrapContents = true, Margin = new Padding(0, 3, 0, 8) };
        var date = new DateTimePicker { Format = DateTimePickerFormat.Short, Width = 130, MinDate = new DateTime(1900,1,1), MaxDate = new DateTime(2099,12,31) };
        var today = SeasonalBrand.PreviewDate ?? DateTime.Today;
        date.Value = today < date.MinDate ? date.MinDate : today > date.MaxDate ? date.MaxDate : today;
        var preview = MediaButton(StudioText("Preview logo", "Προεπισκόπηση λογοτύπου"));
        var reset = MediaButton(StudioText("Use current date", "Χρήση σημερινής ημερομηνίας"));
        preview.Click += (_, _) => { SeasonalBrand.PreviewDate = date.Value.Date; RefreshSeasonalBrand(true); };
        reset.Click += (_, _) => { SeasonalBrand.PreviewDate = null; RefreshSeasonalBrand(true); };
        row.Controls.AddRange([date, preview, reset]);
        row.Disposed += (_, _) => { SeasonalBrand.PreviewDate = null; if (!IsDisposed && !Disposing) RefreshSeasonalBrand(true); };
        return row;
    }
}
