using System.Security.Cryptography;
using System.Text;

namespace MotionDesk.Services;

/// <summary>Non-destructive removal for direct children of the per-user plugin root.
/// Never recursively delete a registry-provided folder or an unauthenticated legacy queue entry.</summary>
internal static class PluginRemovalPolicy
{
    internal static bool IsManagedPackage(string dataRoot, string folder)
    {
        try
        {
            if (!Path.IsPathFullyQualified(folder)) return false;
            string root = Path.GetFullPath(Path.Combine(dataRoot, "plugins"));
            string full = Path.TrimEndingDirectorySeparator(Path.GetFullPath(folder));
            return string.Equals(Path.GetDirectoryName(full), root, StringComparison.OrdinalIgnoreCase) &&
                PackagePaths.IsExistingUnlinkedPath(dataRoot, full) && Directory.Exists(full) &&
                Directory.EnumerateFiles(full, "*Plugin.dll").Any();
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or ArgumentException or NotSupportedException)
        { return false; }
    }

    private static string ReceiptPath(string dataRoot, string folder)
    {
        string id = Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(Path.TrimEndingDirectorySeparator(Path.GetFullPath(folder)).ToUpperInvariant())));
        return Path.Combine(dataRoot, "plugin-removal", id + ".json");
    }

    private static string SafeDirectory(string dataRoot, string name)
    {
        if (!Directory.Exists(dataRoot) || PackagePaths.IsLink(dataRoot)) throw new InvalidDataException("Unsafe data root.");
        string dir = Path.Combine(dataRoot, name);
        Directory.CreateDirectory(dir);
        if (!PackagePaths.IsExistingUnlinkedPath(dataRoot, dir)) throw new InvalidDataException("Unsafe plugin removal directory.");
        return dir;
    }

    internal sealed record Receipt(string Folder, string Digest);
    internal static void Authorize(string dataRoot, string folder)
    {
        if (!IsManagedPackage(dataRoot, folder)) throw new InvalidOperationException("Use the original installer to remove external or bundled plugins.");
        var digest = PluginTrust.HashCompletePackage(folder);
        SafeDirectory(dataRoot, "plugin-removal");
        var file = ReceiptPath(dataRoot, folder);
        if (File.Exists(file) && !PackagePaths.IsExistingUnlinkedPath(dataRoot, file)) throw new InvalidDataException("Unsafe receipt path.");
        AtomicFile.WriteAllText(file, System.Text.Json.JsonSerializer.Serialize(new Receipt(Path.GetFullPath(folder), digest)));
    }

    internal static bool TryArchive(string dataRoot, string folder)
    {
        if (!IsManagedPackage(dataRoot, folder)) return false;
        var file = ReceiptPath(dataRoot, folder);
        if (!PackagePaths.IsExistingUnlinkedPath(dataRoot, file) || new FileInfo(file).Length > 8192) return false;
        var receipt = System.Text.Json.JsonSerializer.Deserialize<Receipt>(File.ReadAllText(file));
        if (receipt == null || !string.Equals(receipt.Folder, Path.GetFullPath(folder), StringComparison.OrdinalIgnoreCase) ||
            !string.Equals(receipt.Digest, PluginTrust.HashCompletePackage(folder), StringComparison.Ordinal)) return false;
        var backup = SafeDirectory(dataRoot, "plugin-removed-backups");
        string target = Path.Combine(backup, Guid.NewGuid().ToString("N"));
        Directory.Move(folder, target); // same volume; no package deletion; never overwrite another directory
        try { File.Delete(file); } catch (IOException) { } catch (UnauthorizedAccessException) { }
        return true;
    }
}
