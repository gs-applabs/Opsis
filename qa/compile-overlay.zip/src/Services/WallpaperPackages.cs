using System.IO.Compression;

namespace MotionDesk.Services;

/// <summary>A read-only inspection report. Inspecting never creates or runs package content.</summary>
public sealed class WallpaperPackagePreview
{
    public IReadOnlyList<string> Files { get; init; } = Array.Empty<string>();
    public long UncompressedBytes { get; init; }
    public string EntryPoint { get; init; } = "index.html";
    public int ScriptCount { get; init; }
}

/// <summary>
/// Local wallpaper ZIPs are untrusted executable web content. Validate *every* ZIP entry before
/// showing a preview or extracting; extract into a private staging folder with bounded streams;
/// only publish the package directory after the entire archive has passed verification.
/// </summary>
public static class WallpaperPackages
{
    public const long MaxUncompressedBytes = 400L * 1024 * 1024;
    public const int MaxEntries = 4000;

    public static string Root => Path.Combine(AppPaths.AppDataFolder, "wallpapers");

    private sealed class EntryPlan
    {
        public required ZipArchiveEntry Entry { get; init; }
        public required string RelativePath { get; init; }
        public required bool IsDirectory { get; init; }
    }

    private sealed class PackagePlan
    {
        public required string Prefix { get; init; }
        public required List<EntryPlan> Entries { get; init; }
        public long TotalBytes { get; init; }
    }

    /// <summary>Read-only preflight: lists the files that would actually be installed.</summary>
    public static WallpaperPackagePreview Inspect(string zipPath)
    {
        using var zip = ZipFile.OpenRead(zipPath);
        var plan = Validate(zip);
        return new WallpaperPackagePreview
        {
            Files = plan.Entries.Where(e => !e.IsDirectory).Select(e => e.RelativePath).ToArray(),
            UncompressedBytes = plan.TotalBytes,
            EntryPoint = plan.Prefix + "index.html",
            ScriptCount = plan.Entries.Count(e => !e.IsDirectory &&
                (e.RelativePath.EndsWith(".js", StringComparison.OrdinalIgnoreCase) ||
                 e.RelativePath.EndsWith(".html", StringComparison.OrdinalIgnoreCase)))
        };
    }

    /// <summary>Returns the path of the installed index.html; failures leave no partial package.</summary>
    public static string Import(string zipPath, string? destinationRoot = null)
    {
        destinationRoot ??= Root;
        using var zip = ZipFile.OpenRead(zipPath);
        // Repeat preflight at import: preview is not a security authorization and the ZIP can change.
        var plan = Validate(zip);
        destinationRoot = Path.GetFullPath(destinationRoot);
        CheckImportAncestors(destinationRoot);
        Directory.CreateDirectory(destinationRoot);
        CheckImportAncestors(destinationRoot);
        string staging = Path.Combine(destinationRoot, ".opsis-import-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(staging);
        string stageRoot = Path.GetFullPath(staging) + Path.DirectorySeparatorChar;
        bool committed = false;
        try
        {
            long totalWritten = 0;
            foreach (var item in plan.Entries)
            {
                string dest = Path.GetFullPath(Path.Combine(stageRoot, item.RelativePath.Replace('/', Path.DirectorySeparatorChar)));
                if (!dest.StartsWith(stageRoot, StringComparison.OrdinalIgnoreCase))
                    throw new InvalidDataException("Unsafe wallpaper package path.");
                if (item.IsDirectory) { Directory.CreateDirectory(dest); continue; }

                Directory.CreateDirectory(Path.GetDirectoryName(dest)!);
                using var source = item.Entry.Open();
                using var output = new FileStream(dest, FileMode.CreateNew, FileAccess.Write, FileShare.None);
                byte[] buffer = new byte[81920];
                long fileWritten = 0;
                int count;
                while ((count = source.Read(buffer, 0, buffer.Length)) > 0)
                {
                    // Check BEFORE addition so a hostile ZIP cannot overflow or bypass the limit.
                    if (count > item.Entry.Length - fileWritten || count > MaxUncompressedBytes - totalWritten)
                        throw new InvalidDataException("Wallpaper package exceeded its declared/allowed size.");
                    output.Write(buffer, 0, count);
                    fileWritten += count;
                    totalWritten += count;
                }
                if (fileWritten != item.Entry.Length)
                    throw new InvalidDataException("Wallpaper package entry size mismatch.");
            }

            CheckImportAncestors(destinationRoot);
            if (IsLinked(staging)) throw new InvalidDataException("Linked staging directory.");
            string name = SafeName(Path.GetFileNameWithoutExtension(zipPath));
            string finalFolder = UniqueFolder(destinationRoot, name);
            Directory.Move(staging, finalFolder); // atomic publish on the same filesystem
            committed = true;
            return Path.Combine(finalFolder, "index.html");
        }
        finally
        {
            if (!committed)
            {
                try { Directory.Delete(staging, true); }
                catch (IOException) { }
                catch (UnauthorizedAccessException) { }
            }
        }
    }

    public sealed record PackageVerification(int ExpectedFiles, int MatchedFiles, int Missing, int Changed, int Unexpected, IReadOnlyList<string> Details)
    {
        public bool Matches => Missing == 0 && Changed == 0 && Unexpected == 0;
    }

    // Compare installed files with the user-selected original ZIP. No execution, extraction,
    // repair in place, or claim of publisher authenticity. The caller must trust the ZIP.
    public static PackageVerification VerifyAgainstArchive(string indexHtml, string zipPath)
    {
        var root = Path.GetFullPath(Root);
        var index = Path.GetFullPath(indexHtml);
        var dir = Path.GetDirectoryName(index) ?? throw new InvalidDataException("Invalid package path.");
        if (!string.Equals(Path.GetDirectoryName(dir), root, StringComparison.OrdinalIgnoreCase) ||
            !string.Equals(Path.GetFileName(index), "index.html", StringComparison.OrdinalIgnoreCase) ||
            !Directory.Exists(dir) || IsLinked(root) || IsLinked(dir))
            throw new InvalidDataException("Only installed local packages can be compared.");
        CheckImportAncestors(dir);
        using var zip = ZipFile.OpenRead(zipPath);
        var plan = Validate(zip);
        var expected = plan.Entries.Where(x => !x.IsDirectory).ToDictionary(x => x.RelativePath, StringComparer.OrdinalIgnoreCase);
        var details = new List<string>();
        int matched = 0, missing = 0, changed = 0, unexpected = 0;
        void Note(string message) { if (details.Count < 60) details.Add(message); }
        // Enumerate without following reparse points. Refuse ambiguous case variants.
        var actual = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        var pending = new Stack<string>(); pending.Push(dir);
        int entries = 0; long installedBytes = 0;
        while (pending.TryPop(out var folder))
        {
            foreach (var item in Directory.EnumerateFileSystemEntries(folder))
            {
                if (++entries > MaxEntries) throw new InvalidDataException("Installed package exceeds the entry limit.");
                if (IsLinked(item)) throw new InvalidDataException("Installed package contains a reparse point.");
                if (Directory.Exists(item)) { pending.Push(item); continue; }
                string relative = Path.GetRelativePath(dir, item).Replace('\\', '/');
                var length = new FileInfo(item).Length;
                if (length > MaxUncompressedBytes - installedBytes) throw new InvalidDataException("Installed package exceeds the size limit.");
                installedBytes += length;
                if (!actual.TryAdd(relative, item)) throw new InvalidDataException("Ambiguous installed path.");
            }
        }
        var a = new byte[81920]; var b = new byte[81920];
        foreach (var (relative, entry) in expected)
        {
            if (!actual.Remove(relative, out var file)) { missing++; Note("Missing: " + relative); continue; }
            if (new FileInfo(file).Length != entry.Entry.Length) { changed++; Note("Changed: " + relative); continue; }
            using var installed = File.OpenRead(file);
            using var archived = entry.Entry.Open();
            // Enforce declared size during reads even if a hostile archive lies about its uncompressed size.
            if (EqualContent(installed, archived, entry.Entry.Length, a, b)) matched++;
            else { changed++; Note("Changed: " + relative); }
        }
        foreach (var relative in actual.Keys) { unexpected++; Note("Unexpected: " + relative); }
        return new(expected.Count, matched, missing, changed, unexpected, details);
    }

    private static bool IsLinked(string path) => (File.GetAttributes(path) & FileAttributes.ReparsePoint) != 0;

    private static bool EqualContent(Stream left, Stream right, long length, byte[] a, byte[] b)
    {
        long remaining = length;
        while (remaining > 0)
        {
            int count = (int)Math.Min(a.Length, remaining);
            if (left.ReadAtLeast(a.AsSpan(0, count), count, false) != count ||
                right.ReadAtLeast(b.AsSpan(0, count), count, false) != count ||
                !a.AsSpan(0, count).SequenceEqual(b.AsSpan(0, count))) return false;
            remaining -= count;
        }
        return left.ReadByte() == -1 && right.ReadByte() == -1;
    }

    private static PackagePlan Validate(ZipArchive zip)
    {
        if (zip.Entries.Count == 0 || zip.Entries.Count > MaxEntries)
            throw new InvalidDataException("Wallpaper package contains no files or too many entries.");

        var all = new List<(ZipArchiveEntry Entry, string Normalized, bool Directory)>();
        var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        long total = 0;
        foreach (var entry in zip.Entries)
        {
            string path = entry.FullName.Replace('\\', '/');
            bool directory = path.EndsWith("/", StringComparison.Ordinal);
            string trimmed = directory ? path.TrimEnd('/') : path;
            string[] parts = trimmed.Split('/');
            if (parts.Length > 32 || trimmed.Length > 512 || parts.Any(p => p.Length > 255))
                throw new InvalidDataException("Wallpaper package path exceeds the supported limits.");
            if (parts.Length == 0 || parts.Any(UnsafeSegment) || path.StartsWith("/", StringComparison.Ordinal) ||
                !seen.Add(trimmed))
                throw new InvalidDataException("Wallpaper package has an unsafe or duplicate path: " + path);

            // UNIX symlink entries cannot become files or directories in a trusted package.
            int unixFileType = (entry.ExternalAttributes >> 16) & 0xF000;
            if ((unixFileType != 0 && unixFileType != (directory ? 0x4000 : 0x8000)) || (entry.ExternalAttributes & 0x400) != 0) // symlink or DOS reparse point
                throw new InvalidDataException("Wallpaper package contains a link: " + path);
            if (directory && entry.Length != 0)
                throw new InvalidDataException("Wallpaper package has an invalid directory entry.");
            if (entry.Length < 0 || entry.Length > MaxUncompressedBytes - total)
                throw new InvalidDataException("Wallpaper package exceeds the size limit.");
            total += entry.Length;
            all.Add((entry, trimmed, directory));
        }

        // A root index wins; otherwise exactly one wrapper must contain every entry.
        ValidatePackageHierarchy(all.Select(x => (x.Normalized, x.Directory)));
        var rootIndex = all.Any(x => !x.Directory && x.Normalized.Equals("index.html", StringComparison.OrdinalIgnoreCase));
        string prefix = "";
        if (!rootIndex)
        {
            var wrappers = all.Where(x => !x.Directory && x.Normalized.Split('/').Length == 2 &&
                x.Normalized.EndsWith("/index.html", StringComparison.OrdinalIgnoreCase)).ToArray();
            if (wrappers.Length != 1) throw new InvalidDataException("Exactly one package entry point is required.");
            prefix = wrappers[0].Normalized[..(wrappers[0].Normalized.LastIndexOf('/') + 1)];
            if (all.Any(x => !x.Normalized.StartsWith(prefix, StringComparison.OrdinalIgnoreCase) &&
                !(x.Directory && x.Normalized.Equals(prefix.TrimEnd('/'), StringComparison.OrdinalIgnoreCase))))
                throw new InvalidDataException("Unexpected entry outside the package wrapper.");
        }

        var selected = new List<EntryPlan>();
        long selectedBytes = 0;
        foreach (var item in all)
        {
            if (!item.Normalized.StartsWith(prefix, StringComparison.OrdinalIgnoreCase)) continue;
            string rel = item.Normalized[prefix.Length..];
            if (!item.Directory && rel.Equals("index.html", StringComparison.OrdinalIgnoreCase)) rel = "index.html";
            if (rel.Length == 0) continue;
            selected.Add(new EntryPlan { Entry = item.Entry, RelativePath = rel, IsDirectory = item.Directory });
            selectedBytes += item.Entry.Length;
        }
        if (!selected.Any(e => !e.IsDirectory && e.RelativePath.Equals("index.html", StringComparison.OrdinalIgnoreCase)))
            throw new InvalidDataException("Wallpaper package entry point is missing.");
        return new PackagePlan { Prefix = prefix, Entries = selected, TotalBytes = selectedBytes };
    }

    // Check implicit parent directories as well as explicit ZIP entries. Case-insensitive
    // Windows paths may alias even when only their parent spellings are different.
    private static void ValidatePackageHierarchy(IEnumerable<(string Path, bool Directory)> entries)
    {
        var nodes = new Dictionary<string, (string Spelling, bool Directory)>(StringComparer.OrdinalIgnoreCase);
        foreach (var (path, directory) in entries)
        {
            string[] parts = path.Split('/');
            string current = "";
            for (int i = 0; i < parts.Length; i++)
            {
                current = i == 0 ? parts[i] : current + "/" + parts[i];
                bool isDirectory = i < parts.Length - 1 || directory;
                if (nodes.TryGetValue(current, out var previous))
                {
                    if (previous.Directory != isDirectory || !string.Equals(previous.Spelling, current, StringComparison.Ordinal))
                        throw new InvalidDataException("Conflicting package paths: " + current);
                }
                else
                {
                    if (nodes.Count >= MaxEntries * 4) throw new InvalidDataException("Too many implicit package folders.");
                    nodes.Add(current, (current, isDirectory));
                }
            }
        }
    }

    private static void CheckImportAncestors(string folder)
    {
        for (DirectoryInfo? d = new DirectoryInfo(folder); d != null; d = d.Parent)
        {
            try
            {
                var attrs = File.GetAttributes(d.FullName);
                if ((attrs & FileAttributes.ReparsePoint) != 0 || (attrs & FileAttributes.Directory) == 0)
                    throw new InvalidDataException("Linked or non-directory package path.");
            }
            catch (FileNotFoundException) { }
            catch (DirectoryNotFoundException) { }
        }
    }

    private static bool UnsafeSegment(string segment)
    {
        if (string.IsNullOrEmpty(segment) || segment is "." or ".." ||
            segment.EndsWith(' ') || segment.EndsWith('.') ||
            segment.Any(c => char.IsControl(c) || "<>:\"|?*".Contains(c))) return true;
        string stem = segment.Split('.')[0].TrimEnd(' ');
        if (stem.Equals("CONIN$", StringComparison.OrdinalIgnoreCase) || stem.Equals("CONOUT$", StringComparison.OrdinalIgnoreCase)) return true;
        return stem.Equals("CON", StringComparison.OrdinalIgnoreCase) ||
               stem.Equals("PRN", StringComparison.OrdinalIgnoreCase) ||
               stem.Equals("AUX", StringComparison.OrdinalIgnoreCase) ||
               stem.Equals("NUL", StringComparison.OrdinalIgnoreCase) ||
               (stem.Length == 4 && (stem.StartsWith("COM", StringComparison.OrdinalIgnoreCase) ||
                                     stem.StartsWith("LPT", StringComparison.OrdinalIgnoreCase)) && (stem[3] is >= '1' and <= '9' or '¹' or '²' or '³'));
    }

    /// <summary>Export is transactional: never destroy the old archive before a complete new one exists.</summary>
    public static void Export(string indexHtml, string zipPath)
    {
        string index = Path.GetFullPath(indexHtml);
        string dir = Path.GetDirectoryName(index) ?? throw new ArgumentException("No folder", nameof(indexHtml));
        string output = Path.GetFullPath(zipPath);
        string root = Path.TrimEndingDirectorySeparator(dir) + Path.DirectorySeparatorChar;
        if (!File.Exists(index) || !string.Equals(Path.GetFileName(index), "index.html", StringComparison.OrdinalIgnoreCase))
            throw new InvalidDataException("Choose a wallpaper package index.html.");
        if (Path.GetPathRoot(dir) == dir || output.StartsWith(root, StringComparison.OrdinalIgnoreCase))
            throw new IOException("Choose a package folder and an output path outside it.");
        // Reject linked ancestors too: a junction outside the package could redirect an export
        // back into the package or cause traversal of unexpected user files.
        static void CheckAncestors(string folder)
        {
            for (DirectoryInfo? d = new DirectoryInfo(folder); d != null; d = d.Parent)
                if (IsLinked(d.FullName)) throw new InvalidDataException("Linked package/output folder is not supported.");
        }
        CheckAncestors(dir);
        CheckAncestors(Path.GetDirectoryName(output)!);
        if (File.Exists(output) && IsLinked(output)) throw new InvalidDataException("Linked output file is not supported.");
        string temporary = Path.Combine(Path.GetDirectoryName(output)!, Guid.NewGuid() + ".tmp");
        bool ownsTemporary = false;
        try
        {
            using (var stream = new FileStream(temporary, FileMode.CreateNew, FileAccess.ReadWrite, FileShare.None))
            {
                ownsTemporary = true;
                using var archive = new ZipArchive(stream, ZipArchiveMode.Create, leaveOpen: true);
                var pending = new Stack<string>(); pending.Push(dir);
                var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                long total = 0; int count = 0;
                byte[] buffer = new byte[81920];
                while (pending.TryPop(out var folder))
                {
                    if (IsLinked(folder)) throw new InvalidDataException("Linked package directory.");
                    foreach (string item in Directory.EnumerateFileSystemEntries(folder))
                    {
                        if (++count > MaxEntries) throw new InvalidDataException("Package exceeds the entry limit.");
                        if (IsLinked(item)) throw new InvalidDataException("Linked package entry.");
                        string relative = Path.GetRelativePath(dir, item).Replace('\\', '/');
                        if (relative.Split('/').Any(UnsafeSegment) || !seen.Add(relative)) throw new InvalidDataException("Unsafe package path.");
                        if (Directory.Exists(item)) { pending.Push(item); archive.CreateEntry(relative + "/"); continue; }
                        using var input = new FileStream(item, FileMode.Open, FileAccess.Read, FileShare.Read);
                        long expected = input.Length, remaining = expected;
                        if (expected > MaxUncompressedBytes - total) throw new InvalidDataException("Package exceeds the size limit.");
                        using var target = archive.CreateEntry(relative, CompressionLevel.Optimal).Open();
                        int n;
                        while ((n = input.Read(buffer, 0, buffer.Length)) != 0)
                        {
                            if (n > remaining || n > MaxUncompressedBytes - total) throw new InvalidDataException("Package file changed during export.");
                            target.Write(buffer, 0, n); remaining -= n; total += n;
                        }
                        if (remaining != 0) throw new InvalidDataException("Package file changed during export.");
                    }
                }
            }
            // Validate the completed archive with the same parser as Import, before publishing it.
            _ = Inspect(temporary);
            File.Move(temporary, output, overwrite: true);
            ownsTemporary = false;
        }
        finally { if (ownsTemporary && File.Exists(temporary)) File.Delete(temporary); }
    }

    private static string SafeName(string n)
    {
        foreach (char c in Path.GetInvalidFileNameChars()) n = n.Replace(c, '_');
        n = n.Trim().Trim('.');
        return n.Length == 0 ? "wallpaper" : n.Length > 60 ? n[..60] : n;
    }

    private static string UniqueFolder(string root, string name)
    {
        string p = Path.Combine(root, name);
        for (int i = 2; Directory.Exists(p) || File.Exists(p); i++) p = Path.Combine(root, $"{name} ({i})");
        return p;
    }
}
