using System;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Runtime.InteropServices;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;

namespace MotionDesk.Services
{
    // Thumbnail + duration for the wallpaper video list.
    //  - Thumbnail: the Windows Shell thumbnail provider (IShellItemImageFactory) — the same picture Explorer shows, no extra dependency.
    //  - Duration: parsed from "ffmpeg -i" output when FFmpeg is available (already used for .wmv conversion); otherwise no duration is shown.
    // Both are computed on background threads and cached per path, so rebuilding the page never blocks the UI.
    public static class VideoMetaService
    {
        private static readonly WallpaperMetaCache<byte[]> Thumbs = new(256, 16L * 1024 * 1024, 128, 2);
        private static readonly WallpaperMetaCache<string> Durations = new(512, 128 * 1024, 128, 2);
        private static readonly SemaphoreSlim DurationGate = new(2);

        private static string? CacheKey(string path)
        {
            try
            {
                var f = new FileInfo(path);
                return f.Exists ? f.FullName + "\0" + f.Length + "\0" + f.LastWriteTimeUtc.Ticks : null;
            }
            catch (Exception) { return null; }
        }

        // The returned Bitmap is exclusively owned by the caller, not by the LRU.
        public static Task<Bitmap?> GetThumbnailAsync(string path) => GetThumbnailAsync(path, CancellationToken.None);

        public static async Task<Bitmap?> GetThumbnailAsync(string path, CancellationToken ct)
        {
            var key = CacheKey(path);
            if (key == null) return null;
            var bytes = await Thumbs.GetAsync(key, () => Task.FromResult(LoadThumbnailBytes(path)), b => b.LongLength, ct).ConfigureAwait(false);
            ct.ThrowIfCancellationRequested();
            if (bytes == null) return null;
            using var stream = new MemoryStream(bytes, writable: false);
            using var image = Image.FromStream(stream);
            return new Bitmap(image);
        }

        private static byte[]? LoadThumbnailBytes(string path)
        {
            using var source = LoadThumbnail(path);
            if (source == null) return null;
            double scale = Math.Min(1, Math.Min(128.0 / source.Width, 72.0 / source.Height));
            using var small = new Bitmap(source, Math.Max(1, (int)(source.Width * scale)), Math.Max(1, (int)(source.Height * scale)));
            using var stream = new MemoryStream();
            small.Save(stream, System.Drawing.Imaging.ImageFormat.Png);
            return stream.ToArray();
        }

        public static Task<string?> GetDurationAsync(string path) => GetDurationAsync(path, CancellationToken.None);

        public static Task<string?> GetDurationAsync(string path, CancellationToken ct)
        {
            var key = CacheKey(path);
            return key == null ? Task.FromResult<string?>(null) : Durations.GetAsync(key, () => LoadDurationAsync(path), s => 2L * s.Length, ct);
        }

        // ---------------------------------------------------------------- thumbnail (Shell)
        [StructLayout(LayoutKind.Sequential)] private struct SIZE { public int cx, cy; }
        [Flags] private enum SIIGBF { ResizeToFit = 0, BiggerSizeOk = 1, ThumbnailOnly = 8 }

        [ComImport, Guid("bcc18b79-ba16-442f-80c4-8a59c30c463b"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
        private interface IShellItemImageFactory
        {
            [PreserveSig] int GetImage(SIZE size, SIIGBF flags, out IntPtr phbm);
        }

        [DllImport("shell32.dll", CharSet = CharSet.Unicode, PreserveSig = false)]
        private static extern void SHCreateItemFromParsingName(string pszPath, IntPtr pbc, [In] ref Guid riid, [MarshalAs(UnmanagedType.Interface)] out IShellItemImageFactory ppv);

        [DllImport("gdi32.dll")] private static extern bool DeleteObject(IntPtr hObject);

        private static Bitmap? LoadThumbnail(string path)
        {
            try
            {
                if (!File.Exists(path)) return null;
                var iid = new Guid("bcc18b79-ba16-442f-80c4-8a59c30c463b");
                SHCreateItemFromParsingName(path, IntPtr.Zero, ref iid, out var factory);
                try
                {
                    int hr = factory.GetImage(new SIZE { cx = 128, cy = 72 }, SIIGBF.ThumbnailOnly | SIIGBF.BiggerSizeOk, out var hbm);
                    if (hr != 0 || hbm == IntPtr.Zero) return null;
                    try
                    {
                        using var raw = Image.FromHbitmap(hbm);
                        return new Bitmap(raw);   // detach from the GDI handle
                    }
                    finally { DeleteObject(hbm); }
                }
                finally { Marshal.ReleaseComObject(factory); }
            }
            catch (Exception) { return null; }   // no thumbnail provider for this codec, COM failure, … -> placeholder
        }

        // ---------------------------------------------------------------- duration (ffmpeg)
        private static readonly Regex DurationRegex = new(@"Duration:\s*(\d+):(\d+):(\d+)", RegexOptions.Compiled);

        private static async Task<string?> LoadDurationAsync(string path)
        {
            await DurationGate.WaitAsync();
            try
            {
                var ffmpeg = WmvConversionService.FindFfmpeg();
                if (ffmpeg == null || !File.Exists(path)) return null;
                var psi = new ProcessStartInfo(ffmpeg) { RedirectStandardError = true, RedirectStandardOutput = true, UseShellExecute = false, CreateNoWindow = true };
                psi.ArgumentList.Add("-hide_banner"); psi.ArgumentList.Add("-i"); psi.ArgumentList.Add(path);
                using var proc = Process.Start(psi);
                if (proc == null) return null;
                var err = proc.StandardError.ReadToEndAsync();      // drain both pipes (a full pipe would block ffmpeg)
                var outp = proc.StandardOutput.ReadToEndAsync();
                if (!proc.WaitForExit(8000)) { try { proc.Kill(true); } catch (Exception) { } return null; }
                var text = await err; await outp;
                var m = DurationRegex.Match(text);
                if (!m.Success) return null;
                int h = int.Parse(m.Groups[1].Value), mi = int.Parse(m.Groups[2].Value), s = int.Parse(m.Groups[3].Value);
                return h > 0 ? $"{h}:{mi:00}:{s:00}" : $"{mi}:{s:00}";
            }
            catch (Exception) { return null; }
            finally { DurationGate.Release(); }
        }
    }
}
