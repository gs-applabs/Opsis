using System;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;

namespace MotionDesk.Services;

// Read-only media facts. No codec support claims and no new decoder or sampler.
internal sealed record GalleryVideoMetadata(int Width, int Height, double Fps, string Codec, long Bytes, DateTime ModifiedUtc)
{
    private static readonly WallpaperMetaCache<GalleryVideoMetadata> Cache = new(512, 512 * 1024, 16, 2);
    internal static bool IsSupported(string path) => Path.GetExtension(path).ToLowerInvariant() is ".mp4" or ".m4v" or ".webm" or ".ogv";
    internal static async Task<GalleryVideoMetadata?> ReadAsync(string path, CancellationToken ct)
    {
        if (!IsSupported(path)) return null;
        try
        {
            var file = new FileInfo(path);
            if (!file.Exists) return null;
            string key = $"{file.FullName}|{file.Length}|{file.LastWriteTimeUtc.Ticks}";
            return await Cache.GetAsync(key, () => ProbeAsync(file.FullName, file.Length, file.LastWriteTimeUtc), _ => 512, ct).ConfigureAwait(false);
        }
        catch (OperationCanceledException) { throw; }
        catch (Exception) { return null; }
    }
    private static async Task<GalleryVideoMetadata?> ProbeAsync(string path, long bytes, DateTime modified)
    {
        var ffmpeg = WmvConversionService.FindFfmpeg();
        string executable = "ffprobe";
        if (ffmpeg != null && Path.IsPathFullyQualified(ffmpeg))
        {
            var companion = Path.Combine(Path.GetDirectoryName(ffmpeg)!, "ffprobe.exe");
            if (File.Exists(companion)) executable = companion;
        }
        var psi = new ProcessStartInfo(executable) { UseShellExecute = false, CreateNoWindow = true, RedirectStandardOutput = true, RedirectStandardError = true };
        foreach (var arg in new[] { "-v", "error", "-select_streams", "v:0", "-show_entries", "stream=width,height,avg_frame_rate,codec_name", "-of", "json", path }) psi.ArgumentList.Add(arg);
        using var proc = Process.Start(psi);
        if (proc == null) return null;
        using var timeout = new CancellationTokenSource(TimeSpan.FromSeconds(8));
        var output = proc.StandardOutput.ReadToEndAsync(timeout.Token);
        var error = proc.StandardError.ReadToEndAsync(timeout.Token);
        try
        {
            await proc.WaitForExitAsync(timeout.Token).ConfigureAwait(false);
            var json = await output.ConfigureAwait(false);
            await error.ConfigureAwait(false);
            if (proc.ExitCode != 0 || json.Length > 16384) return null;
            var now = new FileInfo(path);
            if (!now.Exists || now.Length != bytes || now.LastWriteTimeUtc != modified) return null;
            return Parse(json, bytes, modified);
        }
        finally
        {
            if (!proc.HasExited) { try { proc.Kill(true); } catch (Exception) { } }
            try { await Task.WhenAll(output, error).ConfigureAwait(false); } catch (Exception) { }
        }
    }
    internal static GalleryVideoMetadata? Parse(string json, long bytes, DateTime modified)
    {
        try
        {
            using var doc = JsonDocument.Parse(json);
            if (!doc.RootElement.TryGetProperty("streams", out var streams) || streams.ValueKind != JsonValueKind.Array || streams.GetArrayLength() == 0) return null;
            var v = streams[0];
            int ReadInt(string key) => v.TryGetProperty(key, out var item) && item.TryGetInt32(out int n) && n > 0 && n <= 32768 ? n : 0;
            string ReadString(string key) => v.TryGetProperty(key, out var item) && item.ValueKind == JsonValueKind.String ? item.GetString() ?? "" : "";
            var ratio = ReadString("avg_frame_rate").Split('/');
            double fps = 0;
            if (ratio.Length == 2 && double.TryParse(ratio[0], NumberStyles.Float, CultureInfo.InvariantCulture, out double n) && double.TryParse(ratio[1], NumberStyles.Float, CultureInfo.InvariantCulture, out double d) && d > 0 && n > 0 && double.IsFinite(n / d) && n / d <= 1000) fps = n / d;
            var codec = ReadString("codec_name");
            return new(ReadInt("width"), ReadInt("height"), fps, codec.Length <= 40 ? codec : "", bytes, modified);
        }
        catch (Exception) { return null; }
    }
}
