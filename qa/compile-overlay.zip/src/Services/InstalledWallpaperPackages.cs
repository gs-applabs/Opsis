using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using MotionDesk.Widgets;

namespace MotionDesk.Services;

// Read-only projection of packages imported through WallpaperPackages. No HTML is loaded here.
internal static class InstalledWallpaperPackages
{
    internal sealed record Entry(string Id, string Index, string Title, string Detail);
    internal static IReadOnlyList<Entry> Discover()
    {
        var result = new List<Entry>();
        try
        {
            var root = Path.GetFullPath(WallpaperPackages.Root);
            if (!Directory.Exists(root) || Linked(root)) return result;
            foreach (var dir in Directory.EnumerateDirectories(root).Take(400))
            {
                try
                {
                    var name = Path.GetFileName(dir);
                    if (name.StartsWith(".", StringComparison.Ordinal) || Linked(dir)) continue;
                    var index = Path.Combine(dir, "index.html");
                    if (!File.Exists(index) || Linked(index) || new FileInfo(index).Length > 4L * 1024 * 1024) continue;
                    var manifestPath = Path.Combine(dir, WallpaperManifest.FileName);
                    var manifest = File.Exists(manifestPath) && !Linked(manifestPath) ? WallpaperManifest.LoadFor(index) : null;
                    string id = "package:" + Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(System.Text.Encoding.UTF8.GetBytes(name.ToUpperInvariant())));
                    result.Add(new(id, index, Bounded(manifest?.Name, name, 120), Bounded(manifest?.Description, "HTML / JavaScript", 240) + " · " + Bounded(name, "package", 80)));
                    if (result.Count >= 200) break;
                }
                catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or ArgumentException) { }
            }
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or ArgumentException) { }
        return result;
    }
    private static bool Linked(string path) => (File.GetAttributes(path) & FileAttributes.ReparsePoint) != 0;
    private static string Bounded(string? value, string fallback, int limit)
    {
        string text = string.IsNullOrWhiteSpace(value) ? fallback : value;
        return new string(text.Where(c => !char.IsControl(c)).Take(limit).ToArray());
    }
    internal static bool StillInstalled(Entry entry) => Discover().Any(x => x.Id == entry.Id && string.Equals(x.Index, entry.Index, StringComparison.OrdinalIgnoreCase));
}
