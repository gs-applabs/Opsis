using System;
using System.Collections.Generic;
using System.Linq;

namespace MotionDesk.Services;

/// <summary>Bounded, synchronous transaction for allowlisted current-user settings.
/// Null preserves absence. The owner validates keys and takes its original backup first.
/// No Windows restart, process launch, or background polling.</summary>
public static class ShellPreferenceTransaction
{
    public static bool Apply(IReadOnlyDictionary<string, int?> desired,
        Func<string, int?> read, Action<string, int?> write, Action beforeChange)
    {
        if (desired.Count > 64) throw new ArgumentOutOfRangeException(nameof(desired));
        var previous = desired.Keys.ToDictionary(k => k, read, StringComparer.Ordinal);
        var changes = desired.Where(p => previous[p.Key] != p.Value).ToArray();
        if (changes.Length == 0) return false;
        beforeChange();
        var attempted = new List<string>();
        try
        {
            foreach (var pair in changes)
            {
                attempted.Add(pair.Key);
                write(pair.Key, pair.Value);
                if (read(pair.Key) != pair.Value)
                    throw new InvalidOperationException("Preference readback failed: " + pair.Key);
            }
        }
        catch (Exception original)
        {
            var failures = new List<Exception> { original };
            foreach (var key in attempted.AsEnumerable().Reverse())
                try
                {
                    write(key, previous[key]);
                    if (read(key) != previous[key]) throw new InvalidOperationException("Rollback readback failed: " + key);
                }
                catch (Exception rollback) { failures.Add(rollback); }
            if (failures.Count > 1) throw new AggregateException("Preference update and rollback failed; restore from the original backup.", failures);
            throw;
        }
        return true;
    }
}
