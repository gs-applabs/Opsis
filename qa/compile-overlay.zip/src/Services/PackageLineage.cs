namespace MotionDesk.Services;

// IDs refer to already discovered local package entries, never to a user-provided path.
internal static class PackageLineage
{
    internal const int Limit = 256;
    internal static bool ValidId(string? id) => id != null && id.Length == 72 && id.StartsWith("package:", StringComparison.Ordinal) && id.AsSpan(8).ToString().All(c => c is >= '0' and <= '9' or >= 'A' and <= 'F');
    internal static bool Link(Dictionary<string,string> map,string newer,string older)
    {
        if (!ValidId(newer) || !ValidId(older) || newer == older || map.ContainsKey(newer) || map.Count >= Limit) return false;
        var seen = new HashSet<string>(StringComparer.Ordinal) { newer };
        var cursor = older;
        for (int i=0;i<=Limit;i++)
        {
            if (!ValidId(cursor) || !seen.Add(cursor)) return false;
            if (!map.TryGetValue(cursor,out var next)) { map.Add(newer,older);return true; }
            cursor=next;
        }
        return false;
    }
    internal static string? Previous(IReadOnlyDictionary<string,string>? map,string id)
        => ValidId(id) && map != null && map.TryGetValue(id,out var previous) && ValidId(previous) && previous != id ? previous : null;
}
