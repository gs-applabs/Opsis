using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.Loader;
using Microsoft.Win32;
using MotionDesk.UI;
using OpsisNewsCrawler.Plugin.Abstractions;

namespace MotionDesk.Services
{
    // Μηχανισμός plugin του Opsis - Desktop Customization.
    //
    // Ένα plugin είναι ένας φάκελος μέσα σε έναν από τους φακέλους "plugins" με ένα *Plugin.dll που περιέχει μια κλάση
    // που υλοποιεί IOpsisNewsCrawlerPlugin (το contract βρίσκεται στο libs\OpsisNewsCrawler.Plugin.Abstractions.dll).
    // Φάκελοι αναζήτησης (με αυτή τη σειρά):
    //   1. <φάκελος Opsis>\plugins\*\
    //   2. %AppData%\Opsis\plugins\*\
    //   3. κάθε διαδρομή στο HKCU\Software\Opsis\PluginPaths (την γράφει ο installer του plugin)
    // Κάθε plugin φορτώνεται σε δικό του AssemblyLoadContext ώστε οι εξαρτήσεις του να μη μπλέκονται με του Opsis·
    // μόνο το contract (και το framework) μοιράζονται. Ένα plugin που αποτυγχάνει ΠΟΤΕ δεν ρίχνει το Opsis —
    // το σφάλμα γράφεται στο plugins.log και το plugin παραλείπεται.
    public sealed class PluginHost
    {
        public static PluginHost Instance { get; } = new();

        private sealed class Loaded
        {
            public IOpsisNewsCrawlerPlugin Plugin = null!;
            public string Folder = "";
            public volatile bool Started;
            public volatile bool Revoked;
            public PluginAboutInfo? CachedAbout;
            public PluginDependencyPolicy.Requirement[] Dependencies = [];
            public string? DependencyBlock;
            public bool NavigationAttached;
            public bool Sdk2;
        }

        private readonly List<Loaded> _plugins = new();
        // Plugins are started, approved (LoadFolder), removed and read from several threads and from timers: every read works on a SNAPSHOT taken under this lock, and every change happens
        // under it. Enumerating the live list while another thread changed it threw "Collection was modified" in the tray menu.
        private readonly object _gate = new();
        /// <summary>Runs a call into plugin code again (up to 3 times, a few ms apart) when it fails with "Collection was modified" - a plugin that is being started or stopped on another thread; any other error is passed on.</summary>
        internal static T Retry<T>(Func<T> call)
        {
            for (int attempt = 1; ; attempt++)
            {
                try { return call(); }
                catch (InvalidOperationException ex) when (attempt < 3 && ex.Message.Contains("modified", StringComparison.OrdinalIgnoreCase))
                {
                    Log($"retry {attempt}: {ex.Message}");
                    System.Threading.Thread.Sleep(15 * attempt);
                }
            }
        }

        private Loaded[] Snap() { lock (_gate) return _plugins.ToArray(); }
        private void AddLoaded(Loaded l)
        {
            lock (_gate) _plugins.Add(l);
            UiResourceAudit.Mark("plugin-loaded", Path.GetFileName(l.Folder));
        }
        private void RemoveLoaded(Loaded l) { lock (_gate) _plugins.Remove(l); }
        private bool _started;

        /// <summary>Asked (on the UI thread) before an UNTRUSTED plugin folder is loaded for the first time; returning false skips it. Default: deny.</summary>

        private PluginTrust.Store? _trustStore;

        public IReadOnlyList<IOpsisNewsCrawlerPlugin> Plugins => Snap().Select(p => p.Plugin).ToList();

        // Ζητήθηκε ρητά: ξεχωριστό κουμπί ενεργοποίησης/απενεργοποίησης ΓΙΑ ΚΑΘΕ plugin (π.χ. το
        // News Crawler), όχι μόνο ο γενικός διακόπτης "Φόρτωση plugins" (AppSettings.PluginsEnabled)
        // που τα αφορά όλα μαζί. Ένα απενεργοποιημένο plugin παραμένει φορτωμένο (ώστε να φαίνεται
        // στη σελίδα About με το δικό του κουμπί) αλλά ΔΕΝ τρέχει (Start/Stop) και δεν συνεισφέρει
        // στοιχεία πλοήγησης/tray όσο είναι απενεργοποιημένο.
        public bool IsPluginEnabled(string id) => !AppSettings.Load().DisabledPluginIds.Contains(id, StringComparer.OrdinalIgnoreCase) &&
            !Snap().Any(p => p.Revoked && string.Equals(p.Plugin.Id, id, StringComparison.OrdinalIgnoreCase));

        /// <summary>Revoke a SHA-bound approval and stop plugin callbacks. The DLL stays resident until restart.</summary>
        public bool RevokePluginTrust(string id)
        {
            var found = Snap().FirstOrDefault(p => string.Equals(p.Plugin.Id, id, StringComparison.OrdinalIgnoreCase));
            if (found == null) return false;
            // Mark every resident entry in the same approved package before stopping callbacks.
            var package = Snap().Where(p => string.Equals(p.Folder, found.Folder, StringComparison.OrdinalIgnoreCase)).ToArray();
            foreach (var p in package) p.Revoked = true;
            StopWithDependents(package, "dependency approval revoked");
            try
            {
                TrustStore.Revoke(Path.GetFileName(found.Folder));
                var settings = AppSettings.Load();
                foreach (var p in package)
                    if (!settings.DisabledPluginIds.Contains(p.Plugin.Id)) settings.DisabledPluginIds.Add(p.Plugin.Id);
                settings.Save();
            }
            finally { Changed?.Invoke(); }
            return true;
        }

        public string PluginPermissions(string id)
        {
            var found = Snap().FirstOrDefault(p => string.Equals(p.Plugin.Id, id, StringComparison.OrdinalIgnoreCase));
            return found == null ? "Unknown" : PluginCapabilityManifest.Summary(found.Folder) +
                (found.DependencyBlock == null ? "" : " · Blocked: " + found.DependencyBlock);
        }

        private bool _compatibilitySuspended;

        private static bool MaintenancePending()
        {
            try
            {
                var marker = Path.Combine(AppPaths.AppDataFolder, "plugin-maintenance", "pending.json");
                // Treat an unreadable or linked marker as a hold rather than loading uncertain packages.
                _ = File.GetAttributes(marker);
                return true;
            }
            catch (FileNotFoundException) { return false; }
            catch (DirectoryNotFoundException) { return false; }
            catch (Exception) { return true; }
        }

        public void SetPluginEnabled(string id, bool enabled)
        {
            if (enabled && (_compatibilitySuspended || WindowsUpdateGuard.RequiresReview || MaintenancePending()))
                throw new InvalidOperationException("Windows compatibility review and Opsis restart required before enabling plugins.");
            if (enabled && Snap().Any(p => p.Revoked && string.Equals(p.Plugin.Id, id, StringComparison.OrdinalIgnoreCase)))
                throw new InvalidOperationException("Plugin approval was revoked. Restart Opsis and approve the package again.");
            var p = Snap().FirstOrDefault(x => string.Equals(x.Plugin.Id, id, StringComparison.OrdinalIgnoreCase));
            if (enabled && p != null && DependencyReason(p) is { } reason)
            {
                p.DependencyBlock = reason;
                throw new InvalidOperationException(reason);
            }
            var settings = AppSettings.Load();
            if (enabled) { settings.DisabledPluginIds.RemoveWhere(x => string.Equals(x, id, StringComparison.OrdinalIgnoreCase)); PluginFailureQuarantine.Clear(id); }
            else if (!settings.DisabledPluginIds.Contains(id, StringComparer.OrdinalIgnoreCase)) settings.DisabledPluginIds.Add(id);
            settings.Save();
            if (p != null)
            {
                if (enabled) { p.DependencyBlock = null; ActivateReady([p]); }
                else StopWithDependents([p], "dependency disabled");
            }
            Changed?.Invoke();
        }

        /// <summary>Only Opsis-managed per-user packages may be archived from the host.</summary>
        public bool CanUninstallPlugin(string id) => Snap().FirstOrDefault(x => string.Equals(x.Plugin.Id, id, StringComparison.OrdinalIgnoreCase)) is { } entry &&
            PluginRemovalPolicy.IsManagedPackage(AppPaths.AppDataFolder, entry.Folder);

        public bool UninstallPlugin(string id)
        {
            var p = Snap().FirstOrDefault(x => string.Equals(x.Plugin.Id, id, StringComparison.OrdinalIgnoreCase));
            if (p == null) return false;
            if (MaintenancePending()) throw new InvalidOperationException("Complete plugin maintenance before removing a package.");
            if (!CanUninstallPlugin(id)) throw new InvalidOperationException("Use the original installer to remove external or bundled plugins.");
            // Persist an exact-content removal receipt before changing host state.
            PluginRemovalPolicy.Authorize(AppPaths.AppDataFolder, p.Folder);
            var settings = AppSettings.Load();
            if (!settings.PendingPluginRemovals.Contains(p.Folder, StringComparer.OrdinalIgnoreCase))
                settings.PendingPluginRemovals.Add(p.Folder);
            settings.Save();
            var package = Snap().Where(x => string.Equals(x.Folder, p.Folder, StringComparison.OrdinalIgnoreCase)).ToArray();
            foreach (var entry in package) entry.Revoked = true;
            StopWithDependents(package, "dependency uninstalled");
            foreach (var entry in package)
            {
                RemoveLoaded(entry);
                settings.DisabledPluginIds.RemoveWhere(x => string.Equals(x, entry.Plugin.Id, StringComparison.OrdinalIgnoreCase));
            }

            // The pending marker has already been saved before stopping or moving the package.
            settings.Save();
            bool archived = false;
            try { archived = PluginRemovalPolicy.TryArchive(AppPaths.AppDataFolder, p.Folder); }
            catch (Exception ex) { Log($"Plugin archive pending: {ex.Message}"); }
            if (archived)
            {
                settings.PendingPluginRemovals.RemoveAll(x => string.Equals(x, p.Folder, StringComparison.OrdinalIgnoreCase));
                settings.Save();
            }
            Changed?.Invoke();
            return archived;
        }

        /// <summary>Ένα plugin ζήτησε να εμφανιστεί μία από τις σελίδες του (π.χ. δεξί κλικ στη μπάρα ειδήσεων).</summary>
        public event Action<string>? NavigationRequested;

        /// <summary>Η λίστα στοιχείων του tray menu ή του sidebar μπορεί να έχει αλλάξει.</summary>
        public event Action? Changed;

        /// <summary>Φορτώνει και ξεκινά όλα τα plugin. Πρέπει να κληθεί στο UI thread.</summary>
        public void StartAll()
        {
            if (_started || _compatibilitySuspended || WindowsUpdateGuard.RequiresReview) return;
            if (MaintenancePending()) { Log("Plugin startup held: finish offline package maintenance (recover) and restart Opsis."); return; }
            _started = true;
            SweepPendingRemovals();
            if (!AppSettings.Load().PluginsEnabled) return;

            foreach (var (folder, trustedRoot) in EnumerateCandidateFolders())
            {
                try
                {
                    ConsiderFolder(folder, trustedRoot);
                }
                catch (Exception ex) { Log($"Failed to load '{folder}': {ex}"); }
            }

            ActivateReady(Snap());

            ThemeManager.Changed += () => { foreach (var p in Snap().Where(p => p.Started && !p.Revoked)) PushTheme(p.Plugin); };
            // Η γλώσσα του Opsis ισχύει και για τα plugin: αλλάζει ΚΑΙ στα δύο ταυτόχρονα.
            LocalizationManager.Changed += () => { foreach (var p in Snap().Where(p => p.Started && !p.Revoked)) PushLanguage(p.Plugin); };
            HardwareProfileService.ProfileChanged += _ => { foreach (var p in Snap().Where(p => p.Started && !p.Revoked)) PushHardwareProfile(p.Plugin); };
            Changed?.Invoke();
        }

        // In-process DLLs cannot be unloaded safely. Prevent future host starts and
        // stop active plugins; full isolation is achieved on the next Opsis restart.
        public void SuspendForCompatibility()
        {
            if (_compatibilitySuspended) return;
            _compatibilitySuspended = true;
            StopWithDependents(Snap(), "compatibility hold");
            Changed?.Invoke();
        }

        public void StopAll()
        {
            StopWithDependents(Snap(), "host shutdown");
        }

        // test hooks (InternalsVisibleTo Opsis.Tests): a host instance with plugins added by hand
        internal void AddForTest(IOpsisNewsCrawlerPlugin plugin, bool started) => AddLoaded(new Loaded { Plugin = plugin, Started = started });
        internal void StartAllForTest() { foreach (var p in Snap()) { p.Plugin.Start(); p.Started = true; } }

        /// <summary>The desktop widget a started plugin offers to REPLACE a built-in one (for example "calendar"), or null. A plugin that fails is logged and skipped.</summary>
        public PluginWidget? FindWidgetReplacing(string builtInId)
        {
            foreach (var p in Snap().Where(p => p.Started && !p.Revoked).ToList())
            {
                if (p.Plugin is not IPluginWidgetProvider provider) continue;
                try
                {
                    var widget = provider.GetWidgets().FirstOrDefault(w => string.Equals(w.ReplacesBuiltIn, builtInId, StringComparison.OrdinalIgnoreCase));
                    if (widget != null) { Log($"Plugin '{p.Plugin.Name}': widget '{widget.Key}' replaces built-in '{builtInId}'"); return widget; }
                }
                catch (Exception ex)
                {
                    Log($"Plugin '{p.Plugin.Name}' widgets failed: {ex.Message}");
                    if (PluginFailureQuarantine.RecordFailure(p.Plugin.Id))
                    {
                        StopWithDependents([p], "dependency quarantined");
                        Log($"Plugin '{p.Plugin.Name}' quarantined after three failures; other plugins remain active.");
                    }
                }
            }
            return null;
        }

        /// <summary>Σελίδες των plugin για το sidebar, ταξινομημένες κατά Order. Ένα απενεργοποιημένο plugin δεν συνεισφέρει.</summary>
        public IReadOnlyList<PluginNavigationItem> GetNavigationItems()
        {
            var items = new List<PluginNavigationItem>();
            foreach (var p in Snap().Where(p => p.Started && !p.Revoked))
            {
                try { items.AddRange(Retry(() => p.Plugin.GetNavigationItems().ToList())); }
                catch (Exception ex) { Log($"Plugin '{p.Plugin.Name}' navigation failed: {ex.Message}"); }
            }
            return items.OrderBy(i => i.Order).ToList();
        }

        /// <summary>Tray items per plugin (plugin display name -> its items) so the tray menu can group them by plugin.</summary>
        /// <summary>The "welcome guide" and "Opsis family" entries belong to Opsis itself (one of each in the tray, wherever the plugins are hosted); a plugin copy would show them several times.</summary>
        internal static bool IsHostOwnedEntry(PluginMenuItem item)
        {
            if (item.IsSeparator) return false;
            var k = (item.Key ?? "").Trim().ToLowerInvariant();
            return k is "welcome" or "suite" or "family" || k.EndsWith(".welcome") || k.EndsWith(".suite") || k.EndsWith(".family");
        }

        internal static List<PluginMenuItem> WithoutHostOwned(IEnumerable<PluginMenuItem> items)
        {
            var list = items.Where(i => !IsHostOwnedEntry(i)).ToList();
            while (list.Count > 0 && list[^1].IsSeparator) list.RemoveAt(list.Count - 1);          // no dangling separators
            while (list.Count > 0 && list[0].IsSeparator) list.RemoveAt(0);
            return list;
        }

        public IReadOnlyList<(string PluginName, IReadOnlyList<PluginMenuItem> Items)> GetTrayMenuGroups()
        {
            var groups = new List<(string, IReadOnlyList<PluginMenuItem>)>();
            foreach (var p in Snap().Where(p => p.Started && !p.Revoked))
            {
                try
                {
                    var items = WithoutHostOwned(Retry(() => p.Plugin.GetTrayMenuItems().ToList()));
                    if (items.Count > 0) groups.Add((p.Plugin.Name, items));
                }
                catch (Exception ex) { Log($"Plugin '{p.Plugin.Name}' tray items failed: {ex.Message}"); }
            }
            return groups;
        }

        public IReadOnlyList<PluginMenuItem> GetTrayMenuItems()
        {
            var items = new List<PluginMenuItem>();
            foreach (var p in Snap().Where(p => p.Started && !p.Revoked))
            {
                try { items.AddRange(WithoutHostOwned(Retry(() => p.Plugin.GetTrayMenuItems().ToList()))); }
                catch (Exception ex) { Log($"Plugin '{p.Plugin.Name}' tray items failed: {ex.Message}"); }
            }
            return items;
        }

        /// <summary>Πληροφορίες "Σχετικά" όλων των plugin (ιδιότητες, βοήθεια, οδηγίες, ιστορικό, άδεια) για τη σελίδα About,
        /// μαζί με το Id τους (ώστε η σελίδα About να μπορεί να βάλει το σωστό κουμπί ενεργό/ανενεργό δίπλα στο καθένα).
        /// Τα δείχνει ΟΛΑ, ακόμη και τα απενεργοποιημένα — αλλιώς δεν θα υπήρχε πώς να τα ξανα-ενεργοποιήσεις.</summary>
        public IReadOnlyList<(string Id, PluginAboutInfo Info)> GetAboutInfos()
        {
            var infos = new List<(string, PluginAboutInfo)>();
            foreach (var p in Snap())
            {
                try
                {
                    if (!p.Revoked) p.CachedAbout = Retry(() => p.Plugin.GetAboutInfo());
                    if (p.CachedAbout is { } about) infos.Add((p.Plugin.Id, about));
                }
                catch (Exception ex) { Log($"Plugin '{p.Plugin.Name}' about info failed: {ex.Message}"); }
            }
            return infos;
        }

        public static string TitleOf(PluginNavigationItem item) =>
            LocalizationManager.CurrentLanguage == "el" ? item.TitleEl : item.TitleEn;

        private void PushLanguage(IOpsisNewsCrawlerPlugin plugin)
        {
            try { plugin.SetLanguage(LocalizationManager.CurrentLanguage); }
            catch (Exception ex) { Log($"Plugin '{plugin.Name}' SetLanguage failed: {ex.Message}"); }
            PushHostSettings(plugin);
        }

        /// <summary>Contract 1.0.0.0: the settings that belong to Opsis (language, theme, hardware tier, UI scale, "Opsis manages the updates of this plugin"), for a plugin that implements IPluginHostSettingsAware.</summary>
        internal static PluginHostSettings BuildHostSettings(IOpsisNewsCrawlerPlugin plugin)
        {
            bool dark = true; try { dark = ThemeManager.Current.IsDark; } catch (Exception) { }
            int scale = 100; try { scale = AppSettings.Load().UiScalePercent; } catch (Exception) { }
            return new PluginHostSettings(LocalizationManager.CurrentLanguage, dark, HardwareProfileService.CurrentTier.ToString(), scale, plugin is IPluginUpdateSource);
        }

        private void PushHostSettings(IOpsisNewsCrawlerPlugin plugin)
        {
            if (plugin is not IPluginHostSettingsAware aware) return;
            try { aware.SetHostSettings(BuildHostSettings(plugin)); }
            catch (Exception ex) { Log($"Plugin '{plugin.Name}' SetHostSettings failed: {ex.Message}"); }
        }

        // Handoff Φάση 6 (ελάχιστο): προαιρετική ικανότητα — καλείται ΜΟΝΟ αν το plugin υλοποιεί το
        // νέο, προαιρετικό IPluginProfileAware (δεν αγγίζει καθόλου το υποχρεωτικό
        // IOpsisNewsCrawlerPlugin contract, άρα κανένα υπάρχον plugin δεν σπάει).
        private void PushHardwareProfile(IOpsisNewsCrawlerPlugin plugin)
        {
            if (plugin is not OpsisNewsCrawler.Plugin.Abstractions.IPluginProfileAware aware) { PushHostSettings(plugin); return; }
            try { aware.SetHardwareProfile(HardwareProfileService.CurrentTier.ToString()); }
            catch (Exception ex) { Log($"Plugin '{plugin.Name}' SetHardwareProfile failed: {ex.Message}"); }
        }

        private void PushTheme(IOpsisNewsCrawlerPlugin plugin)
        {
            try
            {
                var t = ThemeManager.Current;
                var opacity = Math.Clamp(AppSettings.Load().WindowOpacity, 0.3, 1.0);
                plugin.SetTheme(t.IsDark, t.Background.ToArgb(), t.Surface.ToArgb(), t.Border.ToArgb(),
                    t.TextPrimary.ToArgb(), t.TextMuted.ToArgb(), t.AccentCyan.ToArgb(), opacity);
            }
            catch (Exception ex) { Log($"Plugin '{plugin.Name}' SetTheme failed: {ex.Message}"); }
        }

        // Archive only exact-content authorized managed packages before discovery.
        // Legacy unverified or changed pending entries stay held; never recursively delete.
        private static void SweepPendingRemovals()
        {
            var settings = AppSettings.Load();
            if (settings.PendingPluginRemovals.Count == 0) return;
            var remaining = new List<string>();
            foreach (var folder in settings.PendingPluginRemovals)
            {
                try
                {
                    try { _ = File.GetAttributes(folder); }
                    catch (FileNotFoundException) { continue; }
                    catch (DirectoryNotFoundException) { continue; }
                    if (PluginRemovalPolicy.TryArchive(AppPaths.AppDataFolder, folder)) continue;
                    Log($"Pending removal held: '{folder}' is external, unverified or changed. No files removed.");
                    remaining.Add(folder);
                }
                catch (Exception ex) { Log($"Could not archive pending plugin folder '{folder}': {ex.Message}"); remaining.Add(folder); }
            }
            settings.PendingPluginRemovals = remaining;
            settings.Save();
        }

        // ---- discovery & loading ---------------------------------------------------------------

        // A folder of an untrusted root (user-writable) is loaded only after the user approved its exact content (see PluginTrust).
        // Start-up NEVER waits for that answer (a modal box at login, maybe hidden behind other windows, used to block the tray and left the plugin's page missing for good):
        // an unapproved folder goes to PendingApprovals and is asked about right after start-up (ResolvePending) or from the tray menu.
        private readonly List<PluginTrustRequest> _pending = new();
        internal PluginTrust.Store? TrustStoreOverride;          // tests
        internal Action<string>? FolderLoader;                   // tests
        private PluginTrust.Store TrustStore => TrustStoreOverride ?? (_trustStore ??= new PluginTrust.Store(Path.Combine(AppPaths.AppDataFolder, "plugin-trust.json")));

        /// <summary>Plugin folders found but not approved yet (user-writable location, content hash not in plugin-trust.json).</summary>
        public IReadOnlyList<PluginTrustRequest> PendingApprovals { get { lock (_pending) return _pending.ToList(); } }

        /// <summary>Loads a folder if its root is trusted or its exact content is approved; otherwise remembers it as pending. Returns true when it was loaded.</summary>
        internal bool ConsiderFolder(string folder, bool trustedRoot)
        {
            if (MaintenancePending() || AppSettings.Load().PendingPluginRemovals.Contains(folder, StringComparer.OrdinalIgnoreCase)) return false;
            PluginCapabilityManifest.Declaration declaration;
            try { declaration = PluginCapabilityManifest.Inspect(folder); }
            catch (Exception ex) { Log($"Plugin '{folder}' skipped: invalid declaration: {ex.Message}"); return false; }
            if (Snap().Any(p => p.Revoked && string.Equals(p.Folder, folder, StringComparison.OrdinalIgnoreCase))) return false;
            if (!trustedRoot || declaration.RequiresExplicitApproval || TrustStore.IsRevoked(Path.GetFileName(folder)))
            {
                string name = Path.GetFileName(folder), hash;
                try { hash = PluginTrust.ApprovalDigest(folder, declaration.RequiresExplicitApproval); }
                catch (Exception ex) { Log($"Plugin '{folder}' skipped: trust check failed: {ex.Message}"); return false; }
                if (!TrustStore.IsApproved(name, hash))
                {
                    var (publisher, signature) = PluginPublisherInfo.Inspect(folder);
                    lock (_pending) { _pending.RemoveAll(p => string.Equals(p.Folder, folder, StringComparison.OrdinalIgnoreCase)); _pending.Add(new PluginTrustRequest(name, folder, hash, publisher, signature, declaration.Summary)); }
                    Log($"Plugin '{name}' in '{folder}' is waiting for approval (sha256 {hash}); it is not loaded until the user approves it.");
                    return false;
                }
            }
            if (MaintenancePending() || _compatibilitySuspended || WindowsUpdateGuard.RequiresReview) return false;
            (FolderLoader ?? LoadFolder)(folder);
            return true;
        }

        /// <summary>Asks about every pending plugin (on the UI thread, after start-up); the approved ones are loaded and started at once. Returns how many were approved.</summary>
        public int ResolvePending(Func<PluginTrustRequest, bool> ask)
        {
            if (_compatibilitySuspended || WindowsUpdateGuard.RequiresReview || MaintenancePending()) return 0;
            int approved = 0;
            foreach (var req in PendingApprovals)
            {
                bool yes;
                try { yes = ask(req); } catch (Exception ex) { Log($"Plugin '{req.Name}' approval prompt failed: {ex.Message}"); yes = false; }
                if (!yes) { Log($"Plugin '{req.Name}' not approved by the user (sha256 {req.Sha256})."); continue; }
                if (_compatibilitySuspended || WindowsUpdateGuard.RequiresReview) break;
                try
                {
                    if (AppSettings.Load().PendingPluginRemovals.Contains(req.Folder, StringComparer.OrdinalIgnoreCase)) continue;
                    if (Snap().Any(p => p.Revoked && string.Equals(p.Folder, req.Folder, StringComparison.OrdinalIgnoreCase))) continue;
                    var declaration = PluginCapabilityManifest.Inspect(req.Folder);
                    string currentHash = PluginTrust.ApprovalDigest(req.Folder, declaration.RequiresExplicitApproval);
                    if (!string.Equals(currentHash, req.Sha256, StringComparison.OrdinalIgnoreCase))
                    {
                        lock (_pending)
                        {
                            _pending.RemoveAll(p => string.Equals(p.Folder, req.Folder, StringComparison.OrdinalIgnoreCase));
                            var (publisher, signature) = PluginPublisherInfo.Inspect(req.Folder);
                            _pending.Add(req with { Sha256 = currentHash, Publisher = publisher, SignatureStatus = signature, Capabilities = declaration.Summary });
                        }
                        Log($"Plugin '{req.Name}' changed before approval completed; it requires a new approval.");
                        continue;
                    }
                    if (_compatibilitySuspended || WindowsUpdateGuard.RequiresReview || MaintenancePending()) break;
                    TrustStore.Approve(req.Name, req.Sha256);
                    Log($"Plugin '{req.Name}' approved by the user (sha256 {req.Sha256}).");
                    var before = Snap().ToHashSet();
                    (FolderLoader ?? LoadFolder)(req.Folder);
                    ActivateReady(Snap().Where(p => !before.Contains(p)));
                    lock (_pending) _pending.RemoveAll(p => string.Equals(p.Folder, req.Folder, StringComparison.OrdinalIgnoreCase));
                    approved++;
                }
                catch (Exception ex) { Log($"Plugin '{req.Name}' failed to load after approval: {ex}"); }
            }
            if (approved > 0) Changed?.Invoke();
            return approved;
        }

        private PluginDependencyPolicy.Node[] DependencySnapshot() => Snap().Select(p =>
            new PluginDependencyPolicy.Node(p.Plugin.Id, p.Plugin.Version, p.Started && !p.Revoked, p.Dependencies)).ToArray();

        private string? DependencyReason(Loaded p) => p.Dependencies.Length == 0 ? null : PluginDependencyPolicy.BlockingReason(
            new(p.Plugin.Id, p.Plugin.Version, p.Started && !p.Revoked, p.Dependencies), DependencySnapshot());

        // Called on the existing lifecycle/UI path. Retry only newly eligible or dependency-blocked entries,
        // never automatically retry a failed Start or clear user settings/quarantine.
        private void ActivateReady(IEnumerable<Loaded> candidates)
        {
            var settings = AppSettings.Load();
            if (!settings.PluginsEnabled || _compatibilitySuspended || WindowsUpdateGuard.RequiresReview) return;
            var pending = candidates.Concat(Snap().Where(p => p.DependencyBlock != null)).Distinct()
                .Where(p => !p.Started && !p.Revoked && !settings.DisabledPluginIds.Contains(p.Plugin.Id, StringComparer.OrdinalIgnoreCase)
                    && !PluginFailureQuarantine.IsQuarantined(p.Plugin.Id)).ToList();
            bool progress;
            do
            {
                progress = false;
                foreach (var p in pending.ToArray())
                {
                    p.DependencyBlock = DependencyReason(p);
                    if (p.DependencyBlock != null) continue;
                    pending.Remove(p);
                    Activate(p);
                    progress = true;
                }
            } while (progress && pending.Count > 0);
            foreach (var p in pending) Log($"Plugin '{p.Plugin.Id}' blocked: {p.DependencyBlock}");
        }

        private void StopWithDependents(IEnumerable<Loaded> roots, string reason)
        {
            var snapshot = Snap();
            var rootIds = roots.Select(p => p.Plugin.Id).ToHashSet(StringComparer.OrdinalIgnoreCase);
            // Revoked entries can still be running until their Stop callback completes.
            var nodes = snapshot.Select(p => new PluginDependencyPolicy.Node(p.Plugin.Id, p.Plugin.Version, p.Started, p.Dependencies)).ToArray();
            foreach (var id in PluginDependencyPolicy.StopOrder(rootIds, nodes))
            {
                var p = snapshot.FirstOrDefault(x => string.Equals(x.Plugin.Id, id, StringComparison.OrdinalIgnoreCase));
                if (p == null || !p.Started) continue;
                if (!rootIds.Contains(id)) p.DependencyBlock = reason;
                p.Started = false;
                try { p.Plugin.Stop(); }
                catch (Exception ex) { Log($"Plugin '{p.Plugin.Name}' failed to stop: {ex.Message}"); }
            }
        }

        private void Activate(Loaded p)
        {
            if (p.Started || p.Revoked) return;
            try
            {
                if (!p.NavigationAttached)
                {
                    p.Plugin.NavigationRequested += key => { if (p.Started && !p.Revoked) NavigationRequested?.Invoke(key); };
                    p.NavigationAttached = true;
                }
                PushLanguage(p.Plugin); PushTheme(p.Plugin); PushHardwareProfile(p.Plugin);
                p.Plugin.Start(); p.Started = true;
            }
            catch (Exception ex)
            {
                Log($"Plugin '{p.Plugin.Name}' failed to start: {ex}");
                if (PluginFailureQuarantine.RecordFailure(p.Plugin.Id))
                    Log($"Plugin '{p.Plugin.Name}' quarantined after three failures.");
            }
        }

        internal static IEnumerable<(string Folder, bool TrustedRoot)> EnumerateCandidateFolders()
        {
            // The install directory is trusted only when it is itself protected (Program Files); a per-user install or a dev build is not.
            string installPlugins = Path.Combine(AppContext.BaseDirectory, "plugins");
            bool installTrusted = PluginTrust.IsUnderProtectedInstall(AppContext.BaseDirectory);
            var locations = new List<(string Path, bool Trusted, bool MayBePlugin)>
            {
                (installPlugins, installTrusted, false),
                (Path.Combine(AppPaths.AppDataFolder, "plugins"), false, false),
                (Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "Opsis", "plugins"), false, false)
            };
            try
            {
                using var key = Registry.CurrentUser.OpenSubKey(@"Software\Opsis\PluginPaths");
                if (key != null)
                    foreach (var name in key.GetValueNames())
                        if (key.GetValue(name) is string path && path.Length > 0) locations.Add((path, false, true));
            }
            catch (Exception) { }

            var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (var (location, trusted, direct) in locations)
            {
                string root;
                try
                {
                    if (!Path.IsPathFullyQualified(location) || location.StartsWith(@"\\", StringComparison.Ordinal)) continue;
                    root = Path.TrimEndingDirectorySeparator(Path.GetFullPath(location));
                }
                catch (Exception ex) when (ex is ArgumentException or IOException or NotSupportedException) { continue; }
                if (!Directory.Exists(root)) continue;
                string[] folders;
                try
                {
                    folders = direct && Directory.EnumerateFiles(root, "*Plugin.dll").Any()
                        ? [root] : Directory.GetDirectories(root);
                }
                catch (Exception ex) when (ex is IOException or UnauthorizedAccessException) { continue; }
                foreach (var folder in folders)
                    if (seen.Add(folder) && !IsReplacedByBuiltIn(folder))
                        yield return (folder, trusted && PackagePaths.IsExistingUnlinkedPath(AppContext.BaseDirectory, folder));
            }
        }

        /// <summary>
        /// Plugins whose features were moved INTO Opsis (2.6.0): Opsis Appearance is now the built-in "Windows appearance" page, so an installed
        /// copy of the old plugin must not load (two engines would fight over the same Windows settings). Never asks for approval, never deletes anything.
        /// </summary>
        internal static readonly string[] ReplacedPluginDlls = { "OpsisAppearancePlugin.dll" };

        internal static bool IsReplacedByBuiltIn(string folder)
        {
            try { return ReplacedPluginDlls.Any(d => File.Exists(Path.Combine(folder, d))); }
            catch (Exception) { return false; }
        }

        internal void LoadFolder(string folder)
        {
            if (IsReplacedByBuiltIn(folder)) { Log($"Plugin folder '{Path.GetFileName(folder)}' skipped: its features are built into Opsis 2.6.0"); return; }
            var declaration = PluginCapabilityManifest.Inspect(folder);
            foreach (var dll in Directory.EnumerateFiles(folder, "*Plugin.dll"))
            {
                if (!PackagePaths.IsExistingUnlinkedPath(folder, dll)) continue;
                // #97: only known 1.0.0.0 plugin entrypoints are gated.
                // Unknown third-party plugins retain the established ABI policy.
                var fileName = Path.GetFileName(dll);
                if (fileName.Equals("OpsisNewsCrawler.OpsisPlugin.dll", StringComparison.OrdinalIgnoreCase) ||
                    fileName.Equals("Chronikologio.OpsisPlugin.dll", StringComparison.OrdinalIgnoreCase))
                {
                    var identity = AssemblyName.GetAssemblyName(dll);
                    if (identity.Version != new Version(1, 0, 0, 0))
                    {
                        Log($"Plugin '{fileName}' skipped: ABI {identity.Version} (2.8.0.2510 requires 1.0.0.0). Update this plugin before enabling it.");
                        continue;
                    }
                }
                var context = new PluginLoadContext(dll);
                var assembly = context.LoadFromAssemblyPath(dll);
                foreach (var type in assembly.GetTypes())
                {
                    if (type.IsAbstract || !typeof(IOpsisNewsCrawlerPlugin).IsAssignableFrom(type)) continue;
                    if (Activator.CreateInstance(type) is not IOpsisNewsCrawlerPlugin plugin) continue;

                    // Το ίδιο plugin μπορεί να βρεθεί σε δύο φακέλους (π.χ. η παλιά έκδοση που ήρθε
                    // bundled με τον installer του Opsis στο <app>\plugins, ΚΑΙ μια νεότερη που έγραψε
                    // ο δικός του αυτόματος updater στο %AppData%\Opsis\plugins). Ζητήθηκε ρητά να μην
                    // μένει "κολλημένη" η παλιά — κρατάμε πάντα τη ΝΕΟΤΕΡΗ έκδοση, όχι αυτή που απλά
                    // βρέθηκε πρώτη (ο παλιός κώδικας έκανε ακριβώς αυτό το λάθος: "first wins").
                    var existing = Snap().FirstOrDefault(p => string.Equals(p.Plugin.Id, plugin.Id, StringComparison.OrdinalIgnoreCase));
                    if (existing != null)
                    {
                        if (!IsNewerVersion(plugin.Version, existing.Plugin.Version)) continue;
                        if (existing.Revoked) continue;
                        if (existing.Started)
                        {
                            // Do not swap a live provider under its consumers or replace resident SDK2 state.
                            if (declaration.RequiresExplicitApproval || existing.Sdk2 ||
                                Snap().Any(p => p.Started && p.Dependencies.Any(d => string.Equals(d.Id, existing.Plugin.Id, StringComparison.OrdinalIgnoreCase))))
                            { Log($"Plugin '{existing.Plugin.Id}' upgrade requires restart."); continue; }
                            existing.Started = false;
                            try { existing.Plugin.Stop(); }
                            catch (Exception ex) { Log($"Plugin '{existing.Plugin.Name}' could not stop during replacement: {ex.Message}"); continue; }
                        }
                        RemoveLoaded(existing);
                    }
                    AddLoaded(new Loaded { Plugin = plugin, Folder = folder, Dependencies = declaration.Dependencies, Sdk2 = declaration.RequiresExplicitApproval });
                }
            }
        }

        private static bool IsNewerVersion(string candidate, string current)
        {
            if (System.Version.TryParse(candidate, out var c) && System.Version.TryParse(current, out var u)) return c > u;
            return string.CompareOrdinal(candidate, current) > 0; // fallback: ασυνήθιστη μορφή έκδοσης, τουλάχιστον σταθερή σύγκριση
        }

        private sealed class PluginLoadContext : AssemblyLoadContext
        {
            private readonly AssemblyDependencyResolver _resolver;
            private readonly string _pluginDirectory;

            public PluginLoadContext(string pluginPath) : base(Path.GetFileNameWithoutExtension(pluginPath), isCollectible: false)
            {
                string assemblyPath = Path.GetFullPath(pluginPath);
                _pluginDirectory = Path.GetDirectoryName(assemblyPath)!;
                _resolver = new AssemblyDependencyResolver(assemblyPath);
            }

            protected override Assembly? Load(AssemblyName name)
            {
                // Το contract πρέπει να είναι το ίδιο Assembly instance με του host.
                // Το return null αφήνει την επίλυση στο default context και μπορεί να αποτύχει
                // όταν το contract δεν βρίσκεται στο probing path της εφαρμογής.
                var contractAssembly = typeof(IOpsisNewsCrawlerPlugin).Assembly;
                if (string.Equals(name.Name, contractAssembly.GetName().Name, StringComparison.OrdinalIgnoreCase))
                    return CompatibleHostAssembly(name, contractAssembly);

                // Opsis.UI must be shared as well: a separate copy inside every plugin's
                // AssemblyLoadContext creates independent OpsisTheme/GlassSettings statics.
                // The host owns theme, language and accessibility state for all plugins.
                var sharedUiAssembly = typeof(Opsis.UI.FlatButton).Assembly;
                if (string.Equals(name.Name, sharedUiAssembly.GetName().Name, StringComparison.OrdinalIgnoreCase))
                    return CompatibleHostAssembly(name, sharedUiAssembly);

                // Πρώτα χρησιμοποιούμε το .deps.json μέσω του AssemblyDependencyResolver.
                var path = _resolver.ResolveAssemblyToPath(name);
                if (path != null && File.Exists(path) && PackagePaths.IsExistingUnlinkedPath(_pluginDirectory, path))
                    return LoadFromAssemblyPath(path);

                // Fallback: αρκετά plugin distributions περιλαμβάνουν τις εξαρτήσεις δίπλα
                // στο *Plugin.dll, αλλά το .deps.json μπορεί να μην τις καταγράφει σωστά.
                if (!string.IsNullOrEmpty(name.Name))
                {
                    var candidate = Path.Combine(_pluginDirectory, name.Name + ".dll");
                    if (File.Exists(candidate) && PackagePaths.IsExistingUnlinkedPath(_pluginDirectory, candidate))
                    {
                        // Έλεγχος ταυτότητας ώστε να μη φορτωθεί DLL άλλης έκδοσης με το ίδιο όνομα.
                        try
                        {
                            var candidateName = AssemblyName.GetAssemblyName(candidate);
                            if (AssemblyName.ReferenceMatchesDefinition(name, candidateName))
                                return LoadFromAssemblyPath(candidate);
                        }
                        catch (BadImageFormatException)
                        {
                            // Δεν είναι managed assembly· αφήνουμε το runtime να συνεχίσει την επίλυση.
                        }
                    }
                }

                return null;
            }

            private static Assembly CompatibleHostAssembly(AssemblyName requested, Assembly host)
            {
                var available = host.GetName();
                if (!AssemblyName.ReferenceMatchesDefinition(requested, available) ||
                    (requested.Version != null && available.Version != null && requested.Version > available.Version))
                    throw new FileLoadException($"Plugin requires {requested.FullName}; Opsis provides {available.FullName}. Update Opsis or the plugin.");
                return host;
            }

            protected override IntPtr LoadUnmanagedDll(string unmanagedDllName)
            {
                var path = _resolver.ResolveUnmanagedDllToPath(unmanagedDllName);
                return path != null && PackagePaths.IsExistingUnlinkedPath(_pluginDirectory, path) ? LoadUnmanagedDllFromPath(path) : IntPtr.Zero;
            }
        }

        private static void Log(string message)
        {
            try
            {
                var path = Path.Combine(AppPaths.AppDataFolder, "plugins.log");
                Directory.CreateDirectory(Path.GetDirectoryName(path)!);
                File.AppendAllText(path, $"[{DateTime.Now:O}] {message}\n");
            }
            catch (Exception) { }
        }
    }
}
