using System.Text.Json.Nodes;
using System.Runtime.InteropServices;
using Microsoft.Win32;
using Windows.Management.Deployment;
using MotionDesk.Containers;
using MotionDesk.Widgets;
using Opsis.Containers;

namespace MotionDesk.Services;

public static class DesktopMenu
{
    private const string Root = @"Software\Classes\DesktopBackground\Shell\";
    private const string Handler = @"Software\Classes\DesktopBackground\shellex\ContextMenuHandlers\Opsis";
    private const string ClassicId = "{7F45B246-0BA9-4C86-AB71-09F969610F62}";
    private const string ComClass = @"Software\Classes\CLSID\" + ClassicId;
    private const string OldHandler = @"Software\Classes\DesktopBackground\shellex\ContextMenuHandlers\OpsisStudio";
    private const string FolderRoot = @"Software\Classes\Directory\Background\shell\";
    private const string ModernSettings = @"Software\gs-applabs\Opsis\DesktopMenu";
    private const string PackageName = "gsapplabs.Opsis.Explorer";
    private const string PackagePublisher = "CN=gs-applabs";
    private const string OwnerValue = "OpsisOwner";
    private const string Owner = "gs-applabs/Opsis:desktop-menu:v2";
    private const string StudioOwner = "gs-applabs/Opsis:context-menu:v1";
    private static readonly string[] OldVerbs = ["OpsisStudio", "OpsisStudioNewContainer", "OpsisStudioNextWallpaper", "OpsisDesktopStudio"];

    // Exact known historical keys only. Never search/delete by display name or wildcard.
    private static IEnumerable<string> LegacyPaths() => OldVerbs.SelectMany(name => new[] { Root + name, FolderRoot + name });

    private static bool IsOpsisCommand(string? command)
    {
        if (string.IsNullOrWhiteSpace(command)) return false;
        var value = command.Trim();
        if (!value.StartsWith('"')) return false; // ambiguous unquoted executable: preserve for manual review
        int end = value.IndexOf('"', 1);
        if (end <= 1) return false;
        string exe = value.Substring(1, end - 1);
        return Path.IsPathFullyQualified(exe) && new[] { "Opsis.exe", "OpsisStudio.exe", "MotionDeskStudio.exe" }
            .Contains(Path.GetFileName(exe), StringComparer.OrdinalIgnoreCase);
    }

    private static bool IsOwnedMenu(RegistryKey key)
    {
        string? marker = key.GetValue(OwnerValue) as string;
        if (marker != null) return marker == Owner || marker == StudioOwner;
        using var direct = key.OpenSubKey("command");
        if (direct != null) return IsOpsisCommand(direct.GetValue("") as string);
        using var children = key.OpenSubKey("shell");
        if (children == null) return false;
        var names = children.GetSubKeyNames();
        return names.Length > 0 && names.All(name =>
        {
            using var child = children.OpenSubKey(name);
            return child != null && IsOwnedMenu(child);
        });
    }

    private static void RemoveOwnedMenu(string path)
    {
        bool owned;
        using (var key = Registry.CurrentUser.OpenSubKey(path))
            owned = key != null && IsOwnedMenu(key);
        if (owned) Registry.CurrentUser.DeleteSubKeyTree(path, false);
    }

    private static void RemoveOwnedHandler(string path)
    {
        bool owned;
        using (var key = Registry.CurrentUser.OpenSubKey(path))
            owned = string.Equals(key?.GetValue("") as string, ClassicId, StringComparison.OrdinalIgnoreCase);
        if (owned) Registry.CurrentUser.DeleteSubKeyTree(path, false);
    }

    public static string ExePath => Environment.ProcessPath ?? "";
    public static string PipeName => "opsis-studio-control-v1-" + Environment.UserName.ToLowerInvariant();
    public static string ContainerPipeName => "opsis-studio-containers-v1-" + Environment.UserName.ToLowerInvariant();

    public static readonly HashSet<string> Allowed = new(StringComparer.Ordinal)
    {
        "new-container", "prev-wallpaper", "next-wallpaper", "toggle-wallpaper", "stop-wallpaper",
        "prev-video", "next-video", "toggle-video", "open-opsis", "ping"
    };

    // Windows 11 compact menu ONLY. The registry below stores preferences, not shell verbs.
    private static bool IdentityMatches(string exe)
    {
        string directory = Path.GetDirectoryName(exe)!;
        var matches = new PackageManager().FindPackagesForUser("").Where(p => p.Id.Name == PackageName).ToArray();
        if (matches.Length != 1 || matches[0].Id.Publisher != PackagePublisher ||
            !string.Equals(Path.TrimEndingDirectorySeparator(matches[0].EffectiveExternalLocation.Path),
                Path.TrimEndingDirectorySeparator(directory), StringComparison.OrdinalIgnoreCase)) return false;
        var localDll = Path.Combine(directory, "OpsisExplorer.dll");
        var packagedDll = Path.Combine(matches[0].InstalledLocation.Path, "OpsisExplorer.dll");
        if (!File.Exists(localDll) || !File.Exists(packagedDll)) return false;
        using var local = File.OpenRead(localDll);
        using var packaged = File.OpenRead(packagedDll);
        return System.Security.Cryptography.SHA256.HashData(local).SequenceEqual(System.Security.Cryptography.SHA256.HashData(packaged));
    }

    private static void SetEnabled(bool enabled, string exe, bool greek)
    {
        using var key = Registry.CurrentUser.CreateSubKey(ModernSettings);
        key.SetValue("Executable", exe, RegistryValueKind.String);
        key.SetValue("Greek", greek ? 1 : 0, RegistryValueKind.DWord);
        key.SetValue("Enabled", enabled ? 1 : 0, RegistryValueKind.DWord);
    }

    public static void Register(string exe, bool? greekOverride = null)
    {
        if (!OperatingSystem.IsWindowsVersionAtLeast(10, 0, 22621))
            throw new PlatformNotSupportedException("Opsis desktop menu requires Windows 11 22H2 or newer.");
        if (!Path.IsPathFullyQualified(exe) || exe.Contains('"') || !File.Exists(exe) ||
            !string.Equals(Path.GetFileName(exe), "Opsis.exe", StringComparison.OrdinalIgnoreCase))
            throw new ArgumentException("Invalid Opsis executable path.", nameof(exe));
        bool greek = greekOverride ?? LocalizationManager.CurrentLanguage == "el";
        if (!IdentityMatches(exe))
            throw new InvalidOperationException("The signed Opsis Explorer identity is not registered for this user. Repair the Windows 11 installation.");
        SetEnabled(true, exe, greek);
        RemoveOldVerbs();
        NotifyExplorer();
    }

    // Called by the installer for the actual interactive user. Deployment is not attempted at every startup.
    internal static void InstallIdentity(string exe)
    {
        if (!OperatingSystem.IsWindowsVersionAtLeast(10, 0, 22621))
            throw new PlatformNotSupportedException("Windows 11 22H2+ required.");
        var directory = Path.GetDirectoryName(exe)!;
        var package = Path.Combine(directory, "OpsisExplorer.msix");
        if (!File.Exists(package)) throw new FileNotFoundException("Signed Explorer identity missing.", package);
        // Windows validates the signature/trust. Never import certificates or bypass trust on a user's PC.
        if (!IdentityMatches(exe))
        {
            var result = Task.Run(async () => await new PackageManager().AddPackageByUriAsync(
                new Uri(package), new AddPackageOptions { ExternalLocationUri = new Uri(directory + Path.DirectorySeparatorChar) }).AsTask()).GetAwaiter().GetResult();
            if (result.ExtendedErrorCode is { HResult: not 0 } error)
                throw new InvalidOperationException(result.ErrorText, error);
        }
        if (!IdentityMatches(exe)) throw new InvalidOperationException("Explorer identity registration verification failed.");
    }

    private static void RemoveOldVerbs()
    {
        foreach (var path in LegacyPaths().Append(Root + "Opsis").Append(FolderRoot + "Opsis")) RemoveOwnedMenu(path);
        RemoveOwnedHandler(Handler);
        RemoveOwnedHandler(OldHandler);
        // Leave dormant COM class and unknown / HKLM entries for ownership audit and rollback.
    }

    public static void Unregister()
    {
        SetEnabled(false, ExePath, LocalizationManager.CurrentLanguage == "el");
        RemoveOldVerbs();
        NotifyExplorer();
    }

    public static bool IsRegistered()
    {
        try
        {
            using var settings = Registry.CurrentUser.OpenSubKey(ModernSettings);
            return Equals(settings?.GetValue("Enabled"), 1) && IdentityMatches(ExePath);
        }
        catch (Exception) { return false; }
    }

    public static void Apply(bool enabled)
    {
        if (enabled) Register(ExePath); else Unregister();
    }

    internal static void ApplyInstallerChoice(bool enabled, bool greek)
    {
        InstallIdentity(ExePath);
        if (enabled) Register(ExePath, greek); else Unregister();
        var settings = AppSettings.Load();
        settings.DesktopMenuEnabled = enabled;
        settings.Save();
    }

    internal static void RemoveIdentity()
    {
        Unregister();
        foreach (var package in new PackageManager().FindPackagesForUser("").Where(p =>
            p.Id.Name == PackageName && p.Id.Publisher == PackagePublisher).ToArray())
        {
            var result = Task.Run(async () => await new PackageManager().RemovePackageAsync(package.Id.FullName).AsTask()).GetAwaiter().GetResult();
            if (result.ExtendedErrorCode is { HResult: not 0 } error)
                throw new InvalidOperationException(result.ErrorText, error);
        }
    }

    private static void NotifyExplorer() => SHChangeNotify(0x08000000, 0, IntPtr.Zero, IntPtr.Zero);

    [DllImport("shell32.dll")]
    private static extern void SHChangeNotify(uint eventId, uint flags, IntPtr item1, IntPtr item2);

    public static bool Send(string action)
    {
        try { return PipeClient.Send(PipeName, action, null, 700)["ok"]?.GetValue<bool>() == true; }
        catch (Exception) { return false; }
    }

    internal static void Run(string action)
    {
        try
        {
            var wallpaper = WallpaperHostEngine.Instance;
            switch (action)
            {
                case "next-wallpaper": wallpaper.StepWallpaper(true); break;
                case "prev-wallpaper": wallpaper.StepWallpaper(false); break;
                case "toggle-wallpaper": wallpaper.PlayOrPauseWallpaper(); break;
                case "stop-wallpaper": wallpaper.StopWallpaper(); break;
                case "next-video": wallpaper.StepVideo(true); break;
                case "prev-video": wallpaper.StepVideo(false); break;
                case "toggle-video": wallpaper.TogglePause(); break;
                case "new-container":
                    if (ContainerHost.Current is { } host)
                        host.NewContainerAtCursor(title: LocalizationManager.CurrentLanguage == "el" ? "Νέο DeskContainer" : "New DeskContainer");
                    else TrayApplicationContext.OpenPage?.Invoke("DeskZones"); // disabled/failed native host: settings, never launch old engine
                    break;
                case "open-opsis":
                    TrayApplicationContext.OpenPage?.Invoke("Dashboard");
                    break;
            }
        }
        catch (Exception ex) { RotatingLogger.Write($"Desktop action '{action}' failed: {ex.Message}"); }
    }

    public sealed class Api : IContainersApi
    {
        private readonly SynchronizationContext _ui = SynchronizationContext.Current ?? new WindowsFormsSynchronizationContext();

        public JsonNode? Handle(string cmd, JsonObject args)
        {
            if (!Allowed.Contains(cmd)) throw new PipeException("unknown-command", "not allowed");
            if (cmd != "ping") _ui.Post(_ => Run(cmd), null);
            return new JsonObject { ["accepted"] = cmd };
        }
    }
}
