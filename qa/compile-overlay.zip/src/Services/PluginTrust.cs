using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;

namespace MotionDesk.Services
{
    /// <summary>
    /// Trust model for plugins. A plugin folder under the install directory of Opsis is trusted only when that directory is itself protected
    /// (Program Files: writable by administrators only). Plugin folders anywhere else - %AppData%\Opsis\plugins, registry paths, a per-user install -
    /// are writable by the user (or by any program running as the user), so a dropped DLL would be code execution inside Opsis: such a folder is loaded
    /// only after the user approved its exact content (SHA-256 over every .dll / .deps.json in the folder). The approval is stored in plugin-trust.json;
    /// any change of the content invalidates it.
    /// </summary>
    internal static class PluginTrust
    {
        /// <summary>True when <paramref name="dir"/> is inside Program Files (64/32-bit): only administrators can write there.</summary>
        public static bool IsUnderProtectedInstall(string dir, IEnumerable<string>? protectedRoots = null)
        {
            string full = Normalize(dir);
            var roots = protectedRoots ?? new[]
            {
                Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles),
                Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86),
            };
            foreach (var r in roots)
            {
                if (string.IsNullOrWhiteSpace(r)) continue;
                string root = Normalize(r);
                if (full.StartsWith(root + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase)
                    && PackagePaths.IsExistingUnlinkedPath(root, full)) return true;
            }
            return false;
        }

        private static string Normalize(string p) => Path.GetFullPath(p).TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);

        /// <summary>SHA-256 (hex) over the relative names and contents of all .dll and .deps.json files below the folder, in a stable order.</summary>
        public static string HashFolder(string folder)
        {
            using var total = SHA256.Create();
            var files = PluginFiles(folder)
                .Where(f => f.EndsWith(".dll", StringComparison.OrdinalIgnoreCase) || (f.EndsWith(".deps.json", StringComparison.OrdinalIgnoreCase) || f.EndsWith("opsis-permissions.json", StringComparison.OrdinalIgnoreCase)))
                .OrderBy(f => f, StringComparer.OrdinalIgnoreCase).ToList();
            var sb = new StringBuilder();
            foreach (var f in files)
            {
                using var sha = SHA256.Create();
                using var fs = new FileStream(f, FileMode.Open, FileAccess.Read, FileShare.Read);
                string h = Convert.ToHexString(sha.ComputeHash(fs));
                sb.Append(Path.GetRelativePath(folder, f).ToLowerInvariant()).Append('|').Append(h).Append('\n');
            }
            return Convert.ToHexString(total.ComputeHash(Encoding.UTF8.GetBytes(sb.ToString())));
        }

        /// <summary>SDK2 full package identity. Includes scripts, native assets, configuration and every other regular file.
        /// Deliberately differs from the legacy digest so existing SDK2 approvals must be renewed once.
        /// This is integrity/consent, not isolation or protection from a concurrent writer.</summary>
        internal static string HashCompletePackage(string folder)
        {
            const int maxEntries = 4096;
            const long maxBytes = 512L * 1024 * 1024;
            var files = new SortedDictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            var dirs = new Stack<string>();
            dirs.Push(folder);
            int entries = 0;
            long bytes = 0;
            while (dirs.TryPop(out var dir))
            {
                if (PackagePaths.IsLink(dir)) throw new InvalidDataException("Linked package directory.");
                foreach (var path in Directory.EnumerateFileSystemEntries(dir))
                {
                    if (++entries > maxEntries) throw new InvalidDataException("Package entry limit exceeded.");
                    var attrs = File.GetAttributes(path);
                    if ((attrs & FileAttributes.ReparsePoint) != 0) throw new InvalidDataException("Linked package entry.");
                    if ((attrs & FileAttributes.Directory) != 0) { dirs.Push(path); continue; }
                    var name = Path.GetRelativePath(folder, path).Replace('\\', '/');
                    if (!files.TryAdd(name, path)) throw new InvalidDataException("Ambiguous package path.");
                }
            }
            if (files.Count == 0) throw new InvalidDataException("Empty package.");
            using var total = IncrementalHash.CreateHash(HashAlgorithmName.SHA256);
            total.AppendData(Encoding.UTF8.GetBytes("OPSIS-SDK2-FULL-PACKAGE-V1\n"));
            foreach (var (name, path) in files)
            {
                if (!PackagePaths.IsExistingUnlinkedPath(folder, path)) throw new InvalidDataException("Unsafe package path.");
                using var stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read);
                long length = stream.Length;
                if (length > maxBytes - bytes) throw new InvalidDataException("Package size limit exceeded.");
                bytes += length;
                var digest = SHA256.HashData(stream);
                if (stream.Position != length || stream.Length != length) throw new InvalidDataException("Package changed while hashing.");
                total.AppendData(Encoding.UTF8.GetBytes(Convert.ToBase64String(Encoding.UTF8.GetBytes(name)) + "|" + Convert.ToHexString(digest) + "\n"));
            }
            return Convert.ToHexString(total.GetHashAndReset());
        }

        internal static string ApprovalDigest(string folder, bool sdk2) => sdk2 ? HashCompletePackage(folder) : HashFolder(folder);

        private static IEnumerable<string> PluginFiles(string folder)
        {
            var directories = new Stack<string>();
            directories.Push(folder);
            while (directories.TryPop(out var directory))
            {
                if (PackagePaths.IsLink(directory)) throw new InvalidDataException("Linked plugin folders are not supported.");
                foreach (string entry in Directory.EnumerateFileSystemEntries(directory))
                {
                    var attributes = File.GetAttributes(entry);
                    if ((attributes & FileAttributes.ReparsePoint) != 0)
                        throw new InvalidDataException("Linked plugin files are not supported.");
                    if ((attributes & FileAttributes.Directory) != 0) directories.Push(entry);
                    else yield return entry;
                }
            }
        }

        public sealed class Entry
        {
            public string Name { get; set; } = "";
            public string Sha256 { get; set; } = "";
            public DateTime ApprovedUtc { get; set; }
            public bool Revoked { get; set; }
        }

        public sealed class Store
        {
            private readonly string _path;
            private List<Entry> _entries;
            private readonly object _gate = new();

            public Store(string path)
            {
                _path = path;
                try { _entries = File.Exists(path) ? (JsonSerializer.Deserialize<List<Entry>>(File.ReadAllText(path)) ?? new()).Where(e => e != null).ToList() : new(); }
                catch (Exception ex) when (ex is JsonException or IOException or UnauthorizedAccessException) { _entries = new(); }
            }

            public bool IsApproved(string name, string sha256)
            {
                lock (_gate) return !IsRevoked(name) && _entries.Any(e => string.Equals(e.Name, name, StringComparison.OrdinalIgnoreCase) && string.Equals(e.Sha256, sha256, StringComparison.OrdinalIgnoreCase));
            }

            public bool IsRevoked(string name)
            {
                lock (_gate) return _entries.Any(e => e.Revoked && string.Equals(e.Name, name, StringComparison.OrdinalIgnoreCase));
            }

            private void Persist(List<Entry> next)
            {
                Directory.CreateDirectory(Path.GetDirectoryName(_path)!);
                AtomicFile.WriteAllText(_path, JsonSerializer.Serialize(next, new JsonSerializerOptions { WriteIndented = true }));
            }

            public void Revoke(string name)
            {
                lock (_gate)
                {
                    var next = _entries.Where(e => !string.Equals(e.Name, name, StringComparison.OrdinalIgnoreCase)).ToList();
                    next.Add(new Entry { Name = name, Revoked = true });
                    _entries = next; // fail closed in this session even if disk write fails
                    Persist(next);
                }
            }

            public void Approve(string name, string sha256)
            {
                lock (_gate)
                {
                    var next = _entries.Where(e => !string.Equals(e.Name, name, StringComparison.OrdinalIgnoreCase)).ToList();
                    next.Add(new Entry { Name = name, Sha256 = sha256.ToUpperInvariant(), ApprovedUtc = DateTime.UtcNow });
                    Persist(next); // failed persistence must never grant in-memory approval
                    _entries = next;
                }
            }
        }
    }

    public sealed record PluginTrustRequest(string Name, string Folder, string Sha256,
        string Publisher = "Unknown / Άγνωστος", string SignatureStatus = "Unknown / Άγνωστη", string Capabilities = "Not declared / Δεν δηλώθηκαν");

    /// <summary>
    /// Inspect both publisher certificate METADATA and Windows Authenticode
    /// verification. An embedded certificate alone is not proof of trust.
    /// Offline verification avoids unexpected network traffic in the approval UI;
    /// certificate revocation is therefore not verified and is reported as such.
    /// </summary>
    internal static class PluginPublisherInfo
    {
        internal static (string Publisher, string SignatureStatus) Inspect(string folder)
        {
            try
            {
                var dll = Directory.EnumerateFiles(folder, "*Plugin.dll", SearchOption.TopDirectoryOnly)
                    .FirstOrDefault(path => (File.GetAttributes(path) & FileAttributes.ReparsePoint) == 0);
                if (dll == null) return ("Unknown", "No plugin entry DLL found");
                string publisher = "Unknown / Άγνωστος";
                try
                {
                    using var cert = System.Security.Cryptography.X509Certificates.X509Certificate.CreateFromSignedFile(dll);
                    publisher = cert.Subject;
                }
                catch (System.Security.Cryptography.CryptographicException)
                {
                    // An unsigned DLL has no embedded publisher certificate.
                }
                var signature = AuthenticodeVerifier.VerifyOffline(dll);
                return (publisher, signature);
            }
            catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or ArgumentException)
            { return ("Unknown", "Could not inspect: " + ex.GetType().Name); }
        }
    }
}
