using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MotionDesk.Services
{
    // Πραγματική λύση για το .wmv (όχι μόνο προειδοποίηση): μετατρέπει αυτόματα σε .webm (VP9/
    // Opus) μέσω FFmpeg πριν προστεθεί στο Wallpaper Studio, αφού το ενσωματωμένο player (WebView2/
    // Chromium) δεν έχει decoder για τον παλιό codec WMV3/VC-1. Επιλέχθηκε FFmpeg (εξωτερική
    // διεργασία, όχι COM) αντί για το legacy Windows Media Player ActiveX control ή για χειροποίητο
    // Media Foundation COM interop — και τα δύο θα απαιτούσαν εύθραυστο, μη-επαληθεύσιμο κώδικα
    // (ακριβές vtable/typelib interop) χωρίς πραγματική επιφάνεια εργασίας Windows διαθέσιμη εδώ
    // για ζωντανό έλεγχο· το FFmpeg είναι ο βιομηχανικός κανόνας γι' ακριβώς αυτή τη μετατροπή,
    // με σταθερό, καλά τεκμηριωμένο command-line interface.
    public static class WmvConversionService
    {
        private static string DefaultCacheDir
        {
            get
            {
                string videos = Environment.GetFolderPath(Environment.SpecialFolder.MyVideos);
                if (string.IsNullOrWhiteSpace(videos)) videos = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "Videos");
                return Path.Combine(videos, "Opsis");
            }
        }
        private static readonly System.Threading.SemaphoreSlim EncodeGate = new(1, 1);

        // Ο χρήστης μπορεί να επιλέξει δικό του φάκελο αποθήκευσης για ΟΛΑ τα μετατρεπόμενα
        // βίντεο (ζητήθηκε ρητά "να έχει επιλογή ο χρήστης το path αποθήκευσης") — προεπιλογή
        // είναι ο ειδικός φάκελος Βίντεο των Windows, υποφάκελος Opsis.
        public static string CacheDir
        {
            get
            {
                var custom = AppSettings.Load().WmvConversionOutputDir;
                return !string.IsNullOrWhiteSpace(custom) && Directory.Exists(Path.GetPathRoot(custom) ?? custom)
                    ? custom
                    : DefaultCacheDir;
            }
        }

        private static string? _cachedFfmpegPath;

        public static string? FindFfmpeg()
        {
            if (_cachedFfmpegPath != null) return _cachedFfmpegPath;
            // Αρνητικό cache 30s: όταν το FFmpeg ΔΕΝ υπάρχει, κάθε κλήση (άνοιγμα σελίδας Ρυθμίσεων, κάθε
            // προσθήκη βίντεο) ξεκινούσε διεργασία probe + αναδρομική σάρωση του WinGet\Packages στο UI thread.
            if (_notFoundUntil > DateTime.UtcNow) return null;

            // 1) Ήδη στο PATH του συστήματος (π.χ. εγκαταστάθηκε από τον χρήστη ή μέσω winget).
            if (TryProbe("ffmpeg")) { _cachedFfmpegPath = "ffmpeg"; return _cachedFfmpegPath; }

            // 2) Προαιρετικό τοπικό αντίγραφο δίπλα στην εφαρμογή (ο χρήστης το τοποθέτησε ο
            // ίδιος, ή μελλοντικός installer bundle) — ΔΕΝ κατεβάζουμε τίποτα αυτόματα εμείς.
            string local = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "ffmpeg", "ffmpeg.exe");
            if (File.Exists(local)) { _cachedFfmpegPath = local; return _cachedFfmpegPath; }

            // 3) WinGet εγκατάσταση (π.χ. "winget install Gyan.FFmpeg") — δεν βασιζόμαστε στο ΝΑ
            // έχει ήδη ανανεωθεί το PATH της τρέχουσας διεργασίας (οι μεταβλητές περιβάλλοντος
            // ΔΕΝ ανανεώνονται αυτόματα σε ήδη-τρέχουσες διεργασίες μετά από winget install, μόνο
            // σε νέες που ξεκινούν αφού το Explorer λάβει το WM_SETTINGCHANGE broadcast) — ψάχνουμε
            // απευθείας τους δύο γνωστούς φακέλους: το "shim" του WinGet (Links) και τον πραγματικό
            // φάκελο πακέτου (Packages\Gyan.FFmpeg_...\...\bin\ffmpeg.exe).
            string localAppData = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            string wingetLink = Path.Combine(localAppData, "Microsoft", "WinGet", "Links", "ffmpeg.exe");
            if (File.Exists(wingetLink)) { _cachedFfmpegPath = wingetLink; return _cachedFfmpegPath; }

            string wingetPackages = Path.Combine(localAppData, "Microsoft", "WinGet", "Packages");
            if (Directory.Exists(wingetPackages))
            {
                try
                {
                    string? found = Directory.EnumerateFiles(wingetPackages, "ffmpeg.exe", SearchOption.AllDirectories).FirstOrDefault();
                    if (found != null) { _cachedFfmpegPath = found; return _cachedFfmpegPath; }
                }
                catch (IOException) { }
                catch (UnauthorizedAccessException) { }
            }

            _notFoundUntil = DateTime.UtcNow.AddSeconds(30);
            return null;
        }

        private static DateTime _notFoundUntil = DateTime.MinValue;

        // Μετά από (ξανα)εγκατάσταση ζητάμε άμεση νέα ανίχνευση αντί να περιμένουμε τη λήξη του αρνητικού cache.
        public static void ResetDetection() { _notFoundUntil = DateTime.MinValue; _cachedFfmpegPath = null; }

        private static bool TryProbe(string exe)
        {
            try
            {
                var psi = new ProcessStartInfo(exe, "-version")
                { RedirectStandardOutput = true, RedirectStandardError = true, UseShellExecute = false, CreateNoWindow = true };
                using var p = Process.Start(psi);
                if (p == null) return false;
                return p.WaitForExit(2000) && p.ExitCode == 0;
            }
            catch { return false; }
        }

        public static bool IsFfmpegAvailable => FindFfmpeg() != null;

        // Ανοίγει τη σελίδα λήψης σε browser — ΔΕΝ κατεβάζουμε/εκτελούμε τίποτα εμείς οι ίδιοι,
        // ο χρήστης εγκαθιστά το FFmpeg με δική του ρητή ενέργεια.
        // Κοινός, τοπικοποιημένος διάλογος "λείπει το FFmpeg" για όλα τα σημεία εισαγωγής .wmv.
        public static void PromptInstallFfmpeg(int wmvCount)
        {
            var choice = MessageBox.Show(
                string.Format(LocalizationManager.T("Dialog.FfmpegMissingFormat"), wmvCount),
                LocalizationManager.T("Dialog.FfmpegTitle"), MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (choice == DialogResult.Yes) OpenFfmpegDownloadPage();
        }

        public static void OpenFfmpegDownloadPage()
        {
            try { Process.Start(new ProcessStartInfo("https://www.gyan.dev/ffmpeg/builds/") { UseShellExecute = true }); }
            catch { }
        }

        // Μετατρέπει ένα .wmv σε .webm, με cache βάσει μεγέθους+ημερομηνίας αρχείου ώστε να μην
        // ξαναμετατρέπεται το ίδιο αρχείο σε κάθε επανεκκίνηση της εφαρμογής.
        // PR #17 follow-up: serialize encodes, validate before publishing, retain sources.
        private const string EncodeProfile = "vp9-crf24-opus96-yuv420p-v2";
        public static async Task<string?> ConvertToWebmAsync(string wmvPath, System.Threading.CancellationToken ct = default)
        {
            await EncodeGate.WaitAsync(ct).ConfigureAwait(false);
            try
            {
                return await Task.Run(() => ConvertCoreAsync(wmvPath, ct), ct).ConfigureAwait(false);
            }
            catch (OperationCanceledException) { throw; }
            catch (Exception) { return null; }
            finally { EncodeGate.Release(); }
        }

        private static async Task<string?> ConvertCoreAsync(string wmvPath, System.Threading.CancellationToken ct)
        {
            string? ffmpeg = FindFfmpeg();
            if (ffmpeg == null || !File.Exists(wmvPath)) return null;
            using var timeout = System.Threading.CancellationTokenSource.CreateLinkedTokenSource(ct);
            timeout.CancelAfter(TimeSpan.FromMinutes(30));
            var token = timeout.Token;
            string? tempPath = null;
            try
            {
                var encoderVersion = await RunMediaAsync(ffmpeg, new[] { "-version" }, token).ConfigureAwait(false);
                if (encoderVersion.Code != 0 || string.IsNullOrWhiteSpace(encoderVersion.Output)) return null;
                string encoder = ffmpeg + "|" + encoderVersion.Output.Split('\n')[0].Trim();
                string ffprobe = FindFfprobe(ffmpeg);
                var probeVersion = await RunMediaAsync(ffprobe, new[] { "-version" }, token).ConfigureAwait(false);
                if (probeVersion.Code != 0) return null;
                var source = new FileInfo(wmvPath);
                string key = CacheKey(source, encoder);
                string directory = CacheDir;
                Directory.CreateDirectory(directory);
                string stem = Path.GetFileNameWithoutExtension(wmvPath);
                if (stem.Length > 80) stem = stem[..80];
                string outputPath = Path.Combine(directory, $"{stem}_{key}.webm");
                if (await ValidateAsync(ffmpeg, ffprobe, outputPath, token).ConfigureAwait(false) && key == CacheKey(new FileInfo(wmvPath), encoder)) return outputPath;
                tempPath = outputPath + "." + Guid.NewGuid().ToString("N") + ".partial.webm";
                var args = new[] { "-nostdin", "-hide_banner", "-loglevel", "error", "-xerror", "-y", "-filter_threads", "2", "-threads", "2", "-i", wmvPath,
                    "-map", "0:v:0", "-map", "0:a:0?", "-vf", "scale=trunc(iw/2)*2:trunc(ih/2)*2", "-pix_fmt", "yuv420p",
                    "-c:v", "libvpx-vp9", "-deadline", "good", "-cpu-used", "4", "-row-mt", "1", "-threads", "2", "-b:v", "0", "-crf", "24", "-c:a", "libopus", "-b:a", "96k", "-f", "webm", tempPath };
                var encode = await RunMediaAsync(ffmpeg, args, token).ConfigureAwait(false);
                if (encode.Code != 0 || !await ValidateAsync(ffmpeg, ffprobe, tempPath, token).ConfigureAwait(false)) return null;
                if (key != CacheKey(new FileInfo(wmvPath), encoder)) return null; // source changed during encode
                token.ThrowIfCancellationRequested();
                File.Move(tempPath, outputPath, overwrite: true);
                return outputPath;
            }
            catch (OperationCanceledException) when (!ct.IsCancellationRequested) { return null; }
            finally { if (tempPath != null) { try { File.Delete(tempPath); } catch (Exception) { } } }
        }

        private static string CacheKey(FileInfo info, string encoder)
        {
            string raw = $"{info.FullName}|{info.Length}|{info.LastWriteTimeUtc.Ticks}|{EncodeProfile}|{encoder}";
            return Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(Encoding.UTF8.GetBytes(raw)))[..24];
        }

        private static string FindFfprobe(string ffmpeg)
        {
            if (Path.IsPathRooted(ffmpeg))
            {
                string companion = Path.Combine(Path.GetDirectoryName(ffmpeg)!, "ffprobe.exe");
                if (File.Exists(companion)) return companion;
            }
            return "ffprobe";
        }

        private static async Task<bool> ValidateAsync(string ffmpeg, string ffprobe, string path, System.Threading.CancellationToken ct)
        {
            if (!File.Exists(path) || new FileInfo(path).Length == 0) return false;
            var probe = await RunMediaAsync(ffprobe, new[] { "-v", "error", "-show_entries", "format=format_name,duration:stream=codec_name,codec_type,width,height", "-of", "json", path }, ct).ConfigureAwait(false);
            if (probe.Code != 0) return false; // fail closed; no unchecked generated files
            double duration;
            try
            {
                using var doc = System.Text.Json.JsonDocument.Parse(probe.Output);
                var format = doc.RootElement.GetProperty("format");
                if (!(format.GetProperty("format_name").GetString() ?? "").Split(',').Contains("webm")) return false;
                if (!double.TryParse(format.GetProperty("duration").GetString(), System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out duration) || !double.IsFinite(duration) || duration <= 0) return false;
                bool video = false;
                foreach (var stream in doc.RootElement.GetProperty("streams").EnumerateArray())
                {
                    var type = stream.GetProperty("codec_type").GetString(); var codec = stream.GetProperty("codec_name").GetString();
                    if (type == "video") { if (codec != "vp9" || stream.GetProperty("width").GetInt32() <= 0 || stream.GetProperty("height").GetInt32() <= 0) return false; video = true; }
                    if (type == "audio" && codec != "opus") return false;
                }
                if (!video) return false;
            }
            catch (Exception) { return false; }
            // Decode a frame near both ends. This is a sample, not a full-stream integrity proof.
            var first = await RunMediaAsync(ffmpeg, new[] { "-nostdin", "-v", "error", "-xerror", "-i", path, "-map", "0:v:0", "-frames:v", "1", "-progress", "pipe:1", "-nostats", "-f", "null", "-" }, ct).ConfigureAwait(false);
            if (first.Code != 0 || !HasDecodedFrame(first.Output)) return false;
            if (duration < 1) return true;
            var last = await RunMediaAsync(ffmpeg, new[] { "-nostdin", "-v", "error", "-xerror", "-sseof", "-0.25", "-i", path, "-map", "0:v:0", "-frames:v", "1", "-progress", "pipe:1", "-nostats", "-f", "null", "-" }, ct).ConfigureAwait(false);
            return last.Code == 0 && HasDecodedFrame(last.Output);
        }

        private static bool HasDecodedFrame(string progress) => progress.Split('\n').Any(line =>
            line.StartsWith("frame=", StringComparison.Ordinal) && int.TryParse(line[6..].Trim(), out int count) && count > 0);

        private static async Task<(int Code, string Output)> RunMediaAsync(string exe, string[] args, System.Threading.CancellationToken ct)
        {
            ct.ThrowIfCancellationRequested();
            var psi = new ProcessStartInfo(exe) { UseShellExecute = false, CreateNoWindow = true, RedirectStandardOutput = true, RedirectStandardError = true };
            foreach (var arg in args) psi.ArgumentList.Add(arg);
            Process? process;
            try { process = Process.Start(psi); } catch (Exception) { return (-1, ""); }
            using var proc = process;
            if (proc == null) return (-1, "");
            try { proc.PriorityClass = ProcessPriorityClass.BelowNormal; } catch (Exception) { }
            // Drain both streams. Error logging is restricted; ffprobe JSON is small for our single-output streams.
            var stdout = proc.StandardOutput.ReadToEndAsync();
            var stderr = proc.StandardError.ReadToEndAsync();
            try { await proc.WaitForExitAsync(ct).ConfigureAwait(false); }
            catch (OperationCanceledException)
            {
                try { proc.Kill(entireProcessTree: true); } catch (Exception) { }
                try { await proc.WaitForExitAsync().WaitAsync(TimeSpan.FromSeconds(5)).ConfigureAwait(false); } catch (Exception) { }
                throw;
            }
            await Task.WhenAll(stdout, stderr).ConfigureAwait(false);
            return (proc.ExitCode, await stdout.ConfigureAwait(false));
        }
    }
}
