using System.Text.Json;

namespace MotionDesk.Services;

/// <summary>Versioned declaration, not an OS sandbox. SDK version is independent of DLL ABI.
/// Legacy packages retain the existing contract. SDK 2.0 currently accepts only explicitly
/// approved in-process packages; an isolated runtime is not implemented and is rejected.</summary>
internal static class PluginCapabilityManifest
{
    internal sealed record Declaration(string SdkVersion, bool Present, bool Network, bool Audio, bool LocalFiles)
    {
        internal PluginDependencyPolicy.Requirement[] Dependencies { get; init; } = [];
        internal bool RequiresExplicitApproval => SdkVersion == "2.0";
        internal string[] Capabilities => new[] { (Network, "network"), (Audio, "audio"), (LocalFiles, "local-files") }
            .Where(x => x.Item1).Select(x => x.Item2).ToArray();
        internal string Summary => $"SDK {SdkVersion} · in-process (not sandboxed) · " +
            (Capabilities.Length > 0 ? string.Join(", ", Capabilities) : "Not declared / Δεν δηλώθηκαν") +
            (Dependencies.Length == 0 ? "" : " · Requires: " + string.Join(", ", Dependencies.Select(d => d.Id + " " + d.Range)));
    }

    internal static Declaration Inspect(string folder)
    {
        var path = Path.Combine(folder, "opsis-permissions.json");
        try { File.GetAttributes(path); }
        catch (FileNotFoundException) { return new("1.0", false, false, false, false); }
        if (!PackagePaths.IsExistingUnlinkedPath(folder, path))
            throw new InvalidDataException("Unsafe plugin permission declaration.");
        using var stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read);
        if (stream.Length > 4096) throw new InvalidDataException("Plugin declaration exceeds 4096 bytes.");
        using var doc = JsonDocument.Parse(stream, new JsonDocumentOptions { MaxDepth = 8 });
        if (doc.RootElement.ValueKind != JsonValueKind.Object)
            throw new InvalidDataException("Plugin permission declaration must be an object.");
        var properties = new Dictionary<string, JsonElement>(StringComparer.OrdinalIgnoreCase);
        foreach (var p in doc.RootElement.EnumerateObject())
            if (!properties.TryAdd(p.Name, p.Value)) throw new InvalidDataException("Duplicate plugin declaration property.");
        string StringValue(string key) => properties.TryGetValue(key, out var v) && v.ValueKind == JsonValueKind.String
            ? v.GetString()! : throw new InvalidDataException("Invalid plugin declaration: " + key);
        bool Flag(string key) => !properties.TryGetValue(key, out var v) ? false : v.ValueKind switch
        {
            JsonValueKind.True => true, JsonValueKind.False => false,
            _ => throw new InvalidDataException("Invalid capability flag: " + key)
        };
        var sdk = properties.ContainsKey("sdkVersion") ? StringValue("sdkVersion") : "1.0";
        if (sdk is not ("1.0" or "2.0")) throw new InvalidDataException("Unsupported plugin SDK version: " + sdk);
        if (sdk == "2.0")
        {
            var allowed = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
                { "sdkVersion", "runtime", "network", "audio", "localFiles", "dependencies" };
            if (properties.Keys.Any(k => !allowed.Contains(k))) throw new InvalidDataException("Unknown SDK 2.0 declaration property.");
            if (StringValue("runtime") != "in-process") throw new InvalidDataException("Requested plugin runtime is not supported; isolation is not available.");
        }
        else if (properties.ContainsKey("runtime") && StringValue("runtime") != "in-process")
            throw new InvalidDataException("Unsupported legacy plugin runtime.");
        var dependencies = new List<PluginDependencyPolicy.Requirement>();
        if (properties.TryGetValue("dependencies", out var deps))
        {
            if (sdk != "2.0" || deps.ValueKind != JsonValueKind.Object)
                throw new InvalidDataException("Dependencies require an SDK 2.0 object.");
            var ids = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (var entry in deps.EnumerateObject())
            {
                if (dependencies.Count >= 32 || !PluginDependencyPolicy.ValidId(entry.Name) || !ids.Add(entry.Name))
                    throw new InvalidDataException("Invalid or duplicate plugin dependency: " + entry.Name);
                Version? minimum = null, maximum = null;
                if (entry.Value.ValueKind == JsonValueKind.String)
                    Version.TryParse(entry.Value.GetString(), out minimum);
                else if (entry.Value.ValueKind == JsonValueKind.Object)
                {
                    var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                    foreach (var field in entry.Value.EnumerateObject())
                    {
                        if (!seen.Add(field.Name) || field.Value.ValueKind != JsonValueKind.String ||
                            !Version.TryParse(field.Value.GetString(), out var parsed))
                            throw new InvalidDataException("Invalid dependency range: " + entry.Name);
                        if (field.Name.Equals("min", StringComparison.OrdinalIgnoreCase)) minimum = parsed;
                        else if (field.Name.Equals("maxExclusive", StringComparison.OrdinalIgnoreCase)) maximum = parsed;
                        else throw new InvalidDataException("Unknown dependency range field: " + field.Name);
                    }
                }
                if (minimum == null || !PluginDependencyPolicy.ValidRange(minimum, maximum))
                    throw new InvalidDataException("Invalid dependency version range: " + entry.Name);
                dependencies.Add(new(entry.Name, minimum) { MaximumExclusive = maximum });
            }
        }
        return new(sdk, true, Flag("network"), Flag("audio"), Flag("localFiles")) { Dependencies = dependencies.ToArray() };
    }

    internal static string[] Read(string folder) => Inspect(folder).Capabilities;
    internal static string Summary(string folder)
    {
        try { return Inspect(folder).Summary; }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or JsonException or InvalidDataException)
        { return "Invalid declaration: " + ex.GetType().Name; }
    }
}
