using System;
using System.IO;
using System.Linq;
using Microsoft.Win32;

namespace MotionDesk.Services;

/// <summary>
/// Compatibility façade for the single Windows 11 compact desktop menu; does not register another shell verb.
/// </summary>
public static class OpsisContextMenuStudio
{
    // Compatibility façade: both old UI switches use the same canonical menu and preference.
    public static bool IsEnabled() => DesktopMenu.IsRegistered();

    /// <summary>Do not allow an arbitrary user-supplied executable or command line.</summary>
    private static string VerifyOpsisExe(string candidate)
    {
        if (string.IsNullOrWhiteSpace(candidate) || !Path.IsPathFullyQualified(candidate) ||
            !string.Equals(Path.GetFileName(candidate), "Opsis.exe", StringComparison.OrdinalIgnoreCase) ||
            !File.Exists(candidate) || candidate.Contains('"'))
            throw new InvalidOperationException("A trusted installed Opsis.exe is required for shell integration.");
        var full = Path.GetFullPath(candidate);
        var installed = Path.GetFullPath(DefaultExecutable);
        if (!string.Equals(full, installed, StringComparison.OrdinalIgnoreCase) &&
            !AppSettings.IsIsolatedForTests())
            throw new InvalidOperationException("Only the current installed Opsis executable can be registered.");
        return full;
    }

    public static string DefaultExecutable => Path.Combine(AppContext.BaseDirectory, "Opsis.exe");

    public static void Enable(string? opsisExe = null)
    {
        var exe = VerifyOpsisExe(opsisExe ?? DefaultExecutable);
        DesktopMenu.Register(exe);
        var settings = AppSettings.Load();
        settings.DesktopMenuEnabled = true;
        settings.Save();
    }

    public static void Disable()
    {
        DesktopMenu.Unregister();
        var settings = AppSettings.Load();
        settings.DesktopMenuEnabled = false;
        settings.Save();
    }

    public static string Describe() => IsEnabled()
        ? "One Opsis menu in Windows 11 compact context menu, with native DeskContainers and wallpaper actions."
        : "Opsis modern menu is disabled or needs signed Explorer identity repair. No classic fallback.";
}
