using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text.Json;
using Microsoft.Win32;

namespace MotionDesk.Services;

/// <summary>Documented Windows Start preferences only. No process injection, policy
/// override, pinned database edits or Explorer restart. Values may be ignored by
/// particular Windows builds or policy; confirm in the Windows Start UI.</summary>
public static class NativeStartPreferences
{
    private const string Advanced = @"Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced";
    private const string Start = @"Software\Microsoft\Windows\CurrentVersion\Start";
    private static readonly (string Id, string Path, int Max)[] Options =
    {
        ("Start_Layout", Advanced, 2),
        ("ShowAllPinsList", Start, 1),
        ("Start_IrisRecommendations", Advanced, 1),
        ("ShowRecentList", Start, 1),
        ("Start_TrackDocs", Advanced, 1)
    };
    private static readonly object Gate = new();
    private static string BackupPath => Path.Combine(AppPaths.AppDataFolder, "native-start-original.json");
    public static bool HasBackup => File.Exists(BackupPath);
    public static bool IsSupported => OperatingSystem.IsWindowsVersionAtLeast(10, 0, 22000);
    public static bool IsValid(string id, int value) =>
        Options.Any(x => x.Id == id && value >= 0 && value <= x.Max);

    private static void CheckWritable()
    {
        if (!IsSupported) throw new PlatformNotSupportedException("Windows 11 is required.");
        if (SafeModeService.IsSafeMode || WindowsUpdateGuard.RequiresReview)
            throw new InvalidOperationException("Windows compatibility review required.");
        var mods = OpsisModCompatibility.ScanCached();
        if (mods.Any(x => x.Risk == "High" ||
            (x.Product.StartsWith("Windhawk: ", StringComparison.Ordinal) && x.Area == "Start")))
            throw new InvalidOperationException("Competing Start customization detected. Review it before applying Opsis preferences.");
    }

    private static int? ReadRaw(string id)
    {
        var entry = Options.Single(x => x.Id == id);
        using var key = Registry.CurrentUser.OpenSubKey(entry.Path, false);
        var raw = key?.GetValue(id);
        if (raw != null && (raw is not int v || !IsValid(id, v) || key!.GetValueKind(id) != RegistryValueKind.DWord))
            throw new InvalidDataException("Unsupported current Start preference: " + id);
        return raw as int?;
    }

    public static Dictionary<string, int?> Read() => Options.ToDictionary(x => x.Id, x => ReadRaw(x.Id), StringComparer.Ordinal);

    private static void Write(string id, int? value)
    {
        var entry = Options.Single(x => x.Id == id);
        if (value == null)
        {
            using var key = Registry.CurrentUser.OpenSubKey(entry.Path, true);
            key?.DeleteValue(entry.Id, false);
        }
        else
        {
            using var key = Registry.CurrentUser.CreateSubKey(entry.Path);
            key.SetValue(entry.Id, value.Value, RegistryValueKind.DWord);
        }
    }

    // Legacy backups contain the original three keys. Never replace their values
    // when extending the backup to include the two additional preferences.
    public static Dictionary<string, int?> ValidateBackup(string json)
    {
        using var doc = JsonDocument.Parse(json);
        if (doc.RootElement.ValueKind != JsonValueKind.Object) throw new InvalidDataException("Invalid Start backup.");
        var saved = new Dictionary<string, int?>(StringComparer.Ordinal);
        foreach (var item in doc.RootElement.EnumerateObject())
        {
            if (!Options.Any(x => x.Id == item.Name)) throw new InvalidDataException("Unknown Start backup key.");
            int? value = item.Value.ValueKind == JsonValueKind.Null ? null : item.Value.GetInt32();
            if ((value.HasValue && !IsValid(item.Name, value.Value)) || !saved.TryAdd(item.Name, value))
                throw new InvalidDataException("Invalid Start backup value.");
        }
        if (Options.Take(3).Any(x => !saved.ContainsKey(x.Id))) throw new InvalidDataException("Missing original Start backup keys.");
        return saved;
    }

    private static Dictionary<string, int?> ReadBackup()
    {
        if (!HasBackup || new FileInfo(BackupPath).Length > 4096) throw new InvalidDataException("Start backup unavailable or invalid.");
        return ValidateBackup(File.ReadAllText(BackupPath));
    }

    private static void BackupIfMissing()
    {
        var saved = HasBackup ? ReadBackup() : new Dictionary<string, int?>(StringComparer.Ordinal);
        int count = saved.Count;
        foreach (var option in Options)
            if (!saved.ContainsKey(option.Id)) saved.Add(option.Id, ReadRaw(option.Id));
        if (count != saved.Count) AtomicFile.WriteAllText(BackupPath, JsonSerializer.Serialize(saved));
    }

    public static void Apply(Dictionary<string, int> changes) =>
        ApplySelection(changes.ToDictionary(p => p.Key, p => (int?)p.Value, StringComparer.Ordinal));

    public static bool ApplySelection(IReadOnlyDictionary<string, int?> desired)
    {
        if (desired.Any(p => !Options.Any(x => x.Id == p.Key) || (p.Value.HasValue && !IsValid(p.Key, p.Value.Value))))
            throw new InvalidDataException("Invalid Start preference.");
        lock (Gate)
        {
            CheckWritable();
            return ShellPreferenceTransaction.Apply(desired, ReadRaw, Write, BackupIfMissing);
        }
    }

    public static void Restore()
    {
        lock (Gate)
        {
            CheckWritable();
            ShellPreferenceTransaction.Apply(ReadBackup(), ReadRaw, Write, () => { });
        }
    }

    public static void OpenWindowsSettings(bool folders = false)
    {
        Process.Start(new ProcessStartInfo(folders ? "ms-settings:personalization-start-places" : "ms-settings:personalization-start") { UseShellExecute = true });
    }
}
