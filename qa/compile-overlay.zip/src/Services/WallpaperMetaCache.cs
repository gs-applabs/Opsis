using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace MotionDesk.Services;

// Cache owns only immutable data; consumers never receive a cached GDI handle.
internal sealed class WallpaperMetaCache<T> where T : class
{
    private sealed record Entry(T? Value, long Cost, DateTime Expires);
    private readonly object _gate = new();
    private readonly Dictionary<string, LinkedListNode<(string Key, Entry Entry)>> _entries = new(StringComparer.OrdinalIgnoreCase);
    private readonly LinkedList<(string Key, Entry Entry)> _lru = new();
    private readonly Dictionary<string, Task<T?>> _pending = new(StringComparer.OrdinalIgnoreCase);
    private readonly SemaphoreSlim _workers;
    private readonly int _maxEntries, _maxPending;
    private readonly long _maxBytes;
    private long _bytes;

    internal WallpaperMetaCache(int maxEntries, long maxBytes, int maxPending, int workers)
    {
        _maxEntries = maxEntries; _maxBytes = maxBytes; _maxPending = maxPending;
        _workers = new SemaphoreSlim(workers, workers);
    }

    private void Remove(LinkedListNode<(string Key, Entry Entry)> node)
    {
        _bytes -= node.Value.Entry.Cost;
        _entries.Remove(node.Value.Key); _lru.Remove(node);
    }

    internal Task<T?> GetAsync(string key, Func<Task<T?>> load, Func<T, long> cost, CancellationToken ct)
    {
        if (ct.IsCancellationRequested) return Task.FromCanceled<T?>(ct);
        Task<T?> task;
        lock (_gate)
        {
            if (_entries.TryGetValue(key, out var node))
            {
                if (node.Value.Entry.Expires > DateTime.UtcNow)
                {
                    _lru.Remove(node); _lru.AddFirst(node);
                    return Task.FromResult(node.Value.Entry.Value);
                }
                Remove(node);
            }
            if (!_pending.TryGetValue(key, out var existing))
            {
                // Bound the queue as well as the cache; a saturated gallery can retry on its next refresh.
                if (_pending.Count >= _maxPending) return Task.FromResult<T?>(null);
                task = Task.Run(async () =>
                {
                    T? value = null;
                    await _workers.WaitAsync().ConfigureAwait(false);
                    try { value = await load().ConfigureAwait(false); }
                    catch (Exception) { /* optional metadata */ }
                    finally { _workers.Release(); }
                    lock (_gate)
                    {
                        try
                        {
                            long bytes = value == null ? 0 : cost(value);
                            if (bytes >= 0 && bytes <= _maxBytes)
                            {
                                var entry = new Entry(value, bytes, DateTime.UtcNow.AddMinutes(value == null ? 1 : 30));
                                _entries[key] = _lru.AddFirst((key, entry)); _bytes += bytes;
                                while (_entries.Count > _maxEntries || _bytes > _maxBytes) Remove(_lru.Last!);
                            }
                        }
                        finally { _pending.Remove(key); }
                    }
                    return value;
                });
                _pending.Add(key, task); // worker publication also takes _gate
            }
            else task = existing;
        }
        // Cancel only the consumer; other rows can still await the shared job.
        return task.WaitAsync(ct);
    }
}
