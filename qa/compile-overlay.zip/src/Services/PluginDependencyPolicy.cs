namespace MotionDesk.Services;

/// <summary>Host activation policy, independent of assembly binding. No package installation or code isolation.</summary>
internal static class PluginDependencyPolicy
{
    internal sealed record Requirement(string Id, Version MinimumVersion)
    {
        internal Version? MaximumExclusive { get; init; }
        internal string Range => ">= " + MinimumVersion + (MaximumExclusive == null ? "" : " and < " + MaximumExclusive);
    }
    internal static bool ValidRange(Version minimum, Version? maximum) => maximum == null || Normalize(minimum) < Normalize(maximum);
    internal sealed record Node(string Id, string Version, bool Started, Requirement[] Dependencies);

    internal static bool ValidId(string id) => id.Length is > 0 and <= 128 &&
        id.All(c => char.IsAsciiLetterOrDigit(c) || c is '.' or '-' or '_');

    private static Version Normalize(Version v) => new(v.Major, v.Minor, Math.Max(0, v.Build), Math.Max(0, v.Revision));

    internal static string? BlockingReason(Node node, IReadOnlyList<Node> nodes)
    {
        foreach (var d in node.Dependencies)
        {
            if (string.Equals(d.Id, node.Id, StringComparison.OrdinalIgnoreCase)) return "Self dependency: " + d.Id;
            var matches = nodes.Where(n => string.Equals(n.Id, d.Id, StringComparison.OrdinalIgnoreCase)).ToArray();
            if (matches.Length != 1) return "Missing or ambiguous dependency: " + d.Id;
            var target = matches[0];
            if (!Version.TryParse(target.Version, out var actual) || Normalize(actual) < Normalize(d.MinimumVersion) ||
                (d.MaximumExclusive is { } max && Normalize(actual) >= Normalize(max)))
                return "Incompatible dependency version: " + d.Id + " (requires " + d.Range + ")";
            if (!target.Started) return "Dependency not active (disabled, failed or cyclic): " + d.Id;
        }
        return null;
    }

    // Dependents before providers, only for active entries. IDs are compared like the host's plugin IDs.
    internal static string[] StopOrder(IEnumerable<string> roots, IReadOnlyList<Node> nodes)
    {
        var order = new List<string>();
        var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        void Visit(string id)
        {
            if (!seen.Add(id)) return;
            foreach (var n in nodes)
                if (n.Started && n.Dependencies.Any(d => string.Equals(d.Id, id, StringComparison.OrdinalIgnoreCase))) Visit(n.Id);
            order.Add(id);
        }
        foreach (var root in roots) Visit(root);
        return order.ToArray();
    }
}
