using MotionDesk.Services;
using Opsis.UI;

namespace MotionDesk.UI;


internal sealed class OriginalHelpForm : OpsisWindow
{
    private static OriginalHelpForm? _open;
    private readonly FlatTabs _tabs = new();
    private readonly Panel _body = new() { Dock = DockStyle.Fill };
    private readonly IReadOnlyList<(string Version, string Date)> _history;
    private readonly RichTextBox _instructions;
    private readonly RichTextBox _license;
    private readonly Panel _versions;
    private readonly FlatComboBox _versionPicker = new();
    private readonly RichTextBox _notes;
    private bool _licenseLoaded;
    private bool _historyLoaded;

    internal static void ShowSingle(IWin32Window? owner, IReadOnlyList<(string Version, string Date)> history,
        HelpSection section = HelpSection.Instructions)
    {
        if (_open is { IsDisposed: false } existing)
        {
            existing._tabs.SelectedIndex = (int)section;
            if (existing.WindowState == FormWindowState.Minimized) existing.WindowState = FormWindowState.Normal;
            existing.BringToFront();
            existing.Activate();
            return;
        }
        _open = new OriginalHelpForm(history, section);
        _open.FormClosed += (_, _) => _open = null;
        if (owner == null) _open.Show();
        else _open.Show(owner);
    }

    internal static void SavePreview(string png, IReadOnlyList<(string Version, string Date)> history, int tab)
    {
        // Retain the existing screenshot command's numbering.
        var section = tab switch { 1 => HelpSection.History, 2 => HelpSection.License, _ => HelpSection.Instructions };
        using var form = new OriginalHelpForm(history, section) { StartPosition = FormStartPosition.Manual, Location = new Point(-5000, -5000), ShowInTaskbar = false };
        form.Show();
        form.PerformLayout();
        Application.DoEvents();
        using var bitmap = new Bitmap(form.Width, form.Height);
        form.DrawToBitmap(bitmap, new Rectangle(0, 0, form.Width, form.Height));
        bitmap.Save(png, System.Drawing.Imaging.ImageFormat.Png);
    }

    private OriginalHelpForm(IReadOnlyList<(string Version, string Date)> history, HelpSection section)
    {
        _history = history;
        Name = "OpsisHelp";
        Text = LocalizationManager.T("Help.Title");
        Icon = AppWindowIcon.Value;
        ShowIcon = true;
        StartPosition = FormStartPosition.CenterParent;
        ClientSize = new Size(810, 660);
        MinimumSize = new Size(735, 410);
        ShowInTaskbar = false;
        _tabs.Dock = DockStyle.Top;
        _tabs.Height = 43;
        _tabs.SetTabs([LocalizationManager.T("Help.TabInstructions"), LocalizationManager.T("Help.TabLicense"),
            LocalizationManager.T("Help.TabHistory")], (int)section);

        _instructions = CreateReader(LocalizationManager.T("About.InstructionsList") + "\n\n" + LocalizationManager.T("About.ShortcutsList"));
        _instructions.Name = "HelpInstructions";
        _license = CreateReader("");
        _license.Name = "HelpLicense";
        _versions = new Panel { Name = "HelpHistory", Dock = DockStyle.Fill, Padding = new Padding(18, 14, 18, 14) };
        var pickerRow = new TableLayoutPanel { Dock = DockStyle.Top, Height = 51, ColumnCount = 2, RowCount = 1 };
        pickerRow.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
        pickerRow.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        var versionLabel = new Label { Text = LocalizationManager.T("VersionHistory.VersionPrefix"), Anchor = AnchorStyles.Left, AutoSize = true, Margin = new Padding(0, 0, 12, 0) };
        _versionPicker.Name = "HistoryVersionPicker";
        _versionPicker.AccessibleName = versionLabel.Text;
        _versionPicker.Anchor = AnchorStyles.Left | AnchorStyles.Right;
        _versionPicker.MaximumSize = new Size(390, 0);
        pickerRow.Controls.Add(versionLabel, 0, 0);
        pickerRow.Controls.Add(_versionPicker, 1, 0);
        _notes = CreateReader("");
        _notes.Name = "HistoryNotes";
        _versionPicker.SelectedIndexChanged += (_, _) => ReadSelectedNotes();
        _versions.Controls.Add(_notes);
        _versions.Controls.Add(pickerRow);
        _notes.BringToFront();

        _body.Controls.AddRange([_instructions, _license, _versions]);
        Controls.Add(_body);
        Controls.Add(_tabs);
        _body.BringToFront();
        _tabs.SelectedIndexChanged += (_, _) => SelectPage();
        OpsisTheme.Changed += Recolour;
        Disposed += (_, _) => OpsisTheme.Changed -= Recolour;
        KeyPreview = true;
        KeyDown += (_, e) => { if (e.KeyCode == Keys.Escape) Close(); };
        Recolour();
        SelectPage();
    }

    private static RichTextBox CreateReader(string content) => new()
    {
        Dock = DockStyle.Fill, ReadOnly = true, BorderStyle = BorderStyle.None, Font = UiTheme.FontBody,
        DetectUrls = false, Text = content.Replace("\\n", "\n"), ScrollBars = RichTextBoxScrollBars.Vertical
    };

    private static string ReadLegalText()
    {
        string Read(string name)
        {
            try { return File.ReadAllText(Path.Combine(AppContext.BaseDirectory, name)).Trim(); }
            catch (Exception ex) when (ex is IOException or UnauthorizedAccessException) { return ""; }
        }
        var license = Read("LICENSE");
        if (license.Length == 0) license = LocalizationManager.T("About.LicenseSummary");
        var notices = Read("THIRD_PARTY_NOTICES.md");
        return notices.Length == 0 ? license : license + "\n\n" + notices;
    }

    private void SelectPage()
    {
        var selected = (HelpSection)_tabs.SelectedIndex;
        _instructions.Visible = selected == HelpSection.Instructions;
        _license.Visible = selected == HelpSection.License;
        _versions.Visible = selected == HelpSection.History;
        if (selected == HelpSection.License && !_licenseLoaded)
        {
            _licenseLoaded = true;
            _license.Text = ReadLegalText();
        }
        if (selected == HelpSection.History && !_historyLoaded && _history.Count > 0)
        {
            _historyLoaded = true;
            var names = _history.Select((item, i) => $"{item.Version}   •   {item.Date}" +
                (i == 0 ? $"   •   {LocalizationManager.T("VersionHistory.Current")}" : "")).ToArray();
            _versionPicker.SetItems(names, names[0]);
            ReadSelectedNotes();
        }
    }

    private void ReadSelectedNotes()
    {
        int index = _versionPicker.SelectedIndex;
        if (index < 0 || index >= _history.Count) return;
        string key = "VersionNotes." + _history[index].Version;
        var notes = LocalizationManager.T(key);
        _notes.Text = notes == key ? "" : string.Join("\n\n", notes.Split('\n', StringSplitOptions.RemoveEmptyEntries)
            .Select(line => line.StartsWith("+ ") || line.StartsWith("~ ") ? "• " + line[2..] :
                line.StartsWith("= ") ? line[2..] : line));
        _notes.SelectionStart = 0;
        _notes.ScrollToCaret();
    }

    private void Recolour()
    {
        if (IsDisposed) return;
        if (InvokeRequired) { try { BeginInvoke(Recolour); } catch (InvalidOperationException) { } return; }
        var theme = OpsisTheme.Current;
        BackColor = _body.BackColor = _versions.BackColor = theme.Background;
        _instructions.BackColor = _license.BackColor = _notes.BackColor = theme.Background;
        _instructions.ForeColor = _license.ForeColor = _notes.ForeColor = theme.Text;
    }
}
