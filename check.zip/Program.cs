using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Text.Json;
using MotionDesk.Services;
using MotionDesk.UI;
using Opsis.UI;

internal static class Program
{
    [STAThread]
    static void Main()
    {
        ApplicationConfiguration.Initialize();
        var versions = JsonSerializer.Deserialize<string[]>(File.ReadAllText("versions.json"))!
            .Select(v => (v, "2026-11")).ToArray();
        foreach (var language in new[] { "el", "en" })
        {
            LocalizationManager.Use(language);
            OriginalHelpForm.ShowSingle(null, versions);
            Application.DoEvents();
            var before = Application.OpenForms.OfType<OriginalHelpForm>().Single();
            before.Controls.OfType<FlatTabs>().Single().SelectedIndex = 2;
            Application.DoEvents();
            var former = before.Controls.Find("HistoryNotes", true).OfType<RichTextBox>().Single();
            Console.WriteLine($"Baseline {language}: visible={former.Visible}, size={former.ClientSize}, length={former.TextLength}");
            before.Close();

            HelpForm.ShowSingle(null, versions);
            Application.DoEvents();
            var help = Application.OpenForms.OfType<HelpForm>().Single();
            var tabs = help.Controls.OfType<TabControl>().Single();
            var list = Find<ListBox>(help, "HistoryVersionPicker");
            var notes = Find<RichTextBox>(help, "HistoryNotes");
            Check(tabs.SelectedIndex == 0 && Find<RichTextBox>(help, "HelpInstructions").TextLength > 30, $"Instructions first ({language})");
            tabs.SelectedIndex = 2;
            Application.DoEvents();
            Check(list.Visible && notes.Visible && notes.ClientSize.Width > 200 && notes.ClientSize.Height > 100, $"Both history panes are visible ({language})");
            Check(list.Items.Count == versions.Length && list.SelectedIndex == 0 && notes.Text.Contains(versions[0].v) && notes.TextLength > 65, $"Latest release and its notes render ({language})");
            for (int i = 0; i < versions.Length; i++)
            {
                list.SelectedIndex = i;
                Check(notes.Text.Contains(versions[i].v) && notes.TextLength > 48, $"Notes for {versions[i].v} ({language})");
            }
            list.SelectedIndex = Math.Min(12, list.Items.Count - 1);
            var selected = list.SelectedIndex;
            tabs.SelectedIndex = 1;
            Application.DoEvents();
            Check(Find<RichTextBox>(help, "HelpLicense").Visible && Find<RichTextBox>(help, "HelpLicense").TextLength > 20, $"License is visible ({language})");
            using var process = Process.GetCurrentProcess();
            var gdiBefore = GetGuiResources(process.Handle, 0);
            var userBefore = GetGuiResources(process.Handle, 1);
            long longest = 0;
            for (int i = 0; i < 100; i++)
            {
                var clock = Stopwatch.StartNew();
                tabs.SelectedIndex = 0;
                tabs.SelectedIndex = 1;
                tabs.SelectedIndex = 2;
                Application.DoEvents();
                longest = Math.Max(longest, clock.ElapsedMilliseconds);
            }
            Check(list.SelectedIndex == selected && list.Visible && notes.Text.Contains(versions[selected].v), $"Selection survives 300 tab changes ({language})");
            var gdiDelta = (long)GetGuiResources(process.Handle, 0) - gdiBefore;
            var userDelta = (long)GetGuiResources(process.Handle, 1) - userBefore;
            Console.WriteLine($"Resources {language}: longest 3-tab cycle {longest} ms, GDI delta {gdiDelta}, USER delta {userDelta}");
            Check(gdiDelta <= 8 && userDelta <= 8 && longest < 1000, $"Tab changes stay within the regression budget ({language})");
            help.Close();

            HelpForm.ShowSingle(null, versions, HelpSection.History);
            Application.DoEvents();
            help = Application.OpenForms.OfType<HelpForm>().Single();
            Check(Find<RichTextBox>(help, "HistoryNotes").Visible && Find<ListBox>(help, "HistoryVersionPicker").SelectedIndex == 0, $"Direct History opening shows the newest release ({language})");
            HelpForm.ShowSingle(null, versions, HelpSection.Instructions);
            Check(Application.OpenForms.OfType<HelpForm>().Single() == help, $"Reopening Help reuses one window ({language})");
            help.Close();
        }

        using var releaseProbe = new ManualResetEventSlim();
        using var enteredProbe = new ManualResetEventSlim();
        int probes = 0;
        var dependency = new DependencyInfo { Id = "fixture", IsInstalled = () =>
        {
            Interlocked.Increment(ref probes);
            enteredProbe.Set();
            return releaseProbe.Wait(5000);
        } };
        using var context = new Form();
        var first = dependency.CheckInstalledAsync();
        Check(enteredProbe.Wait(1000) && !first.IsCompleted, "Dependency probe runs in the background");
        var second = dependency.CheckInstalledAsync();
        Check(ReferenceEquals(first, second), "Concurrent views share the in-flight dependency probe");
        releaseProbe.Set();
        Check(Task.WhenAll(first, second).Wait(1000) && first.Result && probes == 1, "One completed probe supplies both views");
    }

    private static T Find<T>(Control parent, string name) where T : Control => parent.Controls.Find(name, true).OfType<T>().Single();
    private static void Check(bool ok, string description) { if (!ok) throw new InvalidOperationException(description); Console.WriteLine("PASS "+description); }
    [DllImport("user32.dll")] static extern uint GetGuiResources(IntPtr process, uint flag);
}
