using System.Text.Json;
namespace MotionDesk.Services
{
    internal static class LocalizationManager
    {
        private static Dictionary<string,string> strings = new();
        internal static void Use(string language) => strings = JsonSerializer.Deserialize<Dictionary<string,string>>(
            File.ReadAllText(Path.Combine(AppContext.BaseDirectory, $"locale-{language}.json")))!;
        internal static string T(string key) => strings.GetValueOrDefault(key, key);
    }
    internal static class WmvConversionService
    {
        public static bool IsFfmpegAvailable => false;
        public static void ResetDetection() { }
    }
    internal static class RotatingLogger { public static void Write(string value) => Console.WriteLine(value); }
}
namespace MotionDesk.UI
{
    internal static class UiTheme
    {
        internal static Font FontBody => SystemFonts.MessageBoxFont;
        internal static Color AccentCyan => Color.DodgerBlue;
    }
}
